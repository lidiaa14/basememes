package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBg = Color(0xFF090909)
val CardBg = Color(0xFF111111)
val BorderColor = Color(0xFF1F1F1F)

val BaseBlue = Color(0xFF0052FF)
val SafeGreen = Color(0xFF00FF88)
val DangerRed = Color(0xFFFF3B3B)
val WarningYellow = Color(0xFFF5A623)

val TextWhite = Color(0xFFFFFFFF)
val TextMuted = Color(0xFF8A8A8A)

// Theme Colors
val JetBlack = Color(0xFF020202)
val TradingGreenDim = Color(0x1500FF88)
val TradingRedDim = Color(0x15FF3B3B)
val BaseBlueDim = Color(0x150052FF)
val OrangeAccent = Color(0xFFFF7A00)

