package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.OhlcvPoint
import com.example.ui.theme.*
import com.example.utils.Formatters

@Composable
fun ChartToggle(
    isLineChart: Boolean,
    onToggle: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .background(JetBlack, RoundedCornerShape(6.dp))
            .border(1.dp, BorderColor, RoundedCornerShape(6.dp))
            .padding(2.dp)
    ) {
        Button(
            onClick = { onToggle(true) },
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isLineChart) CardBg else Color.Transparent,
                contentColor = if (isLineChart) SafeGreen else TextMuted
            ),
            shape = RoundedCornerShape(4.dp),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
            modifier = Modifier.height(30.dp)
        ) {
            Text("📈 LINE", fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Button(
            onClick = { onToggle(false) },
            colors = ButtonDefaults.buttonColors(
                containerColor = if (!isLineChart) CardBg else Color.Transparent,
                contentColor = if (!isLineChart) SafeGreen else TextMuted
            ),
            shape = RoundedCornerShape(4.dp),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
            modifier = Modifier.height(30.dp)
        ) {
            Text("🕯️ CANDLE", fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun TimeframeSelector(
    selectedTimeframe: String,
    onSelect: (String) -> Unit,
    visibleTimeframes: Set<String> = emptySet(),
    modifier: Modifier = Modifier
) {
    val allOrdered = listOf("1s", "5s", "15s", "30s", "1m", "5m", "15m", "1h", "4h", "1d")
    val options = remember(visibleTimeframes) {
        if (visibleTimeframes.isEmpty()) {
            listOf("15s", "30s", "1m", "5m", "15m", "1h", "4h", "1d")
        } else {
            allOrdered.filter { visibleTimeframes.contains(it) }
        }
    }

    Row(
        modifier = modifier
            .animateContentSize()
            .horizontalScroll(rememberScrollState())
            .background(JetBlack, RoundedCornerShape(6.dp))
            .border(1.dp, BorderColor, RoundedCornerShape(6.dp))
            .padding(2.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        options.forEach { tf ->
            val isSelected = selectedTimeframe == tf
            
            val bgColor by animateColorAsState(
                targetValue = if (isSelected) BaseBlue.copy(alpha = 0.2f) else Color.Transparent,
                label = "bgColorAnimation"
            )
            val borderColor by animateColorAsState(
                targetValue = if (isSelected) BaseBlue else Color.Transparent,
                label = "borderColorAnimation"
            )
            val textColor by animateColorAsState(
                targetValue = if (isSelected) BaseBlue else TextMuted,
                label = "textColorAnimation"
            )

            Box(
                modifier = Modifier
                    .width(42.dp)
                    .height(28.dp)
                    .background(bgColor, RoundedCornerShape(4.dp))
                    .border(1.dp, borderColor, RoundedCornerShape(4.dp))
                    .clickable { onSelect(tf) },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = tf,
                    color = textColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

// Draw custom high-fidelity candlestick details in Canvas
@Composable
fun CandlestickChart(
    candles: List<OhlcvPoint>,
    modifier: Modifier = Modifier
) {
    if (candles.isEmpty()) {
        Box(
            modifier = modifier.background(JetBlack),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = SafeGreen)
        }
        return
    }

    var activeIndex by remember(candles) { mutableStateOf<Int?>(null) }
    val displayCandle = activeIndex?.let { candles.getOrNull(it) } ?: candles.lastOrNull()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardBg)
            .border(1.dp, BorderColor, RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        // Dynamic stats info header
        displayCandle?.let { candle ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "O: " + Formatters.formatUsd(candle.open),
                    color = TextWhite,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    "H: " + Formatters.formatUsd(candle.high),
                    color = SafeGreen,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    "L: " + Formatters.formatUsd(candle.low),
                    color = DangerRed,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    "C: " + Formatters.formatUsd(candle.close),
                    color = TextWhite,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    "Vol: " + Formatters.formatNumberCompact(candle.volume, "$"),
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Box(
            modifier = modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .background(JetBlack)
                    .pointerInput(candles) {
                        detectDragGestures(
                            onDrag = { change, _ ->
                                activeIndex = calculateIndexFromOffset(change.position.x, size.width, candles.size)
                            },
                            onDragEnd = { activeIndex = null },
                            onDragCancel = { activeIndex = null }
                        )
                    }
                    .pointerInput(candles) {
                        detectTapGestures(
                            onPress = { offset ->
                                activeIndex = calculateIndexFromOffset(offset.x, size.width, candles.size)
                                tryAwaitRelease()
                                activeIndex = null
                            }
                        )
                    }
            ) {
                val paddingBottom = size.height * 0.2f // Bottom 20% for Volume bars
                val chartHeight = size.height - paddingBottom

                val maxHigh = candles.maxOf { it.high }
                val minLow = candles.minOf { it.low }
                val deltaY = (maxHigh - minLow).coerceAtLeast(0.0001)

                val count = candles.size
                val stepX = size.width / count

                // Draw background horizontal grids
                val gridLines = 5
                for (i in 0..gridLines) {
                    val y = i * (chartHeight / gridLines)
                    val priceLabelValue = maxHigh - i * (deltaY / gridLines)
                    drawLine(
                        color = BorderColor.copy(alpha = 0.5f),
                        start = Offset(0f, y),
                        end = Offset(size.width, y),
                        strokeWidth = 1f
                    )
                }

                // Draw candles
                candles.forEachIndexed { i, candle ->
                    val x = i * stepX + stepX / 2

                    // Candle Y coordinates
                    val yOpen = ((maxHigh - candle.open) / deltaY * chartHeight).toFloat()
                    val yClose = ((maxHigh - candle.close) / deltaY * chartHeight).toFloat()
                    val yHigh = ((maxHigh - candle.high) / deltaY * chartHeight).toFloat()
                    val yLow = ((maxHigh - candle.low) / deltaY * chartHeight).toFloat()

                    val isUp = candle.close >= candle.open
                    val color = if (isUp) SafeGreen else DangerRed

                    // Draw Wick line
                    drawLine(
                        color = color,
                        start = Offset(x, yHigh),
                        end = Offset(x, yLow),
                        strokeWidth = 1.5f
                    )

                    // Draw Candle Rect
                    val top = minOf(yOpen, yClose)
                    val bottom = maxOf(yOpen, yClose)
                    val candleWidth = (stepX * 0.75f).coerceAtLeast(2f)
                    drawRect(
                        color = color,
                        topLeft = Offset(x - candleWidth / 2f, top),
                        size = Size(candleWidth, (bottom - top).coerceAtLeast(1f))
                    )

                    // Volume Bar Y coordinate
                    val maxVolume = candles.maxOf { it.volume }.coerceAtLeast(1.0)
                    val volHeight = (candle.volume / maxVolume * paddingBottom).toFloat()
                    val volTop = size.height - volHeight
                    drawRect(
                        color = color.copy(alpha = 0.3f),
                        topLeft = Offset(x - candleWidth / 2f, volTop),
                        size = Size(candleWidth, volHeight)
                    )
                }

                // Crosshair highlights
                activeIndex?.let { index ->
                    val x = index * stepX + stepX / 2f
                    drawLine(
                        color = BaseBlue,
                        start = Offset(x, 0f),
                        end = Offset(x, size.height),
                        strokeWidth = 1f,
                        pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )
                }
            }
        }
    }
}

// Simple interactive line chart for Portfolio summaries
@Composable
fun LineChart(
    pointsUsd: List<Double>,
    timestamps: List<Long>,
    modifier: Modifier = Modifier,
    animationProgress: Float = 1.0f
) {
    if (pointsUsd.isEmpty()) {
        Box(
            modifier = modifier
                .background(JetBlack)
                .border(1.dp, BorderColor, RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("Tidak ada data line chart.", color = TextMuted, fontSize = 11.sp)
        }
        return
    }

    var selectedIndex by remember(pointsUsd) { mutableStateOf<Int?>(null) }
    val displayPriceUsd = selectedIndex?.let { pointsUsd.getOrNull(it) } ?: pointsUsd.lastOrNull() ?: 0.0
    val displayTime = selectedIndex?.let { timestamps.getOrNull(it) } ?: timestamps.lastOrNull() ?: 0L

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardBg)
            .border(1.dp, BorderColor, RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "VALUENET: " + Formatters.formatUsd(displayPriceUsd),
                color = SafeGreen,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
            if (displayTime > 0) {
                Text(
                    text = Formatters.formatDateTime(displayTime),
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Box(
            modifier = modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .background(JetBlack)
                    .pointerInput(pointsUsd) {
                        detectDragGestures(
                            onDrag = { change, _ ->
                                selectedIndex = calculateIndexFromOffset(change.position.x, size.width, pointsUsd.size)
                            },
                            onDragEnd = { selectedIndex = null },
                            onDragCancel = { selectedIndex = null }
                        )
                    }
                    .pointerInput(pointsUsd) {
                        detectTapGestures(
                            onPress = { offset ->
                                selectedIndex = calculateIndexFromOffset(offset.x, size.width, pointsUsd.size)
                                tryAwaitRelease()
                                selectedIndex = null
                            }
                        )
                    }
            ) {
                val maxVal = pointsUsd.maxOrNull() ?: 1.0
                val minVal = pointsUsd.minOrNull() ?: 0.0
                val delta = (maxVal - minVal).coerceAtLeast(1.0)

                val count = pointsUsd.size
                val stepX = size.width / (count - 1).coerceAtLeast(1)

                val path = Path()
                val fillPath = Path()

                val activeCount = (count * animationProgress).toInt().coerceAtLeast(1)

                for (idx in 0 until activeCount) {
                    val value = pointsUsd[idx]
                    val x = idx * stepX
                    val y = ((maxVal - value) / delta * size.height).toFloat()

                    if (idx == 0) {
                        path.moveTo(x, y)
                        fillPath.moveTo(x, size.height)
                        fillPath.lineTo(x, y)
                    } else {
                        // draw clean curves
                        val prevX = (idx - 1) * stepX
                        val prevY = ((maxVal - pointsUsd[idx - 1]) / delta * size.height).toFloat()
                        val controlX = (prevX + x) / 2f
                        path.cubicTo(controlX, prevY, controlX, y, x, y)
                        fillPath.cubicTo(controlX, prevY, controlX, y, x, y)
                    }

                    if (idx == activeCount - 1) {
                        fillPath.lineTo(x, size.height)
                        fillPath.close()
                    }
                }

                // Draw solid gridlines
                val grids = 4
                for (i in 0..grids) {
                    val y = i * (size.height / grids)
                    drawLine(
                        color = BorderColor.copy(alpha = 0.3f),
                        start = Offset(0f, y),
                        end = Offset(size.width, y),
                        strokeWidth = 1f
                    )
                }

                // Draw gradient Area underneath
                drawPath(
                    path = fillPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(SafeGreen.copy(alpha = 0.25f), Color.Transparent),
                        startY = 0f,
                        endY = size.height
                    )
                )

                // Draw primary glow line
                drawPath(
                    path = path,
                    color = SafeGreen,
                    style = Stroke(width = 2.dp.toPx())
                )

                // Crosshair Highlights
                selectedIndex?.let { index ->
                    val x = index * stepX
                    drawLine(
                        color = BaseBlue,
                        start = Offset(x, 0f),
                        end = Offset(x, size.height),
                        strokeWidth = 1f,
                        pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )

                    val y = ((maxVal - pointsUsd[index]) / delta * size.height).toFloat()
                    drawCircle(
                        color = BaseBlue,
                        radius = 5.dp.toPx(),
                        center = Offset(x, y)
                    )
                    drawCircle(
                        color = TextWhite,
                        radius = 2.dp.toPx(),
                        center = Offset(x, y)
                    )
                }
            }
        }
    }
}

private fun calculateIndexFromOffset(x: Float, canvasWidth: Int, pointsCount: Int): Int {
    if (pointsCount <= 1 || canvasWidth <= 0) return 0
    val step = canvasWidth.toFloat() / pointsCount
    if (step <= 0f) return 0
    val calculated = (x / step).toInt()
    return calculated.coerceIn(0, pointsCount - 1)
}

private fun clickable(modifier: Modifier, onClick: () -> Unit) = modifier.pointerInput(Unit) {
    detectTapGestures(onTap = { onClick() })
}
