package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddAlert
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Dangerous
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SafetyRating
import com.example.data.Token
import com.example.ui.components.BuySellPanel
import com.example.ui.components.CandlestickChart
import com.example.ui.components.ChartToggle
import com.example.ui.components.LineChart
import com.example.ui.components.PriceAlertModal
import com.example.ui.components.TimeframeSelector
import com.example.ui.components.TokenSafetyBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.TradingViewModel
import com.example.utils.Formatters

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun TradeScreen(
    viewModel: TradingViewModel,
    tokenAddress: String,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val clipboardManager = LocalClipboardManager.current
    var isAlertModalOpen by remember { mutableStateOf(false) }

    // Select token on navigation
    LaunchedEffect(tokenAddress) {
        viewModel.selectToken(tokenAddress)
    }

    val selectedToken by viewModel.selectedToken.collectAsState()
    val candles by viewModel.chartCandles.collectAsState()
    val liveTrades by viewModel.liveTrades.collectAsState()
    val ethBalance by viewModel.ethBalance.collectAsState()
    val holdings by viewModel.holdings.collectAsState()
    val selectedTimeframe by viewModel.selectedTimeframe.collectAsState()
    val userSettings by viewModel.userSettings.collectAsState()

    val tokenBalance = holdings[selectedToken.address] ?: 0.0

    // UI Interactive States
    var isLineChart by remember(userSettings.defaultChartStyle) {
        mutableStateOf(userSettings.defaultChartStyle == "Line")
    }
    var activeSubTab by remember { mutableStateOf(0) } // 0 = Transaksi, 1 = Info

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("trade_screen")
    ) {
        // Danger Honeypot banner warning
        if (selectedToken.safetyRating == SafetyRating.DANGER) {
            Card(
                colors = CardDefaults.cardColors(containerColor = DangerRed.copy(alpha = 0.15f)),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, DangerRed),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Dangerous,
                        contentDescription = null,
                        tint = DangerRed,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "⚠️ KONTRAK BERBAHAYA - HONEYPOT DETECTED",
                            color = DangerRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Aktivitas smart contract mencurigakan. Fungsi penarikan atau penjualan diblokir dalam kode.",
                            color = TextWhite,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }

        // HEADER: Coin identity and large real-time price tracker
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.padding(end = 4.dp).size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextWhite,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(BaseBlue.copy(alpha = 0.15f), CircleShape)
                        .border(1.9.dp, BaseBlue, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        selectedToken.symbol.take(2),
                        color = TextWhite,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = selectedToken.name,
                            color = TextWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        TokenSafetyBadge(selectedToken.safetyRating)
                    }
                    Text(
                        text = selectedToken.symbol,
                        color = TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Real-time price status column
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = Formatters.formatUsd(selectedToken.priceUsd),
                    color = SafeGreen,
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    fontFamily = FontFamily.Monospace
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val isUp = selectedToken.priceChangePercent24h >= 0
                    Text(
                        text = String.format("%+.2f%%", selectedToken.priceChangePercent24h),
                        color = if (isUp) SafeGreen else DangerRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // STATS BAR DETAIL PANEL
        Card(
            colors = CardDefaults.cardColors(containerColor = CardBg),
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, BorderColor),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                // Row 1
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    LabelValueItem(label = "MARKET CAP", value = Formatters.formatNumberCompact(selectedToken.marketCapUsd, "$"))
                    LabelValueItem(label = "VOLUME (24H)", value = Formatters.formatNumberCompact(selectedToken.volume24hUsd, "$"))
                    LabelValueItem(label = "LIQUIDITY", value = Formatters.formatNumberCompact(selectedToken.liquidityUsd, "$"))
                }
                Spacer(modifier = Modifier.height(8.dp))
                Divider(color = BorderColor, thickness = 0.5.dp)
                Spacer(modifier = Modifier.height(8.dp))
                // Row 2
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LabelValueItem(label = "HOLDERS", value = String.format("%,d", selectedToken.holdersCount))
                    LabelValueItem(label = "AGE", value = String.format("%.1fh", selectedToken.pairAgeHours))
                    
                    // Clickable copy contract
                    Column(horizontalAlignment = Alignment.End) {
                        Text("CONTRACT", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clickable {
                                    clipboardManager.setText(AnnotatedString(selectedToken.address))
                                }
                                .padding(top = 2.dp)
                        ) {
                            Text(
                                text = Formatters.shortenAddress(selectedToken.address),
                                color = BaseBlue,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = TextMuted, modifier = Modifier.size(10.dp))
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // INTERACTIVE CHART AREA CONSOLE
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ChartToggle(
                isLineChart = isLineChart,
                onToggle = { isLineChart = it }
            )
            TimeframeSelector(
                selectedTimeframe = selectedTimeframe,
                onSelect = { viewModel.setTimeframe(it) },
                visibleTimeframes = userSettings.chartSettings.visibleTimeframes
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Render selected chart frame
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(260.dp)
        ) {
            if (isLineChart) {
                val chartPointsUsd = remember(candles) { candles.map { it.close } }
                val chartTimes = remember(candles) { candles.map { it.timestamp } }
                LineChart(
                    pointsUsd = chartPointsUsd,
                    timestamps = chartTimes,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                CandlestickChart(
                    candles = candles,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // PRICE ALERT SUBMISSION BAR
        Button(
            onClick = { isAlertModalOpen = true },
            colors = ButtonDefaults.buttonColors(containerColor = JetBlack, contentColor = TextWhite),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderColor, RoundedCornerShape(8.dp))
                .height(44.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.AddAlert, contentDescription = null, tint = BaseBlue, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("PASANG ALARM HARGA BARU 🔔", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // TRANSACTION PANELS IN OUT
        BuySellPanel(
            token = selectedToken,
            ethBalance = ethBalance,
            tokenBalance = tokenBalance,
            onBuy = { tk, eth, slip -> viewModel.executeBuy(tk, eth, slip) },
            onSell = { tk, size, slip -> viewModel.executeSell(tk, size, slip) },
            userSettings = userSettings
        )

        Spacer(modifier = Modifier.height(20.dp))

        // TAB BAR FOR TRANSAKSI / COIN DETAILS INFO
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(BottomBorder(1.dp, BorderColor))
                .padding(bottom = 2.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clickable { activeSubTab = 0 }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "TRANSAKSI LIVE 📊",
                    color = if (activeSubTab == 0) BaseBlue else TextMuted,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clickable { activeSubTab = 1 }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "INFO TOKEN ℹ️",
                    color = if (activeSubTab == 1) BaseBlue else TextMuted,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Tabs viewport
        if (activeSubTab == 0) {
            // Live Transactions Column
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(JetBlack, RoundedCornerShape(8.dp))
                    .border(1.dp, BorderColor, RoundedCornerShape(8.dp))
                    .padding(8.dp)
                    .heightIn(max = 280.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("WALLET / TYPE", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text("ETH", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text("TOKEN", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text("HASH", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
                Divider(color = BorderColor, thickness = 0.5.dp)
                Spacer(modifier = Modifier.height(4.dp))

                liveTrades.forEach { trade ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp, horizontal = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(if (trade.isBuy) TradingGreenDim else TradingRedDim)
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (trade.isBuy) "BUY" else "SELL",
                                    color = if (trade.isBuy) SafeGreen else DangerRed,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                trade.walletShort,
                                color = TextWhite,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Text(
                            String.format("%.3f", trade.ethAmount),
                            color = TextWhite,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            Formatters.formatNumberCompact(trade.tokenAmount),
                            color = TextWhite,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "[TX]",
                            color = BaseBlue,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable {
                                clipboardManager.setText(AnnotatedString("https://basescan.org/tx/" + trade.txHash))
                            }
                        )
                    }
                }
            }
        } else {
            // General token description and links
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(JetBlack, RoundedCornerShape(8.dp))
                    .border(1.dp, BorderColor, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Text(
                    text = if (selectedToken.description.isNotBlank()) selectedToken.description else "No description available for ${selectedToken.symbol}.",
                    color = TextWhite,
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    fontFamily = FontFamily.Serif
                )

                Spacer(modifier = Modifier.height(12.dp))

                Divider(color = BorderColor, thickness = 0.5.dp)

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (selectedToken.socialsWebsite.isNotBlank()) {
                        SocialTag(label = "WEBSITE", link = selectedToken.socialsWebsite)
                    }
                    if (selectedToken.socialsX.isNotBlank()) {
                        SocialTag(label = "TWITTER", link = selectedToken.socialsX)
                    }
                    if (selectedToken.socialsTelegram.isNotBlank()) {
                        SocialTag(label = "TELEGRAM", link = selectedToken.socialsTelegram)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Deployer: " + if (selectedToken.deployerAddress.isNotBlank()) Formatters.shortenAddress(selectedToken.deployerAddress) else "Anonymous",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }

    // Modal popup alerts setting dialog
    PriceAlertModal(
        token = selectedToken,
        isOpen = isAlertModalOpen,
        onClose = { isAlertModalOpen = false },
        onSave = { tk, target, isAb -> viewModel.addPriceAlert(tk, target, isAb) }
    )
}

@Composable
fun LabelValueItem(label: String, value: String) {
    Column {
        Text(text = label, color = TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun SocialTag(
    label: String,
    link: String
) {
    val clipboardManager = LocalClipboardManager.current
    Row(
        modifier = Modifier
            .border(1.dp, BorderColor, RoundedCornerShape(4.dp))
            .clickable {
                clipboardManager.setText(AnnotatedString(link))
            }
            .padding(horizontal = 6.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = Icons.Default.Link, contentDescription = null, tint = BaseBlue, modifier = Modifier.size(10.dp))
        Spacer(modifier = Modifier.width(3.dp))
        Text(text = label, color = TextWhite, fontSize = 8.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}

private fun BottomBorder(strokeWidth: androidx.compose.ui.unit.Dp, color: Color) = BorderStroke(strokeWidth, color)
