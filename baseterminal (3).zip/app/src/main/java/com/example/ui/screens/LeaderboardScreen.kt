package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.LeaderboardTrader
import com.example.data.MockData
import com.example.ui.theme.*
import com.example.utils.Formatters

@Composable
fun LeaderboardScreen(
    modifier: Modifier = Modifier
) {
    // 3 tabs options: 0 = Volume, 1 = PnL, 2 = Win Rate
    var selectMetricTab by remember { mutableStateOf(0) }

    val tradersList = remember(selectMetricTab) {
        when (selectMetricTab) {
            1 -> MockData.leaderboard.sortedByDescending { it.pnlUsd }
            2 -> MockData.leaderboard.sortedByDescending { it.winRate }
            else -> MockData.leaderboard.sortedByDescending { it.volumeEth }
        }
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("leaderboard_screen")
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = Icons.Default.EmojiEvents, contentDescription = null, tint = WarningYellow, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "LEADERBOARD TRADER",
                color = BaseBlue,
                fontWeight = FontWeight.Black,
                fontSize = 18.sp,
                letterSpacing = 0.5.sp
            )
        }
        Text(
            text = "Trader paling aktif dan menguntungkan di Base chain",
            color = TextMuted,
            fontSize = 11.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        // CATEGORY SELECTION TABS
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(JetBlack, RoundedCornerShape(8.dp))
                .border(1.dp, BorderColor, RoundedCornerShape(8.dp))
                .padding(2.dp)
        ) {
            listOf("VOLUME ", "PNL ", "WIN RATE").forEachIndexed { idx, label ->
                val active = selectMetricTab == idx
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (active) BaseBlue.copy(alpha = 0.15f) else Color.Transparent)
                        .border(1.dp, if (active) BaseBlue else Color.Transparent, RoundedCornerShape(6.dp))
                        .clickable { selectMetricTab = idx },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = if (active) BaseBlue else TextMuted,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // LEADERS LIST
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            tradersList.forEachIndexed { index, trader ->
                LeaderWidgetRow(
                    index = index + 1,
                    trader = trader,
                    metricTab = selectMetricTab
                )
            }
        }
    }
}

@Composable
fun LeaderWidgetRow(
    index: Int,
    trader: LeaderboardTrader,
    metricTab: Int
) {
    val highlightBorder = when (index) {
        1 -> BorderStroke(1.5.dp, WarningYellow)
        2 -> BorderStroke(1.dp, Color(0xFFC0C0C0)) // Silver
        3 -> BorderStroke(1.dp, Color(0xFFCD7F32)) // Bronze
        else -> BorderStroke(0.5.dp, BorderColor)
    }

    val dynamicGradient = remember(trader.username) {
        Brush.horizontalGradient(
            colors = listOf(Color(trader.avatarGradientStart), Color(trader.avatarGradientEnd))
        )
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(8.dp),
        border = highlightBorder,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Rank tag
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(if (index <= 3) JetBlack else Color.Transparent),
                contentAlignment = Alignment.Center
            ) {
                if (index == 1) {
                    Icon(imageVector = Icons.Default.Star, contentDescription = null, tint = WarningYellow, modifier = Modifier.size(14.dp))
                } else {
                    Text(
                        text = "#$index",
                        color = if (index <= 3) WarningYellow else TextMuted,
                        fontWeight = FontWeight.Black,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Color circle gradient jazzicon equivalent
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(dynamicGradient)
                    .border(1.dp, BorderColor, CircleShape)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = trader.username,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = String.format("%d trade • Win %s", trader.totalTrades, Formatters.shortenAddress(trader.address)),
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Metric values column
            Column(horizontalAlignment = Alignment.End) {
                val valueString = when (metricTab) {
                    1 -> Formatters.formatUsd(trader.pnlUsd)
                    2 -> String.format("%.1f%% WR", trader.winRate)
                    else -> String.format("%.1f ETH Vol", trader.volumeEth)
                }
                val valueColor = when (metricTab) {
                    1 -> if (trader.pnlUsd >= 0) SafeGreen else DangerRed
                    2 -> SafeGreen
                    else -> BaseBlue
                }

                Text(
                    text = valueString,
                    color = valueColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
