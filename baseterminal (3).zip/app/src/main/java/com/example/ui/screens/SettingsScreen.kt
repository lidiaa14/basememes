package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.UserSettings
import com.example.ui.theme.*
import com.example.ui.viewmodel.TradingViewModel
import com.example.utils.Formatters
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: TradingViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        viewModel.warningMessageFlow.collect { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
        }
    }

    val settings by viewModel.userSettings.collectAsState()
    val username by viewModel.username.collectAsState()

    var showClearDialog by remember { mutableStateOf(false) }
    var saveFeedbackText by remember { mutableStateOf<String?>(null) }

    // local text fields state for smooth typing without instant JSON serialization lag
    var localUsername by remember(username) { mutableStateOf(username) }
    var localBio by remember(settings.bio) { mutableStateOf(settings.bio) }
    var localSlippage by remember(settings.defaultSlippage) { mutableStateOf(settings.defaultSlippage.toString()) }
    
    // quick buy amounts string list for text edits
    var localBuyAmount0 by remember(settings.defaultBuyAmounts) { mutableStateOf(settings.defaultBuyAmounts.getOrElse(0) { 0.01 }.toString()) }
    var localBuyAmount1 by remember(settings.defaultBuyAmounts) { mutableStateOf(settings.defaultBuyAmounts.getOrElse(1) { 0.05 }.toString()) }
    var localBuyAmount2 by remember(settings.defaultBuyAmounts) { mutableStateOf(settings.defaultBuyAmounts.getOrElse(2) { 0.1 }.toString()) }
    var localBuyAmount3 by remember(settings.defaultBuyAmounts) { mutableStateOf(settings.defaultBuyAmounts.getOrElse(3) { 0.5 }.toString()) }

    var localBlacklistInput by remember { mutableStateOf("") }
    var localMinLiquidity by remember(settings.minLiquidityUsd) { mutableStateOf(settings.minLiquidityUsd.toInt().toString()) }

    // Show temporary "Saved" badge helper
    fun triggerSaveToast(msg: String = "Saved ✓") {
        saveFeedbackText = msg
        coroutineScope.launch {
            delay(1500L)
            if (saveFeedbackText == msg) {
                saveFeedbackText = null
            }
        }
    }

    // Auto-save setting updates helper
    fun saveSettings(updated: UserSettings) {
        viewModel.updateSettings(updated)
        triggerSaveToast()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .padding(bottom = 60.dp), // extra space for bottom navigation
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // TOP HEADER INTRO
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SETTINGS",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Konfigurasi trading preference global",
                    fontSize = 11.sp,
                    color = TextMuted
                )
            }

            AnimatedVisibility(
                visible = saveFeedbackText != null,
                enter = fadeIn() + expandHorizontally(),
                exit = fadeOut() + shrinkHorizontally()
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(SafeGreen.copy(alpha = 0.15f))
                        .border(1.dp, SafeGreen, RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = saveFeedbackText ?: "",
                        color = SafeGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), thickness = 1.dp)

        // --- APPEARANCE SECTION ---
        SettingsCategoryCard(title = "APPEARANCE", icon = Icons.Default.Palette) {
            // Theme setting
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Theme Mode", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                    Text("Pilih mode warna visual aplikasi", fontSize = 11.sp, color = TextMuted)
                }
                ThemeSelectorRow(
                    selected = settings.theme,
                    onSelect = {
                        saveSettings(settings.copy(theme = it))
                    }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Accent Color setting
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("Accent Primary Color", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                Text("Pilih warna aksen utama navigasi dan tombol", fontSize = 11.sp, color = TextMuted)
                Spacer(modifier = Modifier.height(8.dp))
                AccentColorPickerRow(
                    selectedColor = settings.accentColor,
                    onSelectColor = {
                        saveSettings(settings.copy(accentColor = it))
                    }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Default Chart Style
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Chart Style Default", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                    Text("Gaya default grafik pergerakan harga", fontSize = 11.sp, color = TextMuted)
                }
                SegmentedControl(
                    items = listOf("Candlestick", "Line"),
                    selected = settings.defaultChartStyle,
                    onSelect = {
                        saveSettings(settings.copy(defaultChartStyle = it))
                    }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Compact Mode Toggle
            SettingsToggleRow(
                title = "Compact Mode UI",
                subtitle = "Gunakan layout padat & font kecil di feed",
                checked = settings.isCompactMode,
                onCheckedChange = {
                    saveSettings(settings.copy(isCompactMode = it))
                }
            )
        }

        // --- CHART PREFERENCES SECTION ---
        SettingsCategoryCard(title = "CHART PREFERENCES", icon = Icons.Default.BarChart) {
            // Default Chart Style
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Chart Style Default", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                    Text("Gaya default grafik pergerakan harga", fontSize = 11.sp, color = TextMuted)
                }
                SegmentedControl(
                    items = listOf("Candlestick", "Line"),
                    selected = settings.defaultChartStyle,
                    onSelect = {
                        saveSettings(settings.copy(defaultChartStyle = it))
                    }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Default Chart Timeframe
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("Default Chart Timeframe", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                Text("Skala waktu default saat membuka grafik harga", fontSize = 11.sp, color = TextMuted)
                Spacer(modifier = Modifier.height(8.dp))
                
                val activeTimeframes = listOf("1s", "5s", "15s", "30s", "1m", "5m", "15m", "1h", "4h", "1d").filter { 
                    settings.chartSettings.visibleTimeframes.contains(it) 
                }
                
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .clip(RoundedCornerShape(8.dp))
                        .background(JetBlack)
                        .border(1.dp, BorderColor, RoundedCornerShape(8.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    activeTimeframes.forEach { tf ->
                        val isSelected = settings.chartSettings.defaultTimeframe == tf
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent)
                                .clickable { 
                                    saveSettings(settings.copy(
                                        chartSettings = settings.chartSettings.copy(defaultTimeframe = tf)
                                    ))
                                }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = tf,
                                color = if (isSelected) TextWhite else TextMuted,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Visible Timeframes
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("Visible Timeframes", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                Text("Pilih skala waktu yang aktif di layar perdagangan", fontSize = 11.sp, color = TextMuted)
                Spacer(modifier = Modifier.height(12.dp))

                val allTfs = listOf(
                    listOf("1s", "5s", "15s", "30s"),
                    listOf("1m", "5m", "15m"),
                    listOf("1h", "4h", "1d")
                )

                allTfs.forEachIndexed { rowIndex, rowList ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        rowList.forEach { tf ->
                            val isActive = settings.chartSettings.visibleTimeframes.contains(tf)

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(38.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (isActive) BaseBlue.copy(alpha = 0.15f) else Color.Transparent
                                    )
                                    .border(
                                        1.dp,
                                        if (isActive) BaseBlue else BorderColor,
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable {
                                        val currentVisible = settings.chartSettings.visibleTimeframes
                                        if (isActive) {
                                            // Try disabling it
                                            if (currentVisible.size <= 1) {
                                                // Prevent turning off all
                                                Toast.makeText(context, "Minimal harus ada 1 timeframe yang aktif", Toast.LENGTH_SHORT).show()
                                            } else {
                                                val nextVisible = currentVisible - tf
                                                var nextDefault = settings.chartSettings.defaultTimeframe
                                                if (settings.chartSettings.defaultTimeframe == tf) {
                                                    // Find nearest available
                                                    nextDefault = com.example.utils.TimeframeHelper.findNearestAvailableTimeframe(tf, nextVisible)
                                                }
                                                // Call viewmodel updateSettings directly to trigger validation & toasts properly
                                                viewModel.updateSettings(settings.copy(
                                                    chartSettings = settings.chartSettings.copy(
                                                        visibleTimeframes = nextVisible,
                                                        defaultTimeframe = nextDefault
                                                    )
                                                ))
                                                triggerSaveToast()
                                            }
                                        } else {
                                            // Turning on
                                            viewModel.updateSettings(settings.copy(
                                                chartSettings = settings.chartSettings.copy(
                                                    visibleTimeframes = currentVisible + tf
                                                )
                                            ))
                                            triggerSaveToast()
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    if (isActive) {
                                        Text(
                                            text = "✓ ",
                                            color = BaseBlue,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                    Text(
                                        text = tf,
                                        color = if (isActive) BaseBlue else TextMuted,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                    if (rowIndex < 2) {
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
        }

        // --- TRADING PREFERENCES SECTION ---
        SettingsCategoryCard(title = "TRADING PREFERENCES", icon = Icons.Default.TrendingUp) {
            // Default Slippage field
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1.3f)) {
                    Text("Default Slippage Tolerance", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                    Text("Slippage default saat membuka form beli/jual", fontSize = 11.sp, color = TextMuted)
                }
                OutlinedTextField(
                    value = localSlippage,
                    onValueChange = {
                        localSlippage = it
                        val dVal = it.toDoubleOrNull()
                        if (dVal != null && dVal > 0.0) {
                            viewModel.updateSettings(settings.copy(defaultSlippage = dVal))
                            triggerSaveToast("Slippage set to $dVal%")
                        }
                    },
                    modifier = Modifier.width(90.dp),
                    trailingIcon = { Text("%", color = TextMuted, fontSize = 12.sp) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    textStyle = LocalTextStyle.current.copy(fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = TextWhite),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = JetBlack,
                        unfocusedContainerColor = JetBlack,
                        focusedIndicatorColor = MaterialTheme.colorScheme.primary,
                        unfocusedIndicatorColor = BorderColor
                    )
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Gas preference
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Gas Preference Rate", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                    Text("Kecepatan eksekusi gas fee blockchain", fontSize = 11.sp, color = TextMuted)
                }
                SegmentedControl(
                    items = listOf("Standard", "Fast", "Instant"),
                    selected = settings.gasPreference,
                    onSelect = {
                        saveSettings(settings.copy(gasPreference = it))
                    }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Confirm before trade checkbox
            SettingsToggleRow(
                title = "Confirm Before Trading",
                subtitle = "Tampilkan modal konfirmasi sebelum eksekusi order",
                checked = settings.isConfirmBeforeTrade,
                onCheckedChange = {
                    saveSettings(settings.copy(isConfirmBeforeTrade = it))
                }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Quick Buy customization
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("Quick Buy ETH Budgets", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                Text("Kustomisasi 4 tombol cepat jumlah ETH saat trading", fontSize = 11.sp, color = TextMuted)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Budget 1
                    OutlinedTextField(
                        value = localBuyAmount0,
                        onValueChange = { newVal ->
                            localBuyAmount0 = newVal
                            val dVal = newVal.toDoubleOrNull()
                            if (dVal != null && dVal > 0.0) {
                                val currentList = settings.defaultBuyAmounts.toMutableList()
                                while (currentList.size <= 0) currentList.add(0.1)
                                currentList[0] = dVal
                                viewModel.updateSettings(settings.copy(defaultBuyAmounts = currentList))
                                triggerSaveToast("Quick amount 1 set to $dVal ETH")
                            }
                        },
                        modifier = Modifier.weight(1f),
                        suffix = { Text("E", color = TextMuted, fontSize = 9.sp) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = LocalTextStyle.current.copy(fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = TextWhite),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = JetBlack,
                            unfocusedContainerColor = JetBlack,
                            focusedIndicatorColor = MaterialTheme.colorScheme.primary,
                            unfocusedIndicatorColor = BorderColor
                        )
                    )

                    // Budget 2
                    OutlinedTextField(
                        value = localBuyAmount1,
                        onValueChange = { newVal ->
                            localBuyAmount1 = newVal
                            val dVal = newVal.toDoubleOrNull()
                            if (dVal != null && dVal > 0.0) {
                                val currentList = settings.defaultBuyAmounts.toMutableList()
                                while (currentList.size <= 1) currentList.add(0.1)
                                currentList[1] = dVal
                                viewModel.updateSettings(settings.copy(defaultBuyAmounts = currentList))
                                triggerSaveToast("Quick amount 2 set to $dVal ETH")
                            }
                        },
                        modifier = Modifier.weight(1f),
                        suffix = { Text("E", color = TextMuted, fontSize = 9.sp) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = LocalTextStyle.current.copy(fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = TextWhite),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = JetBlack,
                            unfocusedContainerColor = JetBlack,
                            focusedIndicatorColor = MaterialTheme.colorScheme.primary,
                            unfocusedIndicatorColor = BorderColor
                        )
                    )

                    // Budget 3
                    OutlinedTextField(
                        value = localBuyAmount2,
                        onValueChange = { newVal ->
                            localBuyAmount2 = newVal
                            val dVal = newVal.toDoubleOrNull()
                            if (dVal != null && dVal > 0.0) {
                                val currentList = settings.defaultBuyAmounts.toMutableList()
                                while (currentList.size <= 2) currentList.add(0.1)
                                currentList[2] = dVal
                                viewModel.updateSettings(settings.copy(defaultBuyAmounts = currentList))
                                triggerSaveToast("Quick amount 3 set to $dVal ETH")
                            }
                        },
                        modifier = Modifier.weight(1f),
                        suffix = { Text("E", color = TextMuted, fontSize = 9.sp) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = LocalTextStyle.current.copy(fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = TextWhite),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = JetBlack,
                            unfocusedContainerColor = JetBlack,
                            focusedIndicatorColor = MaterialTheme.colorScheme.primary,
                            unfocusedIndicatorColor = BorderColor
                        )
                    )

                    // Budget 4
                    OutlinedTextField(
                        value = localBuyAmount3,
                        onValueChange = { newVal ->
                            localBuyAmount3 = newVal
                            val dVal = newVal.toDoubleOrNull()
                            if (dVal != null && dVal > 0.0) {
                                val currentList = settings.defaultBuyAmounts.toMutableList()
                                while (currentList.size <= 3) currentList.add(0.1)
                                currentList[3] = dVal
                                viewModel.updateSettings(settings.copy(defaultBuyAmounts = currentList))
                                triggerSaveToast("Quick amount 4 set to $dVal ETH")
                            }
                        },
                        modifier = Modifier.weight(1f),
                        suffix = { Text("E", color = TextMuted, fontSize = 9.sp) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = LocalTextStyle.current.copy(fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = TextWhite),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = JetBlack,
                            unfocusedContainerColor = JetBlack,
                            focusedIndicatorColor = MaterialTheme.colorScheme.primary,
                            unfocusedIndicatorColor = BorderColor
                        )
                    )
                }
            }
        }

        // --- SAFETY SECTION ---
        SettingsCategoryCard(title = "SAFETY AND PROTECTION", icon = Icons.Default.Shield) {
            // Hide dangerous tokens
            SettingsToggleRow(
                title = "Hide Scam / Danger Tokens",
                subtitle = "Sembunyikan koin berlabel merah 🔴 DANGER dari feed",
                checked = settings.isHideDangerousTokens,
                onCheckedChange = {
                    saveSettings(settings.copy(isHideDangerousTokens = it))
                }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Auto safety check
            SettingsToggleRow(
                title = "Auto Token Safety Check",
                subtitle = "Pindai koin otomatis saat membuka layar trade",
                checked = settings.isAutoSafetyCheck,
                onCheckedChange = {
                    saveSettings(settings.copy(isAutoSafetyCheck = it))
                }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Token Blacklist modifier
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("Contract Blacklist", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                Text("Koin yang memiliki alamat kontrak di bawah tidak akan muncul", fontSize = 11.sp, color = TextMuted)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = localBlacklistInput,
                        onValueChange = { localBlacklistInput = it },
                        placeholder = { Text("0x...", color = TextMuted, fontSize = 12.sp) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        textStyle = LocalTextStyle.current.copy(fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = TextWhite),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = JetBlack,
                            unfocusedContainerColor = JetBlack,
                            focusedIndicatorColor = MaterialTheme.colorScheme.primary,
                            unfocusedIndicatorColor = BorderColor
                        )
                    )
                    Button(
                        onClick = {
                            val addr = localBlacklistInput.trim().lowercase()
                            if (addr.startsWith("0x") && addr.length > 10) {
                                if (!settings.blacklist.contains(addr)) {
                                    val updated = settings.blacklist + addr
                                    saveSettings(settings.copy(blacklist = updated))
                                    localBlacklistInput = ""
                                    triggerSaveToast("Contract Blacklisted 🚫")
                                }
                            } else {
                                Toast.makeText(context, "Format alamat tidak valid", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp)
                    ) {
                        Text("Add", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                    }
                }

                if (settings.blacklist.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(JetBlack)
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        settings.blacklist.forEach { address ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = address,
                                    fontSize = 10.sp,
                                    color = TextMuted,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.weight(1f)
                                )
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Hapus",
                                    tint = DangerRed,
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clickable {
                                            val updated = settings.blacklist.filter { it != address }
                                            saveSettings(settings.copy(blacklist = updated))
                                            triggerSaveToast("Removed from blacklist")
                                        }
                                )
                            }
                        }
                    }
                }
            }
        }

        // --- NOTIFICATIONS SECTION ---
        SettingsCategoryCard(title = "NOTIFICATIONS STATE", icon = Icons.Default.Notifications) {
            SettingsToggleRow(
                title = "Push Price Alerts",
                subtitle = "Aktifkan notifikasi bubble saat target tercapai",
                checked = settings.isPriceAlertEnabled,
                onCheckedChange = {
                    saveSettings(settings.copy(isPriceAlertEnabled = it))
                }
            )

            Spacer(modifier = Modifier.height(14.dp))

            SettingsToggleRow(
                title = "Notification Sound alert",
                subtitle = "Mainkan audio ping khas bursa efek saat bid terpicu",
                checked = settings.isSoundAlertEnabled,
                onCheckedChange = {
                    saveSettings(settings.copy(isSoundAlertEnabled = it))
                }
            )

            Spacer(modifier = Modifier.height(14.dp))

            SettingsToggleRow(
                title = "Base New Token Listings",
                subtitle = "Notifikasi langsung saat pool anyar dibuat di Uniswap",
                checked = settings.isNewListingAlertEnabled,
                onCheckedChange = {
                    saveSettings(settings.copy(isNewListingAlertEnabled = it))
                }
            )
        }

        // --- HOME FEED CONFIGURATION SECTION ---
        SettingsCategoryCard(title = "HOME FEED CONFIGURATION", icon = Icons.Default.Home) {
            // Just Launched Refresh Rate
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Just Launched Refresh Rate", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                    Text("Pilih interval update (Fast uses more data)", fontSize = 11.sp, color = TextMuted)
                }
                val rateItem = when(settings.justLaunchedRefreshRateSeconds) {
                    5 -> "Fast (5s)"
                    30 -> "Slow (30s)"
                    else -> "Normal (10s)"
                }
                SegmentedControl(
                    items = listOf("Fast (5s)", "Normal (10s)", "Slow (30s)"),
                    selected = rateItem,
                    onSelect = { selected ->
                        val secs = when(selected) {
                            "Fast (5s)" -> 5
                            "Slow (30s)" -> 30
                            else -> 10
                        }
                        saveSettings(settings.copy(justLaunchedRefreshRateSeconds = secs))
                    }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Minimum Liquidity Filter
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1.3f)) {
                    Text("Minimum Liquidity in USD", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                    Text("Sembunyikan koin rilis baru di bawah nilai likuiditas ini", fontSize = 11.sp, color = TextMuted)
                }
                OutlinedTextField(
                    value = localMinLiquidity,
                    onValueChange = {
                        localMinLiquidity = it
                        val dVal = it.toDoubleOrNull()
                        if (dVal != null) {
                            viewModel.updateSettings(settings.copy(minLiquidityUsd = dVal))
                            triggerSaveToast("Min liquidity set to \$${Formatters.formatNumberCompact(dVal)}")
                        }
                    },
                    modifier = Modifier.width(110.dp),
                    leadingIcon = { Text("$", color = TextMuted, fontSize = 12.sp) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    textStyle = LocalTextStyle.current.copy(fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = TextWhite),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = JetBlack,
                        unfocusedContainerColor = JetBlack,
                        focusedIndicatorColor = MaterialTheme.colorScheme.primary,
                        unfocusedIndicatorColor = BorderColor
                    )
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Hide tokens younger than
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Hide Tokens Younger Than", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                    Text("Sembunyikan koin yang baru rilis beberapa saat lalu", fontSize = 11.sp, color = TextMuted)
                }
                val youngerStr = when(settings.hideTokensYoungerThanMinutes) {
                    1 -> "1 min"
                    5 -> "5 mins"
                    10 -> "10 mins"
                    else -> "No filter"
                }
                SegmentedControl(
                    items = listOf("No filter", "1 min", "5 mins", "10 mins"),
                    selected = youngerStr,
                    onSelect = { selected ->
                        val mins = when(selected) {
                            "1 min" -> 1
                            "5 mins" -> 5
                            "10 mins" -> 10
                            else -> 0
                        }
                        saveSettings(settings.copy(hideTokensYoungerThanMinutes = mins))
                    }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Show Live Feed Ticker Toggle
            SettingsToggleRow(
                title = "Show Live Feed Ticker",
                subtitle = "Tampilkan running feed real-time di atas layar Beranda",
                checked = settings.isShowLiveFeedTicker,
                onCheckedChange = {
                    saveSettings(settings.copy(isShowLiveFeedTicker = it))
                }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Auto-open new token toggle
            SettingsToggleRow(
                title = "Auto-open New Token Popup",
                subtitle = "Tampilkan dialog detail pembelian instan saat token meluncur",
                checked = settings.isAutoOpenNewToken,
                onCheckedChange = {
                    saveSettings(settings.copy(isAutoOpenNewToken = it))
                }
            )
        }

        // --- DISPLAY CONFIGURATION SECTION ---
        SettingsCategoryCard(title = "DISPLAY & FORMATTING", icon = Icons.Default.Visibility) {
            // Currency selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Currency Mode", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                    Text("Mata uang portofolio & token", fontSize = 11.sp, color = TextMuted)
                }
                SegmentedControl(
                    items = listOf("ETH", "USD", "Both"),
                    selected = settings.currencyDisplay,
                    onSelect = {
                        saveSettings(settings.copy(currencyDisplay = it))
                    }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Address format selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Address Formatting", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                    Text("Format tampilan alamat crypto wallet", fontSize = 11.sp, color = TextMuted)
                }
                SegmentedControl(
                    items = listOf("Short", "Full"),
                    selected = settings.addressFormat,
                    onSelect = {
                        saveSettings(settings.copy(addressFormat = it))
                    }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Time format selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Timestamp Type", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                    Text("Gaya waktu pada histori transaksi", fontSize = 11.sp, color = TextMuted)
                }
                SegmentedControl(
                    items = listOf("Relative", "Absolute"),
                    selected = settings.timeFormat,
                    onSelect = {
                        saveSettings(settings.copy(timeFormat = it))
                    }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Hide small balances
            SettingsToggleRow(
                title = "Hide Small Balances",
                subtitle = "Sembunyikan aset portofolio bernilai < 0.001 ETH",
                checked = settings.isHideSmallBalances,
                onCheckedChange = {
                    saveSettings(settings.copy(isHideSmallBalances = it))
                }
            )
        }

        // --- ACCOUNT SECTION ---
        SettingsCategoryCard(title = "ACCOUNT OVERVIEW", icon = Icons.Default.ManageAccounts) {
            // Edit Username
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("Edit Trading Nickname", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = localUsername,
                        onValueChange = { localUsername = it },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        textStyle = LocalTextStyle.current.copy(fontSize = 13.sp, color = TextWhite),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = JetBlack,
                            unfocusedContainerColor = JetBlack,
                            focusedIndicatorColor = MaterialTheme.colorScheme.primary,
                            unfocusedIndicatorColor = BorderColor
                        )
                    )
                    Button(
                        onClick = {
                            if (localUsername.isNotBlank()) {
                                viewModel.updateUsername(localUsername)
                                triggerSaveToast("Nickname updated ✓")
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Save", fontSize = 12.sp, color = TextWhite)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Edit Bio
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("Edit Bio / Description", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = localBio,
                        onValueChange = { localBio = it },
                        modifier = Modifier.weight(1f),
                        maxLines = 2,
                        textStyle = LocalTextStyle.current.copy(fontSize = 12.sp, color = TextWhite),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = JetBlack,
                            unfocusedContainerColor = JetBlack,
                            focusedIndicatorColor = MaterialTheme.colorScheme.primary,
                            unfocusedIndicatorColor = BorderColor
                        )
                    )
                    Button(
                        onClick = {
                            viewModel.updateSettings(settings.copy(bio = localBio))
                            triggerSaveToast("Bio updated ✓")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Save", fontSize = 12.sp, color = TextWhite)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Divider(color = BorderColor, thickness = 1.dp)

            Spacer(modifier = Modifier.height(16.dp))

            // Action Buttons: CSV exporter and Data Resetter
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // CSV Button
                Button(
                    onClick = {
                        val csvData = viewModel.exportTradeHistoryToCsv()
                        clipboardManager.setText(AnnotatedString(csvData))
                        Toast.makeText(context, "Trade history CSV copied to clipboard! 📋", Toast.LENGTH_LONG).show()
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = JetBlack),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, BorderColor)
                ) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Export CSV", fontSize = 12.sp, color = TextWhite)
                }

                // Delete Cleared cache button
                Button(
                    onClick = {
                        showClearDialog = true
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = DangerRed.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, DangerRed)
                ) {
                    Icon(imageVector = Icons.Default.DeleteForever, contentDescription = null, tint = DangerRed)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Clear All Data", fontSize = 12.sp, color = DangerRed)
                }
            }
        }
    }

    // Confirmation clear all data dialog
    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("Reset Semua Data?", color = TextWhite, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold) },
            text = { Text("Tindakan ini akan menghapus semua histori trading, saldo demo, pengaturan kustom, blacklist, alarm harga dan menyetel ulang database lokal ke awal. Proses ini tidak dapat dibatalkan.", color = TextMuted, fontSize = 13.sp) },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearAllUserData()
                        showClearDialog = false
                        Toast.makeText(context, "Sistem berhasil disetel ulang! 🧹", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Text("YA, RESET DATA", color = DangerRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) {
                    Text("BATAL", color = TextWhite)
                }
            },
            containerColor = JetBlack,
            shape = RoundedCornerShape(12.dp)
        )
    }
}

// Category container card item
@Composable
fun SettingsCategoryCard(
    title: String,
    icon: ImageVector,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, BorderColor)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 12.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    color = TextWhite
                )
            }
            Divider(color = BorderColor.copy(alpha = 0.5f), thickness = 1.dp, modifier = Modifier.padding(bottom = 14.dp))
            content()
        }
    }
}

// Single Setting with standard interactive Switch toggle
@Composable
fun SettingsToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
            Text(subtitle, fontSize = 11.sp, color = TextMuted)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = SafeGreen,
                checkedTrackColor = SafeGreen.copy(alpha = 0.3f),
                uncheckedThumbColor = TextMuted,
                uncheckedTrackColor = JetBlack,
                uncheckedBorderColor = BorderColor
            )
        )
    }
}

// Horizontal theme select segmented row
@Composable
fun ThemeSelectorRow(
    selected: String,
    onSelect: (String) -> Unit
) {
    val options = listOf("Dark", "Light", "Auto")
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(JetBlack)
            .border(1.dp, BorderColor, RoundedCornerShape(8.dp))
            .padding(2.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        options.forEach { opt ->
            val isSelected = selected == opt
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent)
                    .clickable { onSelect(opt) }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = opt,
                    color = if (isSelected) TextWhite else TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// Standard multi-option segmented controller
@Composable
fun SegmentedControl(
    items: List<String>,
    selected: String,
    onSelect: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(JetBlack)
            .border(1.dp, BorderColor, RoundedCornerShape(8.dp))
            .padding(2.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        items.forEach { item ->
            val isSelected = selected.lowercase() == item.lowercase()
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent)
                    .clickable { onSelect(item) }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = item,
                    color = if (isSelected) TextWhite else TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// Row of colorful dots to let user pick global active theme hex
@Composable
fun AccentColorPickerRow(
    selectedColor: String,
    onSelectColor: (String) -> Unit
) {
    val colors = listOf(
        "#0052FF" to "Blue",
        "#00FF88" to "Green",
        "#7C3AED" to "Purple",
        "#F5A623" to "Orange"
    )

    Row(
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        colors.forEach { (hex, name) ->
            val isSelected = selectedColor.equals(hex, ignoreCase = true)
            val colorVal = Color(android.graphics.Color.parseColor(hex))

            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(colorVal)
                    .border(
                        BorderStroke(
                            2.dp,
                            if (isSelected) TextWhite else Color.Transparent
                        ),
                        CircleShape
                    )
                    .clickable { onSelectColor(hex) },
                contentAlignment = Alignment.Center
            ) {
                if (isSelected) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Selected",
                        tint = if (hex == "#00FF88") JetBlack else TextWhite,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
