package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.graphics.graphicsLayer
import com.example.ui.components.shimmer
import com.example.ui.components.pulse
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SafetyRating
import com.example.data.Token
import com.example.data.UserSettings
import com.example.ui.theme.*
import com.example.utils.Formatters

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BuySellPanel(
    token: Token,
    ethBalance: Double,
    tokenBalance: Double,
    onBuy: (Token, Double, Double) -> Unit,
    onSell: (Token, Double, Double) -> Unit,
    modifier: Modifier = Modifier,
    userSettings: UserSettings = UserSettings()
) {
    var isBuyMode by remember { mutableStateOf(true) }
    var ethInput by remember { mutableStateOf("0.1") }
    var tokenInput by remember { mutableStateOf("") }
    var slippageInput by remember(userSettings.defaultSlippage) { mutableStateOf(userSettings.defaultSlippage.toString()) }
    var riskApproved by remember { mutableStateOf(false) }

    var showConfirmModal by remember { mutableStateOf(false) }
    var pendingTradeType by remember { mutableStateOf("BUY") } // "BUY" or "SELL"
    var pendingValue by remember { mutableStateOf(0.0) }

    val isDanger = token.safetyRating == SafetyRating.DANGER
    val activeSlippage = slippageInput.toDoubleOrNull() ?: 1.0

    fun triggerTrade(type: String, value: Double) {
        if (userSettings.isConfirmBeforeTrade) {
            pendingTradeType = type
            pendingValue = value
            showConfirmModal = true
        } else {
            if (type == "BUY") {
                onBuy(token, value, activeSlippage)
            } else {
                onSell(token, value, activeSlippage)
            }
        }
    }

    // Reset risk approval checkbox when token changes
    LaunchedEffect(token) {
        riskApproved = false
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, BorderColor),
        modifier = modifier
            .fillMaxWidth()
            .testTag("buy_sell_panel")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Mode selectors
            val buyBgColor by animateColorAsState(
                targetValue = if (isBuyMode) SafeGreen.copy(alpha = 0.15f) else Color.Transparent,
                animationSpec = tween(250),
                label = "buyBgColor"
            )
            val buyBorderColor by animateColorAsState(
                targetValue = if (isBuyMode) SafeGreen else Color.Transparent,
                animationSpec = tween(250),
                label = "buyBorderColor"
            )
            val sellBgColor by animateColorAsState(
                targetValue = if (!isBuyMode) DangerRed.copy(alpha = 0.15f) else Color.Transparent,
                animationSpec = tween(250),
                label = "sellBgColor"
            )
            val sellBorderColor by animateColorAsState(
                targetValue = if (!isBuyMode) DangerRed else Color.Transparent,
                animationSpec = tween(250),
                label = "sellBorderColor"
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(JetBlack, RoundedCornerShape(8.dp))
                    .border(1.dp, BorderColor, RoundedCornerShape(8.dp))
                    .padding(2.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(buyBgColor)
                        .border(1.dp, buyBorderColor, RoundedCornerShape(6.dp))
                        .clickable { isBuyMode = true },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "BUY ETH 🟢",
                        color = if (isBuyMode) SafeGreen else TextMuted,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(sellBgColor)
                        .border(1.dp, sellBorderColor, RoundedCornerShape(6.dp))
                        .clickable { isBuyMode = false },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "SELL ${token.symbol} 🔴",
                        color = if (!isBuyMode) DangerRed else TextMuted,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (isBuyMode) {
                // === BUY FLOW LAYOUT ===
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Jumlah ETH", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = "Saldo: ${String.format("%.4f", ethBalance)} ETH",
                        color = SafeGreen,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = ethInput,
                    onValueChange = { ethInput = it },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    placeholder = { Text("0.0", color = TextMuted) },
                    suffix = { Text("ETH", color = TextWhite) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = JetBlack,
                        unfocusedContainerColor = JetBlack,
                        focusedBorderColor = BaseBlue,
                        unfocusedBorderColor = BorderColor,
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // QuickAmountButtons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val quickBuyOptions = userSettings.defaultBuyAmounts
                    quickBuyOptions.forEach { amt ->
                        val interactionAmt = remember { MutableInteractionSource() }
                        val isPressedAmt by interactionAmt.collectIsPressedAsState()
                        val amtScale by animateFloatAsState(
                            targetValue = if (isPressedAmt) 0.90f else 1.0f,
                            animationSpec = spring(dampingRatio = 0.5f, stiffness = 500f),
                            label = "amtScale"
                        )
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(30.dp)
                                .graphicsLayer {
                                    scaleX = amtScale
                                    scaleY = amtScale
                                }
                                .background(CardBg, RoundedCornerShape(4.dp))
                                .border(1.dp, if (isPressedAmt) BaseBlue else BorderColor, RoundedCornerShape(4.dp))
                                .clickable(
                                    interactionSource = interactionAmt,
                                    indication = null,
                                    onClick = { ethInput = amt.toString() }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                labelForAmt(amt),
                                color = TextWhite,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Estimate computations
                val ethAmount = ethInput.toDoubleOrNull() ?: 0.0
                val networkFee = ethAmount * 0.01 // 1% fee
                val actualPurchaseAmount = (ethAmount - networkFee).coerceAtLeast(0.0)
                val tokenEstimate = actualPurchaseAmount / token.priceEth

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(JetBlack, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Estimasi Token Didapat", color = TextMuted, fontSize = 10.sp)
                        Text(
                            text = String.format("%,.2f %s", tokenEstimate, token.symbol),
                            color = SafeGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Platform Fee (1%)", color = TextMuted, fontSize = 10.sp)
                        Text(
                            text = String.format("%.4f ETH", networkFee),
                            color = DangerRed,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

            } else {
                // === SELL FLOW LAYOUT ===
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Jumlah ${token.symbol}", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = "Saldo: ${String.format("%,.2f", tokenBalance)} ${token.symbol}",
                        color = SafeGreen,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = tokenInput,
                    onValueChange = { tokenInput = it },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    placeholder = { Text("0.0", color = TextMuted) },
                    suffix = { Text(token.symbol, color = TextWhite) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = JetBlack,
                        unfocusedContainerColor = JetBlack,
                        focusedBorderColor = BaseBlue,
                        unfocusedBorderColor = BorderColor,
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Quick fractional buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val percentOptions = listOf(25, 50, 75, 100)
                    percentOptions.forEach { pct ->
                        val interactionPct = remember { MutableInteractionSource() }
                        val isPressedPct by interactionPct.collectIsPressedAsState()
                        val pctScale by animateFloatAsState(
                            targetValue = if (isPressedPct) 0.90f else 1.0f,
                            animationSpec = spring(dampingRatio = 0.5f, stiffness = 500f),
                            label = "pctScale"
                        )
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(30.dp)
                                .graphicsLayer {
                                    scaleX = pctScale
                                    scaleY = pctScale
                                }
                                .background(CardBg, RoundedCornerShape(4.dp))
                                .border(1.dp, if (isPressedPct) BaseBlue else BorderColor, RoundedCornerShape(4.dp))
                                .clickable(
                                    interactionSource = interactionPct,
                                    indication = null,
                                    onClick = {
                                        val factor = pct / 100.0
                                        tokenInput = (tokenBalance * factor).toString()
                                    }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "$pct%",
                                color = TextWhite,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Estimate return computations
                val sellAmount = tokenInput.toDoubleOrNull() ?: 0.0
                val returnEthUnchecked = sellAmount * token.priceEth
                val platformFee = returnEthUnchecked * 0.01
                val returnEthFinal = (returnEthUnchecked - platformFee).coerceAtLeast(0.0)

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(JetBlack, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Estimasi ETH Didapat (Uniswap)", color = TextMuted, fontSize = 10.sp)
                        Text(
                            text = String.format("%.4f ETH", returnEthFinal),
                            color = SafeGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Platform Fee (1%)", color = TextMuted, fontSize = 10.sp)
                        Text(
                            text = String.format("%.4f ETH", platformFee),
                            color = DangerRed,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Slippage configs
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Slippage Tolerance", color = TextMuted, fontSize = 10.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("0.5", "1.0", "3.0").forEach { slips ->
                        val active = slippageInput == slips
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(3.dp))
                                .background(if (active) BaseBlue.copy(alpha = 0.2f) else JetBlack)
                                .border(0.5.dp, if (active) BaseBlue else BorderColor, RoundedCornerShape(3.dp))
                                .clickable { slippageInput = slips }
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                "$slips%",
                                color = if (active) BaseBlue else TextWhite,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Danger Lock Overlay check
            if (isBuyMode && isDanger) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0x18FF3B3B), RoundedCornerShape(6.dp))
                        .border(1.dp, DangerRed.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                        .padding(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = DangerRed, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            "KONTRAK BERBAHAYA / SUSPICIOUS HONEYPOT",
                            color = DangerRed,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "Dideteksi sebagai honeypot atau memiliki fungsi mint tak terbatas. Hububungi dev / bypass resiko jika yakin.",
                        color = TextMuted,
                        fontSize = 9.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = riskApproved,
                            onCheckedChange = { riskApproved = it },
                            colors = CheckboxDefaults.colors(
                                checkedColor = DangerRed,
                                uncheckedColor = TextMuted
                            )
                        )
                        Text(
                            "Saya mengerti risikonya",
                            color = TextWhite,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { riskApproved = !riskApproved }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // ORDER EXEC BUTTONS
            val buyVal = ethInput.toDoubleOrNull() ?: 0.0
            val sellVal = tokenInput.toDoubleOrNull() ?: 0.0

            val interactionBuy = remember { MutableInteractionSource() }
            val isPressedBuy by interactionBuy.collectIsPressedAsState()
            val buyButtonScale by animateFloatAsState(
                targetValue = if (isPressedBuy) 0.97f else 1.01f, // subtle hover-up scale
                animationSpec = spring(stiffness = 300f),
                label = "buyButtonScale"
            )

            val interactionSell = remember { MutableInteractionSource() }
            val isPressedSell by interactionSell.collectIsPressedAsState()
            val sellButtonScale by animateFloatAsState(
                targetValue = if (isPressedSell) 0.97f else 1.01f,
                animationSpec = spring(stiffness = 300f),
                label = "sellButtonScale"
            )

            if (isBuyMode) {
                val buttonEnabled = !isDanger || riskApproved
                Button(
                    onClick = { triggerTrade("BUY", buyVal) },
                    enabled = buttonEnabled && buyVal > 0 && buyVal <= ethBalance,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isDanger) DangerRed else SafeGreen,
                        disabledContainerColor = BorderColor,
                        contentColor = TextWhite,
                        disabledContentColor = TextMuted
                    ),
                    shape = RoundedCornerShape(8.dp),
                    interactionSource = interactionBuy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .graphicsLayer {
                            scaleX = buyButtonScale
                            scaleY = buyButtonScale
                        }
                        .testTag("buy_button")
                ) {
                    Text(
                        text = if (isDanger && !riskApproved) "TOKEN BERBAHAYA ⚠️" else "BUY TOKEN 🚀",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            } else {
                Button(
                    onClick = { triggerTrade("SELL", sellVal) },
                    enabled = sellVal > 0 && sellVal <= tokenBalance,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DangerRed,
                        disabledContainerColor = BorderColor,
                        contentColor = TextWhite,
                        disabledContentColor = TextMuted
                    ),
                    shape = RoundedCornerShape(8.dp),
                    interactionSource = interactionSell,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .graphicsLayer {
                            scaleX = sellButtonScale
                            scaleY = sellButtonScale
                        }
                        .testTag("sell_button")
                ) {
                    Text(
                        text = "SELL TOKEN 💥",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Confirm Trade Modal Dialog
            if (showConfirmModal) {
                AlertDialog(
                    onDismissRequest = { showConfirmModal = false },
                    title = { Text(if (pendingTradeType == "BUY") "Konfirmasi Pembelian" else "Konfirmasi Penjualan", color = TextWhite, fontWeight = FontWeight.Bold) },
                    text = {
                        Text(
                            if (pendingTradeType == "BUY") {
                                "Apakah Anda yakin ingin membeli token ${token.symbol} seharga ${String.format("%.4f", pendingValue)} ETH?"
                            } else {
                                "Apakah Anda yakin ingin menjual ${String.format("%,.2f", pendingValue)} ${token.symbol}?"
                            },
                            color = TextMuted,
                            fontSize = 13.sp
                        )
                    },
                    confirmButton = {
                        TextButton(
                            onClick = {
                                showConfirmModal = false
                                if (pendingTradeType == "BUY") {
                                    onBuy(token, pendingValue, activeSlippage)
                                } else {
                                    onSell(token, pendingValue, activeSlippage)
                                }
                            }
                        ) {
                            Text("KONFIRMASI", color = if (pendingTradeType == "BUY") SafeGreen else DangerRed, fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showConfirmModal = false }) {
                            Text("BATAL", color = TextWhite)
                        }
                    },
                    containerColor = JetBlack,
                    shape = RoundedCornerShape(12.dp)
                )
            }
        }
    }
}

private fun labelForAmt(amt: Double): String {
    return if (amt < 0.1) String.format("%.2f", amt) else String.format("%.1f", amt)
}
