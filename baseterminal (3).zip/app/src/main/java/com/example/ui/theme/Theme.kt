package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.example.data.UserSettings

private val DarkColorScheme =
  darkColorScheme(
    primary = BaseBlue,
    secondary = SafeGreen,
    tertiary = WarningYellow,
    background = DarkBg,
    surface = CardBg,
    onPrimary = TextWhite,
    onSecondary = DarkBg,
    onBackground = TextWhite,
    onSurface = TextWhite,
    outline = BorderColor,
    error = DangerRed
  )

@Composable
fun MyApplicationTheme(
  userSettings: UserSettings = UserSettings(),
  content: @Composable () -> Unit,
) {
  val darkTheme = when (userSettings.theme) {
      "Light" -> false
      "Dark" -> true
      else -> isSystemInDarkTheme() // "Auto" default
  }

  val accentColor = try {
      Color(android.graphics.Color.parseColor(userSettings.accentColor))
  } catch (e: Exception) {
      BaseBlue
  }

  val colorScheme = if (darkTheme) {
      darkColorScheme(
          primary = accentColor,
          secondary = SafeGreen,
          tertiary = WarningYellow,
          background = DarkBg,
          surface = CardBg,
          onPrimary = TextWhite,
          onSecondary = DarkBg,
          onBackground = TextWhite,
          onSurface = TextWhite,
          outline = BorderColor,
          error = DangerRed
      )
  } else {
      lightColorScheme(
          primary = accentColor,
          secondary = SafeGreen,
          tertiary = WarningYellow,
          background = Color(0xFFF5F5F7),
          surface = Color(0xFFFFFFFF),
          onPrimary = Color.White,
          onSecondary = Color.Black,
          onBackground = Color.Black,
          onSurface = Color.Black,
          outline = Color(0xFFE5E5EA),
          error = DangerRed
      )
  }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
