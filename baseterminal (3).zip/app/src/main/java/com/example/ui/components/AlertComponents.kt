package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAlert
import androidx.compose.material.icons.filled.AlarmOn
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.PriceAlert
import com.example.data.Token
import com.example.ui.theme.*
import com.example.utils.Formatters

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PriceAlertModal(
    token: Token,
    isOpen: Boolean,
    onClose: () -> Unit,
    onSave: (Token, Double, Boolean) -> Unit
) {
    if (!isOpen) return

    var targetInput by remember { mutableStateOf(String.format(java.util.Locale.US, "%.4f", token.priceUsd * 1.1)) }
    var isAbove by remember { mutableStateOf(true) }

    Dialog(onDismissRequest = onClose) {
        Card(
            colors = CardDefaults.cardColors(containerColor = CardBg),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, BorderColor),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("price_alert_modal")
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.AddAlert, contentDescription = null, tint = BaseBlue)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "Set Price Alert: ${token.symbol}",
                        color = TextWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("Harga Saat Ini", color = TextMuted, fontSize = 10.sp)
                Text(
                    text = Formatters.formatUsd(token.priceUsd),
                    color = SafeGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Alert Trigger Toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(JetBlack, RoundedCornerShape(8.dp))
                        .border(1.dp, BorderColor, RoundedCornerShape(8.dp))
                        .padding(2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isAbove) BaseBlue.copy(alpha = 0.15f) else Color.Transparent)
                            .border(1.dp, if (isAbove) BaseBlue else Color.Transparent, RoundedCornerShape(6.dp))
                            .clickable { isAbove = true },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "ABOVE 📈",
                            color = if (isAbove) BaseBlue else TextMuted,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (!isAbove) DangerRed.copy(alpha = 0.15f) else Color.Transparent)
                            .border(1.dp, if (!isAbove) DangerRed else Color.Transparent, RoundedCornerShape(6.dp))
                            .clickable { isAbove = false },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "BELOW 📉",
                            color = if (!isAbove) DangerRed else TextMuted,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("Target Price (USD)", color = TextMuted, fontSize = 10.sp)
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = targetInput,
                    onValueChange = { targetInput = it },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = JetBlack,
                        unfocusedContainerColor = JetBlack,
                        focusedBorderColor = BaseBlue,
                        unfocusedBorderColor = BorderColor,
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onClose,
                        colors = ButtonDefaults.buttonColors(containerColor = JetBlack, contentColor = TextMuted),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, BorderColor, RoundedCornerShape(6.dp))
                    ) {
                        Text("Batal", fontSize = 12.sp)
                    }

                    val targetVal = targetInput.toDoubleOrNull() ?: 0.0
                    Button(
                        onClick = {
                            onSave(token, targetVal, isAbove)
                            onClose()
                        },
                        enabled = targetVal > 0.0,
                        colors = ButtonDefaults.buttonColors(containerColor = BaseBlue, contentColor = TextWhite),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Simpan Alert", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AlertList(
    alerts: List<PriceAlert>,
    onDelete: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    if (alerts.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "Belum ada alarm harga aktif.",
                color = TextMuted,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
        return
    }

    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(alerts) { alert ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(JetBlack, RoundedCornerShape(6.dp))
                    .border(1.dp, BorderColor, RoundedCornerShape(6.dp))
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (alert.isTriggered) Icons.Default.CheckCircle else Icons.Default.AlarmOn,
                    contentDescription = null,
                    tint = if (alert.isTriggered) SafeGreen else if (alert.isAbove) BaseBlue else DangerRed,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = alert.tokenSymbol,
                            color = TextWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(3.dp))
                                .background(if (alert.isAbove) BaseBlue.copy(alpha = 0.15f) else DangerRed.copy(alpha = 0.15f))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = if (alert.isAbove) "GOES ABOVE" else "GOES BELOW",
                                color = if (alert.isAbove) BaseBlue else DangerRed,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Target: " + Formatters.formatUsd(alert.targetPriceUsd),
                        color = TextWhite,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    if (alert.isTriggered) {
                        Text(
                            text = "Triggered di: " + Formatters.formatUsd(alert.triggeredPrice) + " (" + Formatters.formatDateTime(alert.triggerTime) + ")",
                            color = SafeGreen,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
                IconButton(onClick = { onDelete(alert.id) }) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Hapus",
                        tint = TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
