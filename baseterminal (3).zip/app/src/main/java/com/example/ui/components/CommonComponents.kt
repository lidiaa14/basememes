package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.with
import androidx.compose.animation.core.*
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.PriceAlert
import com.example.data.SafetyRating
import com.example.data.Token
import com.example.ui.theme.*
import com.example.ui.viewmodel.TxState
import com.example.utils.Formatters
import kotlinx.coroutines.delay

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PriceTicker(
    tokens: List<Token>,
    onTokenClick: (Token) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(JetBlack)
            .border(1.dp, BorderColor)
            .padding(vertical = 6.dp)
            .basicMarquee(
                iterations = Int.MAX_VALUE,
                velocity = 40.dp
            ),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Take top 10 tokens for marquee
        val displayTokens = tokens.take(10)
        // Repeat display tokens to smooth loop
        (displayTokens + displayTokens + displayTokens).forEach { token ->
            val isUp = token.priceChangePercent24h >= 0
            Row(
                modifier = Modifier
                    .padding(horizontal = 16.dp)
                    .clickable { onTokenClick(token) },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = token.symbol,
                    color = TextWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(end = 6.dp)
                )
                Text(
                    text = Formatters.formatUsd(token.priceUsd),
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(end = 4.dp)
                )
                Icon(
                    imageVector = if (isUp) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                    contentDescription = null,
                    tint = if (isUp) SafeGreen else DangerRed,
                    modifier = Modifier.size(12.dp)
                )
                Text(
                    text = String.format("%.2f%%", token.priceChangePercent24h),
                    color = if (isUp) SafeGreen else DangerRed,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .size(3.dp)
                    .background(BorderColor, CircleShape)
            )
        }
    }
}

@Composable
fun TokenSafetyBadge(
    rating: SafetyRating,
    modifier: Modifier = Modifier
) {
    val (label, containerColor, textColor, icon) = when (rating) {
        SafetyRating.SAFE -> Quadruple("SAFE", TradingGreenDim, SafeGreen, Icons.Default.CheckCircle)
        SafetyRating.WARNING -> Quadruple("WARNING", Color(0x20F5A623), WarningYellow, Icons.Default.Warning)
        SafetyRating.DANGER -> Quadruple("DANGER", TradingRedDim, DangerRed, Icons.Default.Error)
    }

    val badgeModifier = if (rating == SafetyRating.DANGER) {
        modifier.pulse()
    } else {
        modifier
    }

    Row(
        modifier = badgeModifier
            .clip(RoundedCornerShape(4.dp))
            .background(containerColor)
            .border(0.5.dp, textColor.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = textColor,
            modifier = Modifier.size(12.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            color = textColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun PnLBadge(
    pnlUsd: Double,
    isPercentage: Boolean = false,
    modifier: Modifier = Modifier
) {
    val isProfit = pnlUsd >= 0
    val text = if (isPercentage) {
        java.lang.String.format(java.util.Locale.US, "%+.2f%%", pnlUsd)
    } else {
        if (pnlUsd >= 0.0) {
            "+$" + java.lang.String.format(java.util.Locale.US, "%,.2f", pnlUsd)
        } else {
            "-$" + java.lang.String.format(java.util.Locale.US, "%,.2f", -pnlUsd)
        }
    }
    val color = if (isProfit) SafeGreen else DangerRed
    val dimBg = if (isProfit) TradingGreenDim else TradingRedDim

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(dimBg)
            .border(0.5.dp, color.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = text,
            color = color,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun ConnectWallet(
    walletAddress: String,
    ethBalance: Double,
    modifier: Modifier = Modifier
) {
    val clipboardManager = LocalClipboardManager.current
    val short = Formatters.shortenAddress(walletAddress)

    Card(
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, BorderColor),
        modifier = modifier.testTag("connect_wallet")
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Wallet,
                contentDescription = "Wallet",
                tint = BaseBlue,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable {
                        clipboardManager.setText(AnnotatedString(walletAddress))
                    }
                ) {
                    Text(
                        text = short,
                        color = TextWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy",
                        tint = TextMuted,
                        modifier = Modifier.size(10.dp)
                    )
                }
                Text(
                    text = String.format("%.4f ETH", ethBalance),
                    color = SafeGreen,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun TransactionToast(
    txState: TxState,
    onDismiss: () -> Unit
) {
    var isPaused by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(1f) }

    LaunchedEffect(txState) {
        if (txState !is TxState.Idle) {
            progress = 1f
            val totalTime = 4000L
            val interval = 50L
            val step = interval.toFloat() / totalTime
            while (progress > 0f) {
                delay(interval)
                if (!isPaused) {
                    progress = (progress - step).coerceAtLeast(0f)
                }
            }
            onDismiss()
        }
    }

    AnimatedVisibility(
        visible = txState !is TxState.Idle,
        enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(16.dp)
            .testTag("transaction_toast")
    ) {
        val (bgColor, icon, tintColor, titleText, descText) = when (txState) {
            is TxState.Pending -> Quintuple(
                CardBg,
                Icons.Default.HourglassEmpty,
                WarningYellow,
                "MEMPROSES TRANSAKSI ⏳",
                txState.msg
            )
            is TxState.Success -> Quintuple(
                CardBg,
                Icons.Default.CheckCircle,
                SafeGreen,
                "TRANSAKSI BERHASIL! ✅",
                txState.msg + "\nTX: " + Formatters.shortenAddress(txState.txHash)
            )
            is TxState.Error -> Quintuple(
                CardBg,
                Icons.Default.Error,
                DangerRed,
                "TRANSAKSI GAGAL ❌",
                txState.msg
            )
            else -> Quintuple(CardBg, Icons.Default.Error, DangerRed, "", "")
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(bgColor)
                .border(1.dp, tintColor.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                .pointerInput(Unit) {
                    awaitPointerEventScope {
                        while (true) {
                            val event = awaitPointerEvent()
                            // Pause progress countdown when screen is touched/pressed
                            isPaused = event.changes.any { it.pressed }
                        }
                    }
                }
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = tintColor,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = titleText,
                        color = tintColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = descText,
                        color = TextWhite,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Tutup",
                        tint = TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp),
                color = tintColor,
                trackColor = Color.Transparent
            )
        }
    }
}

// PREMIUM EXQUISITE SHIMMER MODIFIER FOR LOADING SKELETONS
fun Modifier.shimmer(): Modifier = this.composed {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val translateAnim = transition.animateFloat(
        initialValue = -1000f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmerTranslate"
    )

    val shimmerColors = listOf(
        Color(0xFF161616),
        Color(0xFF2E2E2E),
        Color(0xFF161616),
    )

    val brush = Brush.linearGradient(
        colors = shimmerColors,
        start = Offset(translateAnim.value - 200f, translateAnim.value - 200f),
        end = Offset(translateAnim.value + 200f, translateAnim.value + 200f)
    )

    this.then(Modifier.background(brush))
}

// PREMIUM EXQUISITE PULSING MODIFIER FOR DECORATIVE OR DANGER BADGES
fun Modifier.pulse(
    initialValue: Float = 0.95f,
    targetValue: Float = 1.05f,
    duration: Int = 800
): Modifier = this.composed {
    val transition = rememberInfiniteTransition(label = "pulse")
    val scale by transition.animateFloat(
        initialValue = initialValue,
        targetValue = targetValue,
        animationSpec = infiniteRepeatable(
            animation = tween(duration, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )
    this.then(Modifier.graphicsLayer {
        scaleX = scale
        scaleY = scale
    })
}

// PREMIUM SLIDING ANIMATED CHARACTER PRICE COUNTER
@OptIn(ExperimentalAnimationApi::class)
@Composable
fun AnimatedPriceText(
    priceText: String,
    isUp: Boolean,
    modifier: Modifier = Modifier,
    color: Color = TextWhite,
    fontSize: androidx.compose.ui.unit.TextUnit = 12.sp,
    fontWeight: FontWeight = FontWeight.Bold,
    fontFamily: FontFamily = FontFamily.Monospace
) {
    AnimatedContent(
        targetState = priceText,
        transitionSpec = {
            if (isUp) {
                slideInVertically(initialOffsetY = { it }) + fadeIn() with
                        slideOutVertically(targetOffsetY = { -it }) + fadeOut()
            } else {
                slideInVertically(initialOffsetY = { -it }) + fadeIn() with
                        slideOutVertically(targetOffsetY = { it }) + fadeOut()
            }
        },
        label = "PriceAnimText"
    ) { targetText ->
        Text(
            text = targetText,
            color = color,
            fontSize = fontSize,
            fontWeight = fontWeight,
            fontFamily = fontFamily,
            modifier = modifier
        )
    }
}

// Helper generic data holder classes
data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
data class Quintuple<A, B, C, D, E>(val first: A, val second: B, val third: C, val fourth: D, val fifth: E)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LiveFeedTicker(
    tokens: List<Token>,
    onDismiss: () -> Unit,
    onTokenClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    if (tokens.isEmpty()) return
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFF0F141C))
            .border(1.dp, BorderColor)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier
                .weight(1f)
                .basicMarquee(iterations = Int.MAX_VALUE, velocity = 40.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val scrollList = tokens + tokens + tokens
            scrollList.forEach { token ->
                val now = System.currentTimeMillis()
                val ageMs = now - token.creationTimeMills
                val ageSecs = (ageMs / 1000L).coerceAtLeast(0L)
                val ageText = if (ageSecs < 60) "${ageSecs}s ago" else "${ageSecs / 1000 / 60}m ago"
                Row(
                    modifier = Modifier
                        .clickable { onTokenClick(token.address) }
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🚀 ${token.name} launched",
                        color = Color(0xFF00FF88),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "• \$${Formatters.formatNumberCompact(token.liquidityUsd)} liq",
                        color = TextWhite,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "• $ageText",
                        color = TextMuted,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Box(
                    modifier = Modifier
                        .size(3.dp)
                        .background(BorderColor, CircleShape)
                )
            }
        }
        
        IconButton(
            onClick = onDismiss,
            modifier = Modifier.size(24.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Dismiss",
                tint = TextMuted,
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

@Composable
fun JustLaunchedCard(
    token: Token,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val now = System.currentTimeMillis()
    val ageMs = now - token.creationTimeMills
    val ageMins = ageMs / 60000L
    val ageSecs = ageMs / 1000L

    val ageStr = if (ageSecs < 60) {
        "Just now"
    } else {
        "${ageMins} mins ago"
    }

    val infiniteTransition = rememberInfiniteTransition(label = "badge_flash")
    val alphaAnim by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "flash"
    )

    Card(
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, BorderColor),
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("just_launched_card_${token.address}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(BaseBlue.copy(alpha = 0.15f), CircleShape)
                        .border(1.dp, BaseBlue.copy(alpha = 0.4f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = token.symbol.take(1),
                        color = BaseBlue,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = token.name,
                            color = TextWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = token.symbol,
                            color = TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .pulse(0.4f, 1.1f, 600)
                                .background(Color.Red, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "LIVE • $ageStr",
                            color = SafeGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.padding(horizontal = 4.dp)
            ) {
                if (ageMins < 5) {
                    Box(
                        modifier = Modifier
                            .graphicsLayer { alpha = alphaAnim }
                            .clip(RoundedCornerShape(4.dp))
                            .background(OrangeAccent.copy(alpha = 0.2f))
                            .border(1.dp, OrangeAccent, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "🆕 NEW",
                            color = OrangeAccent,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                TokenSafetyBadge(token.safetyRating)
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = Formatters.formatUsd(token.priceUsd),
                    color = TextWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Liq: \$${Formatters.formatNumberCompact(token.liquidityUsd)}",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
