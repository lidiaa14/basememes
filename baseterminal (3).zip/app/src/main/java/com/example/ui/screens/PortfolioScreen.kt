package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.ui.graphics.graphicsLayer
import com.example.ui.components.shimmer
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TradeHistoryItem
import com.example.data.UserSettings
import com.example.ui.components.LineChart
import com.example.ui.components.PnLBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.TradingViewModel
import com.example.utils.Formatters
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PortfolioScreen(
    viewModel: TradingViewModel,
    onTokenNavigate: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()

    val tokens by viewModel.tokens.collectAsState()
    val holdings by viewModel.holdings.collectAsState()
    val tradeHistory by viewModel.tradeHistory.collectAsState()
    val snapshots by viewModel.portfolioSnapshots.collectAsState()
    val ethBalance by viewModel.ethBalance.collectAsState()
    val userSettings by viewModel.userSettings.collectAsState()

    val rawTotals = remember(holdings, tradeHistory, tokens, ethBalance) { viewModel.getPortfolioTotals() }

    var animationProgress by remember { mutableStateOf(0f) }
    LaunchedEffect(Unit) {
        animate(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing)
        ) { value, _ ->
            animationProgress = value
        }
    }

    val totals = remember(rawTotals, animationProgress) {
        com.example.ui.viewmodel.PortfolioMetrics(
            totalValueEth = rawTotals.totalValueEth * animationProgress,
            totalValueUsd = rawTotals.totalValueUsd * animationProgress,
            realizedPnlUsd = rawTotals.realizedPnlUsd * animationProgress,
            unrealizedPnlUsd = rawTotals.unrealizedPnlUsd * animationProgress,
            totalTrades = (rawTotals.totalTrades * animationProgress).toInt(),
            winRate = rawTotals.winRate * animationProgress,
            tradingVolumeEth = rawTotals.tradingVolumeEth * animationProgress
        )
    }

    var filterState by remember { mutableStateOf(0) } // 0 = All, 1 = Buy, 2 = Sell
    var isExporting by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("portfolio_screen")
    ) {
        Text(
            text = "DASHBOARD PORTFOLIO",
            color = BaseBlue,
            fontWeight = FontWeight.Black,
            fontSize = 18.sp,
            letterSpacing = 0.5.sp
        )
        Text(
            text = "Statistik performa dan posisi terbuka",
            color = TextMuted,
            fontSize = 11.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        // HEADER VALUE CARDS GRID
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, BorderColor),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("TOTAL NET WORTH", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(4.dp))
                    if (userSettings.currencyDisplay == "ETH") {
                        Text(
                            text = String.format("%.4f ETH", totals.totalValueEth),
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = Formatters.formatUsd(totals.totalValueUsd),
                            color = BaseBlue,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    } else {
                        Text(
                            text = Formatters.formatUsd(totals.totalValueUsd),
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = String.format("%.4f ETH", totals.totalValueEth),
                            color = BaseBlue,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, BorderColor),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("UNREALIZED PNL", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(4.dp))
                    PnLBadge(pnlUsd = totals.unrealizedPnlUsd)
                    Spacer(modifier = Modifier.height(4.dp))
                    val realizedPnlFormatted = if (totals.realizedPnlUsd >= 0.0) {
                        "+$" + java.lang.String.format(java.util.Locale.US, "%,.2f", totals.realizedPnlUsd)
                    } else {
                        "-$" + java.lang.String.format(java.util.Locale.US, "%,.2f", -totals.realizedPnlUsd)
                    }
                    Text("Realized: $realizedPnlFormatted", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricsMiniCard(label = "WIN RATE", value = String.format("%.1f%%", totals.winRate), color = SafeGreen, modifier = Modifier.weight(1f))
            MetricsMiniCard(label = "TOTAL VOLUME", value = String.format("%.2f ETH", totals.tradingVolumeEth), color = BaseBlue, modifier = Modifier.weight(1f))
            MetricsMiniCard(label = "TOTAL TRADES", value = String.format("%d", totals.totalTrades), color = TextWhite, modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(20.dp))

        // HISTORICAL NETWORTH GRAPH
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.ShowChart, contentDescription = null, tint = BaseBlue, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("HISTORIS PORTOFOLIO (NETWORTH)", color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
            Text("PRO-TIMEFRAME", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }

        Spacer(modifier = Modifier.height(10.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        ) {
            val chartPointsUsd = remember(snapshots) { snapshots.map { it.valueUsd } }
            val chartTimes = remember(snapshots) { snapshots.map { it.timestamp } }
            LineChart(
                pointsUsd = chartPointsUsd,
                timestamps = chartTimes,
                modifier = Modifier.fillMaxSize(),
                animationProgress = animationProgress
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // ACTIVE POSITIONS LIST
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = Icons.Default.PieChart, contentDescription = null, tint = SafeGreen, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("ASET YANG DIMILIKI (HOLDINGS)", color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Map holdings list
        val isEthVisible = if (userSettings.isHideSmallBalances) {
            (ethBalance * 3000.0) >= 1.0
        } else {
            true
        }
        val visibleHoldings = holdings.filter { (address, amount) ->
            val token = tokens.firstOrNull { it.address.lowercase() == address.lowercase() }
            if (token != null) {
                val valueUsd = amount * token.priceUsd
                !userSettings.isHideSmallBalances || valueUsd >= 1.0
            } else {
                false
            }
        }

        if (!isEthVisible && visibleHoldings.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(JetBlack, RoundedCornerShape(8.dp))
                    .border(1.dp, BorderColor, RoundedCornerShape(8.dp))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Belum ada posisi terbuka. Beli token di menu Trade!", color = TextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // ETH Balance asset card
                if (isEthVisible) {
                    HoldingsCard(
                        symbol = "WETH / ETH",
                        name = "Ethereum Mainnet Coin",
                        amount = ethBalance,
                        priceUsd = 3000.0,
                        valueUsd = ethBalance * 3000.0,
                        pnlPercentage = 0.0,
                        onClick = {},
                        userSettings = userSettings
                    )
                }

                visibleHoldings.forEach { (address, amount) ->
                    val token = tokens.firstOrNull { it.address.lowercase() == address.lowercase() }
                    if (token != null) {
                        val valueUsd = amount * token.priceUsd
                        // Simulated average cost offset
                        val pnlEst = (token.priceChangePercent24h * 0.4)
                        HoldingsCard(
                            symbol = token.symbol,
                            name = token.name,
                            amount = amount,
                            priceUsd = token.priceUsd,
                            valueUsd = valueUsd,
                            pnlPercentage = pnlEst,
                            onClick = { onTokenNavigate(token.address) },
                            userSettings = userSettings
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // TRADE HISTORY ACTION LOGS
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.History, contentDescription = null, tint = BaseBlue, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("HISTORY TRANSAKSI", color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }

            // Export CSV Button
            Button(
                onClick = {
                    coroutineScope.launch {
                        isExporting = true
                        delay(1500L) // simulation export
                        isExporting = false
                    }
                },
                enabled = !isExporting,
                colors = ButtonDefaults.buttonColors(containerColor = JetBlack, contentColor = BaseBlue),
                shape = RoundedCornerShape(4.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                modifier = Modifier
                    .height(28.dp)
                    .border(1.dp, BorderColor, RoundedCornerShape(4.dp))
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Download, contentDescription = null, tint = BaseBlue, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (isExporting) "EXPORTING..." else "EXPORT CSV", fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }

        // CSV toast notify
        if (isExporting) {
            Text(
                "Mengekspor semua riwayat perdagangan Anda ke CSV file... Selesai! Disimpan ke direktori Download.",
                color = SafeGreen,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 10.dp)
            )
        }

        // Sub categories filters
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("ALL", "BUY", "SELL").forEachIndexed { idx, label ->
                val isSelected = filterState == idx
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelected) BaseBlue.copy(alpha = 0.2f) else JetBlack)
                        .border(1.dp, if (isSelected) BaseBlue else BorderColor, RoundedCornerShape(4.dp))
                        .clickable { filterState = idx }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(text = label, color = if (isSelected) BaseBlue else TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }

        // Transactions list view
        val filteredHistory = remember(tradeHistory, filterState) {
            when (filterState) {
                1 -> tradeHistory.filter { it.isBuy }
                2 -> tradeHistory.filter { !it.isBuy }
                else -> tradeHistory
            }
        }

        if (filteredHistory.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(JetBlack, RoundedCornerShape(8.dp))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Tidak ditemukan log transaksi", color = TextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                filteredHistory.forEach { tx ->
                    HistoryItemWidget(tx = tx, userSettings = userSettings)
                }
            }
        }
    }
}

@Composable
fun MetricsMiniCard(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, BorderColor),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text(label, color = TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
fun HoldingsCard(
    symbol: String,
    name: String,
    amount: Double,
    priceUsd: Double,
    valueUsd: Double,
    pnlPercentage: Double,
    onClick: () -> Unit,
    userSettings: UserSettings = UserSettings()
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, BorderColor),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Circle letter profile
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .background(BaseBlue.copy(alpha = 0.1f), CircleShape)
                    .border(1.dp, BaseBlue.copy(alpha = 0.4f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(symbol.take(2), color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }

            Spacer(modifier = Modifier.width(12.dp))

            val displayPriceString = if (userSettings.currencyDisplay == "ETH") {
                val priceEth = if (symbol.contains("WETH") || symbol.contains("ETH")) 1.0 else priceUsd / 3000.0
                String.format("%.6f ETH", priceEth)
            } else {
                Formatters.formatUsd(priceUsd)
            }

            val displayValueString = if (userSettings.currencyDisplay == "ETH") {
                val valueEth = if (symbol.contains("WETH") || symbol.contains("ETH")) amount else valueUsd / 3000.0
                String.format("%.4f ETH", valueEth)
            } else {
                Formatters.formatUsd(valueUsd)
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(symbol, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                Text(text = "Price: $displayPriceString", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }

            Column(
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = String.format("%.4f", amount),
                    color = TextWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = displayValueString,
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            if (pnlPercentage != 0.0) {
                PnLBadge(pnlUsd = pnlPercentage, isPercentage = true)
            } else {
                Box(modifier = Modifier.width(52.dp)) // empty align filler
            }
        }
    }
}

@Composable
fun HistoryItemWidget(tx: TradeHistoryItem, userSettings: UserSettings = UserSettings()) {
    Card(
        colors = CardDefaults.cardColors(containerColor = JetBlack),
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, BorderColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(if (tx.isBuy) TradingGreenDim else TradingRedDim)
                    .padding(horizontal = 6.dp, vertical = 3.dp)
            ) {
                Text(
                    text = if (tx.isBuy) "BUY" else "SELL",
                    color = if (tx.isBuy) SafeGreen else DangerRed,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            val sdf = if (userSettings.timeFormat == "12H") {
                SimpleDateFormat("MMM dd, yyyy - hh:mm a", Locale.US)
            } else {
                SimpleDateFormat("MMM dd, yyyy - HH:mm", Locale.US)
            }
            val timeLabel = sdf.format(Date(tx.timestamp))

            Column(modifier = Modifier.weight(1f)) {
                Text(tx.tokenSymbol, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(timeLabel, color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = String.format("%.4f ETH", tx.ethAmount),
                    color = if (tx.isBuy) SafeGreen else OrangeDecimal,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = String.format("%,.1f Token", tx.tokenAmount),
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

private val OrangeDecimal = Color(0xFFFF9800)
