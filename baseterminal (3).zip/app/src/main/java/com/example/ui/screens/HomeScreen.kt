package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.delay
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.FiberNew
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SafetyRating
import com.example.data.Token
import com.example.data.UserSettings
import com.example.ui.components.ConnectWallet
import com.example.ui.components.PriceTicker
import com.example.ui.components.TokenSafetyBadge
import com.example.ui.components.AnimatedPriceText
import com.example.ui.components.LiveFeedTicker
import com.example.ui.components.JustLaunchedCard
import com.example.ui.components.pulse
import androidx.compose.foundation.horizontalScroll
import com.example.ui.theme.*
import com.example.ui.viewmodel.TradingViewModel
import com.example.utils.Formatters

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: TradingViewModel,
    onTokenNavigate: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens by viewModel.tokens.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()
    val isSearching by viewModel.isSearching.collectAsState()
    val ethBalance by viewModel.ethBalance.collectAsState()
    val walletAddress by viewModel.walletAddress.collectAsState()
    val userSettings by viewModel.userSettings.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var showAutocomplete by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf(0) }

    // Real-time Popup for Auto-Detected New Token launches
    var activeAlertToken by remember { mutableStateOf<Token?>(null) }

    LaunchedEffect(Unit) {
        viewModel.newLaunchAlertFlow.collect { token ->
            activeAlertToken = token
        }
    }

    val recentSearches = remember { viewModel.getRecentSearches() }

    // Filter out dangerous tokens if option is enabled
    val visibleTokens = remember(tokens, userSettings.isHideDangerousTokens) {
        if (userSettings.isHideDangerousTokens) {
            tokens.filter { it.safetyRating != SafetyRating.DANGER }
        } else {
            tokens
        }
    }

    // Categorized streams
    val trendingTokens = remember(visibleTokens) {
        visibleTokens.sortedByDescending { it.volume24hUsd }.take(6)
    }
    val newListings = remember(visibleTokens) {
        visibleTokens.filter { it.pairAgeHours < 48.0 }.take(6)
    }
    val topGainers = remember(visibleTokens) {
        visibleTokens.sortedByDescending { it.priceChangePercent24h }.take(6)
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
    ) {
        // top marquee ticker
        PriceTicker(
            tokens = tokens,
            onTokenClick = { token -> onTokenNavigate(token.address) }
        )

        // Live Feed Ticker
        if (userSettings.isShowLiveFeedTicker) {
            val justLaunchedTokens by viewModel.justLaunchedTokens.collectAsState()
            LiveFeedTicker(
                tokens = justLaunchedTokens,
                onDismiss = {
                    viewModel.updateSettings(userSettings.copy(isShowLiveFeedTicker = false))
                },
                onTokenClick = { address -> onTokenNavigate(address) }
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // Header stats & Connect pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "BASE SWIFT",
                        color = BaseBlue,
                        fontWeight = FontWeight.Black,
                        fontSize = 20.sp,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Pro Meme-Trading Tool",
                        color = TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                ConnectWallet(
                    walletAddress = walletAddress,
                    ethBalance = ethBalance
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Main Large Explorer Search Box
            Text(
                "Cari Token di Base Chain",
                color = TextWhite,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 6.dp)
            )

            OutlinedTextField(
                value = searchQuery,
                onValueChange = {
                    searchQuery = it
                    showAutocomplete = it.isNotBlank()
                    viewModel.performSearch(it)
                },
                placeholder = { Text("Nama, simbol, atau alamat kontrak...", color = TextMuted) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextMuted) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = CardBg,
                    unfocusedContainerColor = CardBg,
                    focusedBorderColor = BaseBlue,
                    unfocusedBorderColor = BorderColor,
                    focusedTextColor = TextWhite,
                    unfocusedTextColor = TextWhite
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_search_bar"),
                shape = RoundedCornerShape(8.dp)
            )

            // Autocomplete Results Overlay Dropdown
            AnimatedVisibility(visible = showAutocomplete) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardBg),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, BorderColor),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                        .heightIn(max = 240.dp)
                ) {
                    if (isSearching) {
                        Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = BaseBlue, modifier = Modifier.size(24.dp))
                        }
                    } else if (searchResults.isEmpty()) {
                        Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                            Text("Token tidak ditemukan", color = TextMuted, fontSize = 11.sp)
                        }
                    } else {
                        LazyColumn(modifier = Modifier.padding(6.dp)) {
                            items(searchResults) { match ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(4.dp))
                                        .clickable {
                                            searchQuery = ""
                                            showAutocomplete = false
                                            onTokenNavigate(match.address)
                                        }
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(match.name, color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text(match.symbol + " • " + Formatters.shortenAddress(match.address), color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                    }
                                    TokenSafetyBadge(match.safetyRating)
                                }
                            }
                        }
                    }
                }
            }

            // Recent searches tags
            if (recentSearches.isNotEmpty() && !showAutocomplete) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Terakhir dicari: ", color = TextMuted, fontSize = 10.sp)
                    Spacer(modifier = Modifier.width(6.dp))
                    recentSearches.take(3).forEach { term ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(JetBlack)
                                .border(0.5.dp, BorderColor, RoundedCornerShape(4.dp))
                                .clickable {
                                    onTokenNavigate(term)
                                }
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(Formatters.shortenAddress(term), color = BaseBlue, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // TABS ROW
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TabButton(text = "🔥 Trending", isSelected = selectedTab == 0, onClick = { selectedTab = 0 })
                TabButton(text = "🚀 Just Launched", isSelected = selectedTab == 1, onClick = { selectedTab = 1 })
                TabButton(text = "🆕 New <24H", isSelected = selectedTab == 2, onClick = { selectedTab = 2 })
                TabButton(text = "📈 Top Gainers", isSelected = selectedTab == 3, onClick = { selectedTab = 3 })
            }

            Spacer(modifier = Modifier.height(20.dp))

            when (selectedTab) {
                0 -> {
                    // SECTION 1: 🔥 TRENDING TOKENS
                    SectionHeader(title = "TRENDING POOLS", icon = Icons.Default.ElectricBolt, color = WarningYellow)
                    TokenRowList(tokens = trendingTokens, onTokenNavigate = onTokenNavigate, viewModel = viewModel, userSettings = userSettings)

                    Spacer(modifier = Modifier.height(24.dp))

                    // SECTION 1.5: 🚀 JUST LAUNCHED (LIVE) - Place above New Listings on Home Page
                    SectionHeader(title = "🚀 JUST LAUNCHED (LIVE)", icon = Icons.Default.ElectricBolt, color = SafeGreen)
                    val justLaunchedTokens by viewModel.justLaunchedTokens.collectAsState()
                    if (justLaunchedTokens.isEmpty()) {
                        Text("No live launches found aligning with filters", color = TextMuted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 12.dp))
                    } else {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(bottom = 12.dp)
                        ) {
                            justLaunchedTokens.take(6).forEach { token ->
                                JustLaunchedCard(token = token, onClick = { onTokenNavigate(token.address) })
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // SECTION 2: 🆕 NEW LISTINGS
                    SectionHeader(title = "NEW LISTINGS (<24H)", icon = Icons.Default.FiberNew, color = BaseBlue)
                    TokenRowList(tokens = newListings, onTokenNavigate = onTokenNavigate, viewModel = viewModel, userSettings = userSettings)

                    Spacer(modifier = Modifier.height(24.dp))

                    // SECTION 3: 📈 TOP GAINERS
                    SectionHeader(title = "TOP GAINERS (24H)", icon = Icons.Default.TrendingUp, color = SafeGreen)
                    TokenRowList(tokens = topGainers, onTokenNavigate = onTokenNavigate, viewModel = viewModel, userSettings = userSettings)
                }
                1 -> {
                    // Full List screen of newly launched live tokens
                    SectionHeader(title = "🚀 REAL-TIME JUST LAUNCHED (LIVE)", icon = Icons.Default.ElectricBolt, color = OrangeAccent)
                    val justLaunchedTokens by viewModel.justLaunchedTokens.collectAsState()
                    if (justLaunchedTokens.isEmpty()) {
                        Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                            Text("No live launches detected yet matching liquidity/age preferences.", color = TextMuted, fontSize = 12.sp)
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            justLaunchedTokens.forEach { token ->
                                JustLaunchedCard(token = token, onClick = { onTokenNavigate(token.address) })
                            }
                        }
                    }
                }
                2 -> {
                    // Full Screen list of New listings (up to 20 tokens)
                    SectionHeader(title = "🆕 NEW LISTINGS (<24H)", icon = Icons.Default.FiberNew, color = BaseBlue)
                    val fullNewListings = remember(visibleTokens) {
                        visibleTokens.filter { it.pairAgeHours < 48.0 }.take(20)
                    }
                    TokenRowList(tokens = fullNewListings, onTokenNavigate = onTokenNavigate, viewModel = viewModel, userSettings = userSettings)
                }
                3 -> {
                    // Full Screen list of Top gainers (up to 20 tokens)
                    SectionHeader(title = "📈 TOP GAINERS (24H)", icon = Icons.Default.TrendingUp, color = SafeGreen)
                    val fullTopGainers = remember(visibleTokens) {
                        visibleTokens.sortedByDescending { it.priceChangePercent24h }.take(20)
                    }
                    TokenRowList(tokens = fullTopGainers, onTokenNavigate = onTokenNavigate, viewModel = viewModel, userSettings = userSettings)
                }
            }
        }
    }

    // Real-Time Popup Alert Dialog
    if (activeAlertToken != null) {
        val alertToken = activeAlertToken!!
        AlertDialog(
            onDismissRequest = { activeAlertToken = null },
            containerColor = Color(0xFF0F141C),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .pulse(0.4f, 1.1f, 600)
                            .background(Color.Red, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "NEW COIN SPOTTED! 🚀",
                        color = OrangeAccent,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Token anyar baru saja terdeteksi di Base Chain!",
                        color = TextMuted,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CardBg),
                        border = BorderStroke(1.dp, BorderColor),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(alertToken.name, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(alertToken.symbol + " • " + Formatters.shortenAddress(alertToken.address), color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                }
                                TokenSafetyBadge(alertToken.safetyRating)
                            }
                            
                            Spacer(modifier = Modifier.height(10.dp))
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("PRICE", color = TextMuted, fontSize = 9.sp)
                                    Text(Formatters.formatUsd(alertToken.priceUsd), color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("LIQUIDITY", color = TextMuted, fontSize = 9.sp)
                                    Text("\$${Formatters.formatNumberCompact(alertToken.liquidityUsd)}", color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.executeBuy(alertToken, 0.05, 10.0)
                        activeAlertToken = null
                        onTokenNavigate(alertToken.address)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SafeGreen),
                    modifier = Modifier.testTag("popup_quick_buy")
                ) {
                    Text("Instant Buy 0.05 ETH", color = JetBlack, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { activeAlertToken = null },
                    modifier = Modifier.testTag("popup_close")
                ) {
                    Text("Tutup", color = TextMuted, fontSize = 12.sp)
                }
            }
        )
    }
}

@Composable
fun TabButton(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(30.dp))
            .background(if (isSelected) BaseBlue else CardBg)
            .border(1.dp, if (isSelected) BaseBlue else BorderColor, RoundedCornerShape(30.dp))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .testTag("tab_${text.lowercase().replace(" ", "_")}")
    ) {
        Text(
            text = text,
            color = if (isSelected) TextWhite else TextMuted,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun SectionHeader(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(bottom = 10.dp)
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = title,
            color = TextWhite,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun TokenRowList(
    tokens: List<Token>,
    onTokenNavigate: (String) -> Unit,
    viewModel: TradingViewModel,
    userSettings: UserSettings = UserSettings()
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        tokens.forEachIndexed { index, token ->
            TokenCardWidget(
                token = token,
                index = index,
                onClick = { onTokenNavigate(token.address) },
                viewModel = viewModel,
                userSettings = userSettings
            )
        }
    }
}

@Composable
fun TokenCardWidget(
    token: Token,
    index: Int = 0,
    onClick: () -> Unit,
    viewModel: TradingViewModel,
    userSettings: UserSettings = UserSettings()
) {
    val flashUpMap by viewModel.priceFlashUp.collectAsState()
    val flashDownMap by viewModel.priceFlashDown.collectAsState()

    val lastFlashUp = flashUpMap[token.address] ?: 0L
    val lastFlashDown = flashDownMap[token.address] ?: 0L

    // Is flashing if updated less than 300ms ago
    val isFlashingUp = (System.currentTimeMillis() - lastFlashUp) < 300L
    val isFlashingDown = (System.currentTimeMillis() - lastFlashDown) < 300L

    val containerColor by animateColorAsState(
        targetValue = when {
            isFlashingUp -> SafeGreen.copy(alpha = 0.25f)
            isFlashingDown -> DangerRed.copy(alpha = 0.25f)
            else -> CardBg
        },
        animationSpec = tween(durationMillis = 300),
        label = "containerColor"
    )

    // Staggered reveal animation state
    var isVisible by remember { mutableStateOf(false) }
    LaunchedEffect(token.address) {
        delay(index * 50L) // Staggered 50ms delay
        isVisible = true
    }

    val cardAlpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(300),
        label = "cardAlpha"
    )
    val cardOffsetY by animateFloatAsState(
        targetValue = if (isVisible) 0f else 20f,
        animationSpec = tween(300),
        label = "cardOffsetY"
    )

    // Interaction source for simulated hover/touch/press scale and lift
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val liftY by animateFloatAsState(
        targetValue = if (isPressed) -4f else 0f,
        animationSpec = spring(stiffness = 300f),
        label = "liftY"
    )
    val cardScale by animateFloatAsState(
        targetValue = if (isPressed) 0.97f else 1.0f,
        animationSpec = spring(stiffness = 400f),
        label = "cardScale"
    )

    // Layout configuration values for Compact Mode
    val isCompact = userSettings.isCompactMode
    val cardPadding = if (isCompact) 6.dp else 12.dp
    val iconSize = if (isCompact) 28.dp else 36.dp
    val titleSize = if (isCompact) 10.sp else 12.sp
    val subSize = if (isCompact) 9.sp else 10.sp
    val priceSize = if (isCompact) 11.sp else 12.sp
    val changeSize = if (isCompact) 9.sp else 11.sp
    val spacingBetween = if (isCompact) 1.dp else 2.dp

    // Dynamic currency displaying conversions
    val displayPriceUsd = token.priceUsd
    val displayPriceEth = token.priceEth

    val displayPriceString = if (userSettings.currencyDisplay == "ETH") {
        String.format("%.8f ETH", displayPriceEth)
    } else {
        Formatters.formatUsd(displayPriceUsd)
    }

    val displayMcString = if (userSettings.currencyDisplay == "ETH") {
        Formatters.formatNumberCompact(token.marketCapUsd / 3000.0, "") + " ETH"
    } else {
        Formatters.formatNumberCompact(token.marketCapUsd, "$")
    }

    val displayLiqString = if (userSettings.currencyDisplay == "ETH") {
        Formatters.formatNumberCompact(token.liquidityUsd / 3000.0, "") + " ETH"
    } else {
        Formatters.formatNumberCompact(token.liquidityUsd, "$")
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = containerColor),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(
            width = 1.dp,
            color = if (isPressed) BaseBlue else if (isFlashingUp) SafeGreen else if (isFlashingDown) DangerRed else BorderColor
        ),
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                alpha = cardAlpha
                translationY = cardOffsetY + liftY
                scaleX = cardScale
                scaleY = cardScale
            }
            .clickable(
                interactionSource = interactionSource,
                indication = androidx.compose.foundation.LocalIndication.current,
                onClick = onClick
            )
            .testTag("token_card_${token.symbol}")
    ) {
        Row(
            modifier = Modifier.padding(cardPadding),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Cute dynamic letter icon
            Box(
                modifier = Modifier
                    .size(iconSize)
                    .background(BaseBlue.copy(alpha = 0.15f), CircleShape)
                    .border(1.dp, BaseBlue.copy(alpha = 0.5f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = token.symbol.take(2),
                    color = TextWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = if (isCompact) 10.sp else 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = token.name,
                        color = TextWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = titleSize,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = token.symbol,
                        color = TextMuted,
                        fontSize = subSize,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Spacer(modifier = Modifier.height(spacingBetween))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "MC: $displayMcString",
                        color = TextMuted,
                        fontSize = subSize,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Liq: $displayLiqString",
                        color = TextMuted,
                        fontSize = subSize,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Column(
                horizontalAlignment = Alignment.End
            ) {
                val isUpPrice = token.priceChangePercent24h >= 0f
                AnimatedPriceText(
                    priceText = displayPriceString,
                    isUp = isUpPrice,
                    color = TextWhite,
                    fontSize = priceSize,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(spacingBetween))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (!isCompact) {
                        TokenSafetyBadge(token.safetyRating)
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    val isUp = token.priceChangePercent24h >= 0
                    Text(
                        text = String.format("%+.2f%%", token.priceChangePercent24h),
                        color = if (isUp) SafeGreen else DangerRed,
                        fontSize = changeSize,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}
