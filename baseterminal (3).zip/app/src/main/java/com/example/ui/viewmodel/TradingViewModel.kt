package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.utils.StorageHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.random.Random

sealed class TxState {
    object Idle : TxState()
    data class Pending(val msg: String) : TxState()
    data class Success(val msg: String, val txHash: String) : TxState()
    data class Error(val msg: String) : TxState()
}

class TradingViewModel(application: Application) : AndroidViewModel(application) {

    private val storage = StorageHelper(application)

    // STABLE TOKENS ACTIVE STATE WITH LIVE PRICE UPDATES
    private val _tokens = MutableStateFlow<List<Token>>(MockData.tokens)
    val tokens: StateFlow<List<Token>> = _tokens.asStateFlow()

    // SELECTED TOKEN ADDRESS FOR VIEWING / TRADING (BRETT IS DEFAULT)
    private val _selectedToken = MutableStateFlow<Token>(MockData.tokens.first { it.id == "brett" })
    val selectedToken: StateFlow<Token> = _selectedToken.asStateFlow()

    // GRAPH INTERVAL SELECTOR
    private val _selectedTimeframe = MutableStateFlow<String>("1m")
    val selectedTimeframe: StateFlow<String> = _selectedTimeframe.asStateFlow()

    private val _warningMessageFlow = kotlinx.coroutines.flow.MutableSharedFlow<String>(replay = 0, extraBufferCapacity = 1)
    val warningMessageFlow: kotlinx.coroutines.flow.SharedFlow<String> = _warningMessageFlow.asSharedFlow()

    private var candlePollingJob: kotlinx.coroutines.Job? = null

    // REAL-TIME ACTIVE GRAPH OHLCV (CANDLESTICKS)
    private val _chartCandles = MutableStateFlow<List<OhlcvPoint>>(emptyList())
    val chartCandles: StateFlow<List<OhlcvPoint>> = _chartCandles.asStateFlow()

    // REAL-TIME ACTIONS/TRADES HISTORIC FEED OF CURRENT TOKEN
    private val _liveTrades = MutableStateFlow<List<LiveTrade>>(emptyList())
    val liveTrades: StateFlow<List<LiveTrade>> = _liveTrades.asStateFlow()

    // TRANS_STATE TOAST FEED
    private val _txState = MutableStateFlow<TxState>(TxState.Idle)
    val txState: StateFlow<TxState> = _txState.asStateFlow()

    // WALLET ADDRESS & LOCAL PORTFOLIO CONFIGS
    private val _walletAddress = MutableStateFlow<String>(storage.getWalletAddress())
    val walletAddress: StateFlow<String> = _walletAddress.asStateFlow()

    private val _ethBalance = MutableStateFlow<Double>(storage.getDemoEthBalance())
    val ethBalance: StateFlow<Double> = _ethBalance.asStateFlow()

    private val _holdings = MutableStateFlow<Map<String, Double>>(storage.getDemoHoldings())
    val holdings: StateFlow<Map<String, Double>> = _holdings.asStateFlow()

    private val _tradeHistory = MutableStateFlow<List<TradeHistoryItem>>(storage.getTradeHistory())
    val tradeHistory: StateFlow<List<TradeHistoryItem>> = _tradeHistory.asStateFlow()

    private val _activeAlerts = MutableStateFlow<List<PriceAlert>>(storage.getPriceAlerts())
    val activeAlerts: StateFlow<List<PriceAlert>> = _activeAlerts.asStateFlow()

    private val _portfolioSnapshots = MutableStateFlow<List<PortfolioSnapshot>>(storage.getPortfolioSnapshots())
    val portfolioSnapshots: StateFlow<List<PortfolioSnapshot>> = _portfolioSnapshots.asStateFlow()

    // SEARCH RESULTS DISPATCHER
    private val _searchResults = MutableStateFlow<List<Token>>(emptyList())
    val searchResults: StateFlow<List<Token>> = _searchResults.asStateFlow()

    private val _isSearching = MutableStateFlow<Boolean>(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    // PROFILE DETAILS
    private val _username = MutableStateFlow<String>(
        storage.getUsername().ifBlank { "BaseTrader_" + Random.nextInt(1000, 9999) }
    )
    val username: StateFlow<String> = _username.asStateFlow()

    // ALERT TRIGGER SHARED NOTIFIER
    private val _alertTriggeredFlow = MutableSharedFlow<PriceAlert>()
    val alertTriggeredFlow: SharedFlow<PriceAlert> = _alertTriggeredFlow.asSharedFlow()

    // FLASH STATES (Token address to long epoch timestamp for animation trigger)
    private val _priceFlashUp = MutableStateFlow<Map<String, Long>>(emptyMap())
    val priceFlashUp: StateFlow<Map<String, Long>> = _priceFlashUp.asStateFlow()

    private val _priceFlashDown = MutableStateFlow<Map<String, Long>>(emptyMap())
    val priceFlashDown: StateFlow<Map<String, Long>> = _priceFlashDown.asStateFlow()

    // ADMIN CONTRACT VALUES
    private val _feeCollectedEth = MutableStateFlow<Double>(0.452)
    val feeCollectedEth: StateFlow<Double> = _feeCollectedEth.asStateFlow()

    private val _userSettings = MutableStateFlow<UserSettings>(storage.getUserSettings())
    val userSettings: StateFlow<UserSettings> = _userSettings.asStateFlow()

    // Real-time Just Launched State
    private val _justLaunchedTokens = MutableStateFlow<List<Token>>(emptyList())
    val justLaunchedTokens: StateFlow<List<Token>> = _justLaunchedTokens.asStateFlow()

    // Real-time notification flow for auto-opened popup
    private val _newLaunchAlertFlow = MutableSharedFlow<Token>()
    val newLaunchAlertFlow: SharedFlow<Token> = _newLaunchAlertFlow.asSharedFlow()

    // Tracking seen addresses to avoid duplicate notification triggers
    private val seenAddresses = mutableSetOf<String>()

    init {
        // Initialize timeframe with user defaults if saved
        _selectedTimeframe.value = storage.getUserSettings().chartSettings.defaultTimeframe

        // Save initial default username if blank
        if (storage.getUsername().isBlank()) {
            storage.setUsername(_username.value)
        }
        
        startCandlePollingJob()
        loadLiveTradesFeed()

        // 1. Tick Loop: Periodically randomize prices to simulate standard real-time feed
        viewModelScope.launch {
            while (true) {
                delay(3000L) // updates every 3 seconds as requested
                simulatePriceTicks()
                checkPriceAlertsAndNotify()
            }
        }

        // 2. Ticker Loop: Periodic small portfolio snapshots simulation
        viewModelScope.launch {
            while (true) {
                delay(60000L) // every 1 min
                recordPortfolioSnapshot()
            }
        }

        // 3. Just Launched Poller
        startJustLaunchedPoller()
    }

    private fun startJustLaunchedPoller() {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            _tokens.value.forEach { seenAddresses.add(it.address.lowercase()) }
            generateInitialSimulatedJustLaunched()

            while (true) {
                // Poll rate from userSettings or fallback to 10
                val pollSecs = _userSettings.value.justLaunchedRefreshRateSeconds.coerceIn(5, 30)
                try {
                    fetchJustLaunchedPools()
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    e.printStackTrace()
                    simulateLiveLaunchTick()
                }
                try {
                    delay(pollSecs * 1000L)
                } catch (ce: kotlinx.coroutines.CancellationException) {
                    throw ce
                }
            }
        }
    }


    private suspend fun generateInitialSimulatedJustLaunched() {
        val now = System.currentTimeMillis()
        val initialLaunches = List(8) { idx ->
            val prefix = simPrefixes.random()
            val sym = simSymbols.random()
            val name = "$prefix $sym"
            val symbol = (prefix.take(3) + sym).uppercase()
            val randAddr = "0x" + UUID.randomUUID().toString().replace("-", "").take(40)
            val price = Random.nextDouble(0.0001, 0.05)
            val liquidity = Random.nextDouble(1200.0, 25000.0)
            val ageMins = (idx * 6) + Random.nextInt(1, 5)

            Token(
                id = "sim_init_$idx",
                name = name,
                symbol = symbol,
                address = randAddr,
                logoUrl = "",
                priceEth = price / 3000.0,
                priceUsd = price,
                priceChangePercent24h = Random.nextDouble(-10.0, 50.0),
                volume24hUsd = Random.nextDouble(500.0, 10000.0),
                marketCapUsd = liquidity * 3.0,
                liquidityEth = liquidity / 3000.0,
                liquidityUsd = liquidity,
                pairAgeHours = ageMins.toDouble() / 60.0,
                safetyRating = if (liquidity > 8000) SafetyRating.SAFE else if (liquidity > 3000) SafetyRating.WARNING else SafetyRating.DANGER,
                creationTimeMills = now - ageMins * 60000L
            )
        }
        processAndMergeNewLaunches(initialLaunches)
    }

    private suspend fun fetchJustLaunchedPools() {
        val response = ApiClient.geckoService.getNewlyLaunchedPools(page = 1, sort = "pool_created_at")
        val pools = response.data ?: emptyList()
        val mappedTokens = pools.map { pool ->
            val name = pool.attributes.name
            val parts = name.split(Regex("\\s*/\\s*|\\s*-\\s*|/"))
            val symbol = if (parts.isNotEmpty()) parts[0] else name
            val baseName = symbol
            val address = pool.attributes.address
            val priceUsd = pool.attributes.price_in_usd?.toDoubleOrNull() ?: 1.0
            val reserveUsd = pool.attributes.reserve_in_usd?.toDoubleOrNull() ?: 0.0

            val creationTimeMills = try {
                if (pool.attributes.pool_created_at != null) {
                    java.time.Instant.parse(pool.attributes.pool_created_at).toEpochMilli()
                } else {
                    System.currentTimeMillis() - Random.nextLong(10000, 3600000)
                }
            } catch (e: Exception) {
                System.currentTimeMillis() - Random.nextLong(10000, 3600000)
            }

            val safetyRating = when {
                reserveUsd < 5000.0 -> SafetyRating.DANGER
                reserveUsd < 15000.0 -> SafetyRating.WARNING
                else -> SafetyRating.SAFE
            }

            Token(
                id = "gt_${pool.id}",
                name = baseName,
                symbol = symbol,
                address = address,
                logoUrl = "",
                priceEth = priceUsd / 3000.0,
                priceUsd = priceUsd,
                priceChangePercent24h = 0.0,
                volume24hUsd = pool.attributes.from_volume_in_usd?.toDoubleOrNull() ?: 0.0,
                marketCapUsd = reserveUsd * 2.5,
                liquidityEth = reserveUsd / 3000.0,
                liquidityUsd = reserveUsd,
                pairAgeHours = (System.currentTimeMillis() - creationTimeMills).toDouble() / 3600000.0,
                safetyRating = safetyRating,
                creationTimeMills = creationTimeMills
            )
        }
        processAndMergeNewLaunches(mappedTokens)
    }

    private suspend fun simulateLiveLaunchTick() {
        val now = System.currentTimeMillis()
        if (Random.nextDouble() < 0.45) {
            val prefix = simPrefixes.random()
            val sym = simSymbols.random()
            val name = "$prefix $sym"
            val symbol = (prefix.take(3) + sym).uppercase()
            val randAddr = "0x" + UUID.randomUUID().toString().replace("-", "").take(40)
            
            val price = Random.nextDouble(0.0001, 0.05)
            val liquidity = Random.nextDouble(500.0, 15000.0)

            val newToken = Token(
                id = "sim_${UUID.randomUUID().toString().take(8)}",
                name = name,
                symbol = symbol,
                address = randAddr,
                logoUrl = "",
                priceEth = price / 3000.0,
                priceUsd = price,
                priceChangePercent24h = 0.0,
                volume24hUsd = Random.nextDouble(100.0, 5000.0),
                marketCapUsd = liquidity * 3.0,
                liquidityEth = liquidity / 3000.0,
                liquidityUsd = liquidity,
                pairAgeHours = 0.0,
                safetyRating = if (liquidity > 5000) SafetyRating.SAFE else SafetyRating.WARNING,
                creationTimeMills = now
            )
            processAndMergeNewLaunches(listOf(newToken))
        } else {
            val updated = _justLaunchedTokens.value.map { token ->
                val priceChange = (Random.nextDouble() - 0.48) * 0.05
                val newPrice = token.priceUsd * (1.0 + priceChange).coerceIn(0.5, 2.0)
                token.copy(
                    priceUsd = newPrice,
                    priceEth = newPrice / 3000.0
                )
            }
            processAndMergeNewLaunches(updated)
        }
    }

    private suspend fun processAndMergeNewLaunches(newTokens: List<Token>) {
        val now = System.currentTimeMillis()
        val sixtyMinsAgo = now - 60 * 60 * 1000L

        val currentList = _justLaunchedTokens.value.toMutableList()
        val combined = (newTokens + currentList).associateBy { it.address.lowercase() }.values.toList()

        val filtered = combined.filter { token ->
            val ageMs = now - token.creationTimeMills
            val ageMins = ageMs / 60000.0

            val passesAgeMax = ageMs <= 60 * 60 * 1000L
            val passesMinLiquidity = token.liquidityUsd >= _userSettings.value.minLiquidityUsd
            val passesAgeMin = ageMins >= _userSettings.value.hideTokensYoungerThanMinutes

            passesAgeMax && passesMinLiquidity && passesAgeMin
        }.sortedByDescending { it.creationTimeMills }.take(20)

        filtered.forEach { token ->
            val addr = token.address.lowercase()
            if (!seenAddresses.contains(addr)) {
                seenAddresses.add(addr)
                if (_userSettings.value.isAutoOpenNewToken) {
                    _newLaunchAlertFlow.emit(token)
                }
            }
        }

        _justLaunchedTokens.value = filtered
    }

    private fun loadLiveTradesFeed() {
        _liveTrades.value = MockData.generateLiveTrades(_selectedToken.value)
    }

    private fun startCandlePollingJob() {
        candlePollingJob?.cancel()
        candlePollingJob = viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val token = _selectedToken.value
            val tf = _selectedTimeframe.value
            
            while (true) {
                try {
                    // Determine pool address
                    val poolAddress = resolvePoolAddress(token)
                    
                    when (tf) {
                        "1s" -> {
                            val trades = fetchTradesFromApi(poolAddress)
                            val candlesMapped = com.example.utils.buildCandlesFromTrades(trades, 1)
                            _chartCandles.value = candlesMapped.map { ohlcvFromCandle(it) }
                            delay(1000L)
                        }
                        "5s" -> {
                            val trades = fetchTradesFromApi(poolAddress)
                            val candlesMapped = com.example.utils.buildCandlesFromTrades(trades, 5)
                            _chartCandles.value = candlesMapped.map { ohlcvFromCandle(it) }
                            delay(2000L)
                        }
                        "15s" -> {
                            val trades = fetchTradesFromApi(poolAddress)
                            val candlesMapped = com.example.utils.buildCandlesFromTrades(trades, 15)
                            _chartCandles.value = candlesMapped.map { ohlcvFromCandle(it) }
                            delay(3000L)
                        }
                        "30s" -> {
                            val trades = fetchTradesFromApi(poolAddress)
                            val candlesMapped = com.example.utils.buildCandlesFromTrades(trades, 30)
                            _chartCandles.value = candlesMapped.map { ohlcvFromCandle(it) }
                            delay(3000L)
                        }
                        "1m", "5m", "15m" -> {
                            val agg = when (tf) {
                                "5m" -> 5
                                "15m" -> 15
                                else -> 1
                            }
                            val ohlcv = fetchOhlcvMinuteFromApi(poolAddress, agg)
                            if (ohlcv.isNotEmpty()) {
                                _chartCandles.value = ohlcv
                            }
                            delay(10000L)
                        }
                        "1h", "4h" -> {
                            val agg = if (tf == "4h") 4 else 1
                            val ohlcv = fetchOhlcvHourFromApi(poolAddress, agg)
                            if (ohlcv.isNotEmpty()) {
                                _chartCandles.value = ohlcv
                            }
                            delay(60000L)
                        }
                        "1d" -> {
                            val ohlcv = fetchOhlcvDayFromApi(poolAddress, 1)
                            if (ohlcv.isNotEmpty()) {
                                _chartCandles.value = ohlcv
                            }
                            delay(300000L) // 5 minutes
                        }
                        else -> {
                            val candles = MockData.generateOhlcv(token, 1)
                            _chartCandles.value = candles
                            delay(10000L)
                        }
                    }
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    e.printStackTrace()
                    if (_chartCandles.value.isEmpty()) {
                        val fallback = MockData.generateOhlcv(token, 1)
                        _chartCandles.value = fallback
                    }
                    try {
                        delay(5000L)
                    } catch (ce: kotlinx.coroutines.CancellationException) {
                        throw ce
                    }
                }
            }
        }
    }

    private suspend fun resolvePoolAddress(token: Token): String {
        val address = token.address
        if (token.id.startsWith("sim_") || token.id.startsWith("sim_init_")) {
            return address
        }
        return try {
            val response = ApiClient.geckoService.getTokenPools(address)
            val resolved = response.data?.firstOrNull()?.attributes?.address
            resolved ?: address
        } catch (e: Exception) {
            address
        }
    }

    private fun parseTimestamp(timestampStr: String?): Long {
        if (timestampStr == null) return System.currentTimeMillis()
        return try {
            java.time.Instant.parse(timestampStr).toEpochMilli()
        } catch (e: Exception) {
            try {
                timestampStr.toLong() * 1000L
            } catch (ex: Exception) {
                System.currentTimeMillis()
            }
        }
    }

    private suspend fun fetchTradesFromApi(pool: String): List<com.example.utils.Trade> {
        if (pool.startsWith("0x")) {
            try {
                val response = ApiClient.geckoService.getPoolTrades(pool)
                val mapped = response.data?.mapNotNull { trade ->
                    val price = trade.attributes.price_from_in_usd?.toDoubleOrNull() ?: return@mapNotNull null
                    val amount = trade.attributes.from_token_amount?.toDoubleOrNull() ?: 0.0
                    val ts = parseTimestamp(trade.attributes.block_timestamp)
                    com.example.utils.Trade(
                        price = price,
                        amount = amount,
                        timestamp = ts,
                        type = trade.attributes.kind ?: "buy"
                    )
                } ?: emptyList()
                if (mapped.isNotEmpty()) return mapped
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        return generateSimulatedTrades(pool)
    }

    private fun generateSimulatedTrades(pool: String): List<com.example.utils.Trade> {
        val now = System.currentTimeMillis()
        val list = mutableListOf<com.example.utils.Trade>()
        val basePrice = _selectedToken.value.priceUsd
        for (i in 0 until 50) {
            val randPrice = basePrice * (1.0 + (Random.nextDouble() - 0.49) * 0.02)
            list.add(
                com.example.utils.Trade(
                    price = randPrice,
                    amount = Random.nextDouble(10.0, 500.0),
                    timestamp = now - i * 5000L,
                    type = if (Random.nextBoolean()) "buy" else "sell"
                )
            )
        }
        return list
    }

    private suspend fun fetchOhlcvMinuteFromApi(pool: String, aggregate: Int): List<OhlcvPoint> {
        if (pool.startsWith("0x")) {
            try {
                val response = ApiClient.geckoService.getOhlcvMinute(pool, aggregate)
                val mapped = mapOhlcvResponse(response)
                if (mapped.isNotEmpty()) return mapped
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        return MockData.generateOhlcv(_selectedToken.value, when(aggregate) {
            5 -> 5
            15 -> 15
            else -> 1
        })
    }

    private suspend fun fetchOhlcvHourFromApi(pool: String, aggregate: Int): List<OhlcvPoint> {
        if (pool.startsWith("0x")) {
            try {
                val response = ApiClient.geckoService.getOhlcvHour(pool, aggregate)
                val mapped = mapOhlcvResponse(response)
                if (mapped.isNotEmpty()) return mapped
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        return MockData.generateOhlcv(_selectedToken.value, when(aggregate) {
            4 -> 96
            else -> 24
        })
    }

    private suspend fun fetchOhlcvDayFromApi(pool: String, aggregate: Int): List<OhlcvPoint> {
        if (pool.startsWith("0x")) {
            try {
                val response = ApiClient.geckoService.getOhlcvDay(pool, aggregate)
                val mapped = mapOhlcvResponse(response)
                if (mapped.isNotEmpty()) return mapped
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        return MockData.generateOhlcv(_selectedToken.value, 168)
    }

    private fun mapOhlcvResponse(response: GeckoOhlcvResponse?): List<OhlcvPoint> {
        val list = response?.data?.attributes?.ohlcv_list ?: return emptyList()
        return list.mapNotNull { item ->
            if (item.size < 6) return@mapNotNull null
            OhlcvPoint(
                timestamp = item[0].toLong() * 1000L,
                open = item[1],
                high = item[2],
                low = item[3],
                close = item[4],
                volume = item[5]
            )
        }.sortedBy { it.timestamp }
    }

    private fun ohlcvFromCandle(candle: com.example.utils.Candle): OhlcvPoint {
        return OhlcvPoint(
            timestamp = candle.time,
            open = candle.open,
            high = candle.high,
            low = candle.low,
            close = candle.close,
            volume = candle.volume
        )
    }

    // SIMULATED RANDOM WALK PRICE UPDATE
    private fun simulatePriceTicks() {
        val random = Random(System.currentTimeMillis())
        val currentFlashUp = _priceFlashUp.value.toMutableMap()
        val currentFlashDown = _priceFlashDown.value.toMutableMap()

        val updated = _tokens.value.map { token ->
            val changeFactor = (random.nextDouble() - 0.49) * 0.038 // swing up or down
            val currentPrice = token.priceUsd * (1.0 + changeFactor)
            val currentPriceEth = token.priceEth * (1.0 + changeFactor)
            val oldPrice = token.priceUsd

            // Trigger flashes
            if (changeFactor > 0.005) {
                currentFlashUp[token.address] = System.currentTimeMillis()
            } else if (changeFactor < -0.005) {
                currentFlashDown[token.address] = System.currentTimeMillis()
            }

            token.copy(
                priceUsd = currentPrice,
                priceEth = currentPriceEth,
                priceChangePercent24h = token.priceChangePercent24h + (changeFactor * 100.0),
                volume24hUsd = token.volume24hUsd + (random.nextDouble() * 3000.0)
            )
        }

        _priceFlashUp.value = currentFlashUp
        _priceFlashDown.value = currentFlashDown
        _tokens.value = updated

        // Keep selected token price updated
        val updatedSelected = updated.firstOrNull { it.address == _selectedToken.value.address }
        if (updatedSelected != null) {
            _selectedToken.value = updatedSelected
        }
    }

    // ALERTS CONTROLLER ACTION
    private suspend fun checkPriceAlertsAndNotify() {
        val alerts = _activeAlerts.value.toMutableList()
        var updated = false

        _tokens.value.forEach { token ->
            alerts.forEach { alert ->
                if (alert.isActive && alert.tokenAddress == token.address) {
                    val price = token.priceUsd
                    val isTriggeredNow = if (alert.isAbove) {
                        price >= alert.targetPriceUsd
                    } else {
                        price <= alert.targetPriceUsd
                    }

                    if (isTriggeredNow) {
                        alert.isActive = false
                        alert.isTriggered = true
                        alert.triggeredPrice = price
                        alert.triggerTime = System.currentTimeMillis()
                        updated = true
                        _alertTriggeredFlow.emit(alert)
                    }
                }
            }
        }

        if (updated) {
            _activeAlerts.value = alerts
            storage.setPriceAlerts(alerts)
        }
    }

    // SELECT AN ACTIVE COIN FOR INTERACTIVE DETAIL
    fun selectToken(address: String) {
        val found = _tokens.value.firstOrNull { it.address.lowercase() == address.lowercase() }
        if (found != null) {
            _selectedToken.value = found
            storage.saveRecentlyViewed(found.address)
            startCandlePollingJob()
            loadLiveTradesFeed()
        }
    }

    // UPDATE TIME INTERVAL
    fun setTimeframe(tf: String) {
        _selectedTimeframe.value = tf
        startCandlePollingJob()
    }

    // REAL ASYNC TOKEN SEARCH ACTION
    fun performSearch(query: String) {
        if (query.isBlank()) {
            _searchResults.value = emptyList()
            return
        }
        storage.saveRecentSearch(query)
        _isSearching.value = true
        viewModelScope.launch {
            val results = ApiClient.searchTokensResilient(query)
            _searchResults.value = results
            _isSearching.value = false
        }
    }

    fun getRecentSearches(): List<String> = storage.getRecentSearches()
    fun getRecentlyViewed(): List<Token> {
        val addresses = storage.getRecentlyViewed()
        return _tokens.value.filter { token -> addresses.contains(token.address) }
    }
    fun clearRecentSearches() {
        storage.clearRecentSearches()
    }

    // ORDER TRANSACTION SYSTEM (BUY) WITH SIMULATED 1.5S NETWORK FEED
    fun executeBuy(token: Token, ethAmount: Double, slippagePercent: Double) {
        if (ethAmount <= 0.0) {
            _txState.value = TxState.Error("Tentukan jumlah ETH untuk dikirim!")
            return
        }
        if (_ethBalance.value < ethAmount) {
            _txState.value = TxState.Error("Saldo ETH tidak mencukupi!")
            return
        }

        viewModelScope.launch {
            _txState.value = TxState.Pending("FEE ROUTING: Mentransfer fee 1% (${(ethAmount * 0.01).formatDecimals(4)} ETH) secara instan ke Wallet Owner...")
            delay(1000L) // Block simulation
            _txState.value = TxState.Pending("UNISWAP V3 SWAP: Melakukan swap sisa ${(ethAmount * 0.99).formatDecimals(4)} ETH ke ${token.symbol}...")
            delay(1000L) // Contract execution simulation

            val fee = ethAmount * 0.01 // 1%
            val purchaseEth = ethAmount - fee
            val tokenTokens = purchaseEth / token.priceEth

            // Fee is sent instantly to owner wallet on transaction execution (FeeRouter.sol simulation)
            _feeCollectedEth.value += fee

            // Update local balance
            val newEth = _ethBalance.value - ethAmount
            _ethBalance.value = newEth
            storage.setDemoEthBalance(newEth)

            // Update holdings
            val currentHoldings = _holdings.value.toMutableMap()
            val existingAmount = currentHoldings[token.address] ?: 0.0
            currentHoldings[token.address] = existingAmount + tokenTokens
            _holdings.value = currentHoldings
            storage.setDemoHoldings(currentHoldings)

            // Add to history
            val txHash = "0x" + UUID.randomUUID().toString().replace("-", "").take(64)
            val historyItem = TradeHistoryItem(
                id = UUID.randomUUID().toString(),
                type = "BUY",
                isBuy = true,
                tokenAddress = token.address,
                tokenName = token.name,
                tokenSymbol = token.symbol,
                ethAmount = ethAmount,
                tokenAmount = tokenTokens,
                pricePaidEth = token.priceEth,
                pricePaidUsd = token.priceUsd,
                timestamp = System.currentTimeMillis(),
                txHash = txHash,
                status = "SUCCESS"
            )

            storage.saveTradeHistoryItem(historyItem)
            _tradeHistory.value = storage.getTradeHistory()

            _txState.value = TxState.Success(
                msg = "${tokenTokens.formatDecimals(2)} ${token.symbol} berhasil dibeli! (Fee 1% ditransfer langsung ke Owner)",
                txHash = txHash
            )

            // Auto reset idle state
            delay(4000)
            _txState.value = TxState.Idle
        }
    }

    // ORDER TRANSACTION SYSTEM (SELL)
    fun executeSell(token: Token, tokenAmount: Double, slippagePercent: Double) {
        val heldAmount = _holdings.value[token.address] ?: 0.0
        if (tokenAmount <= 0.0) {
            _txState.value = TxState.Error("Tentukan jumlah token untuk dijual!")
            return
        }
        if (heldAmount < tokenAmount) {
            _txState.value = TxState.Error("Saldo Token tidak mencukupi untuk dijual!")
            return
        }

        viewModelScope.launch {
            _txState.value = TxState.Pending("FEE ROUTING: Mentransfer fee 1% (${(tokenAmount * token.priceEth * 0.01).formatDecimals(4)} ETH) secara instan ke Wallet Owner...")
            delay(1000L)
            _txState.value = TxState.Pending("UNISWAP V3 SWAP: Melakukan swap ${tokenAmount.formatDecimals(2)} ${token.symbol} ke ETH...")
            delay(1000L)

            val returnEth = tokenAmount * token.priceEth
            val fee = returnEth * 0.01 // 1%
            val finalEth = returnEth - fee

            // Fee is sent instantly to owner wallet on transaction execution (FeeRouter.sol simulation)
            _feeCollectedEth.value += fee

            // Update balance
            val newEth = _ethBalance.value + finalEth
            _ethBalance.value = newEth
            storage.setDemoEthBalance(newEth)

            // Update holdings
            val currentHoldings = _holdings.value.toMutableMap()
            val remaining = heldAmount - tokenAmount
            if (remaining <= 0.0001) {
                currentHoldings.remove(token.address)
            } else {
                currentHoldings[token.address] = remaining
            }
            _holdings.value = currentHoldings
            storage.setDemoHoldings(currentHoldings)

            // Save History
            val txHash = "0x" + UUID.randomUUID().toString().replace("-", "").take(64)
            val historyItem = TradeHistoryItem(
                id = UUID.randomUUID().toString(),
                type = "SELL",
                isBuy = false,
                tokenAddress = token.address,
                tokenName = token.name,
                tokenSymbol = token.symbol,
                ethAmount = finalEth,
                tokenAmount = tokenAmount,
                pricePaidEth = token.priceEth,
                pricePaidUsd = token.priceUsd,
                timestamp = System.currentTimeMillis(),
                txHash = txHash,
                status = "SUCCESS"
            )

            storage.saveTradeHistoryItem(historyItem)
            _tradeHistory.value = storage.getTradeHistory()

            _txState.value = TxState.Success(
                msg = "${tokenAmount.formatDecimals(2)} ${token.symbol} berhasil dijual untuk ${finalEth.formatDecimals(4)} ETH! (Fee 1% ditransfer langsung ke Owner)",
                txHash = txHash
            )

            delay(4000)
            _txState.value = TxState.Idle
        }
    }

    // HELPER: RESET TOAST
    fun resetTxState() {
        _txState.value = TxState.Idle
    }

    // CREATE NEW PRICE ALERT
    fun addPriceAlert(token: Token, targetPriceUsd: Double, isAbove: Boolean) {
        val alert = PriceAlert(
            id = UUID.randomUUID().toString(),
            tokenAddress = token.address,
            tokenSymbol = token.symbol,
            targetPriceUsd = targetPriceUsd,
            isAbove = isAbove,
            isActive = true
        )
        storage.savePriceAlert(alert)
        _activeAlerts.value = storage.getPriceAlerts()
    }

    // CANCEL ALERT
    fun removePriceAlert(alertId: String) {
        val current = _activeAlerts.value.toMutableList()
        current.removeIf { it.id == alertId }
        storage.setPriceAlerts(current)
        _activeAlerts.value = current
    }

    // PROFILE EDITOR FUNCTION
    fun updateUsername(newName: String) {
        if (newName.isNotBlank()) {
            _username.value = newName
            storage.setUsername(newName)
        }
    }

    fun updateSettings(newSettings: UserSettings) {
        var updatedChartSettings = newSettings.chartSettings
        val defaultAllOn = setOf("1s", "5s", "15s", "30s", "1m", "5m", "15m", "1h", "4h", "1d")
        
        // Validation 1: If visibleTimeframes is empty → reset to default all ON
        if (updatedChartSettings.visibleTimeframes.isEmpty()) {
            updatedChartSettings = updatedChartSettings.copy(visibleTimeframes = defaultAllOn)
        }
        
        // Validation 2: If defaultTimeframe not in visibleTimeframes → set default to first visible timeframe
        val visibleTfs = updatedChartSettings.visibleTimeframes
        val defaultTf = updatedChartSettings.defaultTimeframe
        if (!visibleTfs.contains(defaultTf)) {
            val oldDefault = defaultTf
            val allOrd = listOf("1s", "5s", "15s", "30s", "1m", "5m", "15m", "1h", "4h", "1d")
            val newDefault = allOrd.firstOrNull { visibleTfs.contains(it) } ?: "1m"
            updatedChartSettings = updatedChartSettings.copy(defaultTimeframe = newDefault)
            
            // Show warning snackbar message
            val warningMsg = "Default timeframe changed to $newDefault because $oldDefault was hidden"
            _warningMessageFlow.tryEmit(warningMsg)
        }
        
        val validatedSettings = newSettings.copy(chartSettings = updatedChartSettings)
        
        _userSettings.value = validatedSettings
        storage.setUserSettings(validatedSettings)
        
        // Sync selected chart timeframe if the old one was disabled
        if (!validatedSettings.chartSettings.visibleTimeframes.contains(_selectedTimeframe.value)) {
            val allOrd = listOf("1s", "5s", "15s", "30s", "1m", "5m", "15m", "1h", "4h", "1d")
            val fallbackTf = allOrd.firstOrNull { validatedSettings.chartSettings.visibleTimeframes.contains(it) } ?: "1m"
            _selectedTimeframe.value = fallbackTf
        }
    }

    fun exportTradeHistoryToCsv(): String {
        val history = _tradeHistory.value
        val sb = StringBuilder()
        sb.append("ID,Type,Token Address,Token Name,Token Symbol,ETH Amount,Token Amount,Price Paid ETH,Price Paid USD,Timestamp,Tx Hash,Status\n")
        history.forEach { tx ->
            sb.append("${tx.id},${tx.type},${tx.tokenAddress},\"${tx.tokenName.replace("\"", "\"\"")}\",${tx.tokenSymbol},${tx.ethAmount},${tx.tokenAmount},${tx.pricePaidEth},${tx.pricePaidUsd},${tx.timestamp},${tx.txHash},${tx.status}\n")
        }
        return sb.toString()
    }

    fun clearAllUserData() {
        storage.clearAllLocalData()

        // Reset local in-memory viewmodel states immediately
        val defaultSettings = UserSettings()
        _userSettings.value = defaultSettings
        _tradeHistory.value = storage.getTradeHistory()
        _activeAlerts.value = storage.getPriceAlerts()
        _holdings.value = storage.getDemoHoldings()
        _ethBalance.value = storage.getDemoEthBalance()
        _walletAddress.value = storage.getWalletAddress()
        _portfolioSnapshots.value = storage.getPortfolioSnapshots()

        val newUsername = "BaseTrader_" + Random.nextInt(1000, 9999)
        _username.value = newUsername
        storage.setUsername(newUsername)
    }

    // SNAPSHOT PORTFOLIO TOTALS
    private fun recordPortfolioSnapshot() {
        val holdingsValueEth = calculatePortfolioHoldingsValueEth()
        val totalValueEth = _ethBalance.value + holdingsValueEth
        val totalValueUsd = totalValueEth * 3000.0 // Base index approximation

        val snapshot = PortfolioSnapshot(System.currentTimeMillis(), totalValueEth, totalValueUsd)
        storage.addPortfolioSnapshot(snapshot)
        _portfolioSnapshots.value = storage.getPortfolioSnapshots()
    }

    // USER PORTFOLIO DATA METRIC AGGREGATORS
    fun calculatePortfolioHoldingsValueEth(): Double {
        var sum = 0.0
        _holdings.value.forEach { (address, amount) ->
            val token = _tokens.value.firstOrNull { it.address.lowercase() == address.lowercase() }
            if (token != null) {
                sum += (amount * token.priceEth)
            }
        }
        return sum
    }

    fun getPortfolioTotals(): PortfolioMetrics {
        val ethBal = _ethBalance.value
        val holdingsEth = calculatePortfolioHoldingsValueEth()
        val totalEth = ethBal + holdingsEth
        val totalUsd = totalEth * 3000.0

        // Calculate PnL and trade counts
        val history = _tradeHistory.value
        val tradesCount = history.size
        var wins = 0
        var losses = 0
        var realizedPnlUsd = 0.0

        history.forEach { tx ->
            if (!tx.isBuy) {
                // simple realization estimate
                realizedPnlUsd += (tx.ethAmount * 3000.0 * 0.1) // assume 10% average trade delta realized
                wins++
            } else {
                losses++
            }
        }

        // Unrealized calculation: Current total value compared to purchase bases
        val unrealizedPnlUsd = holdingsEth * 3000.0 * 0.15 // average demo valuation gain delta

        val totalVol = history.sumOf { it.ethAmount }
        val rawRate = if (wins + losses > 0) (wins.toDouble() / (wins + losses).toDouble()) * 100.0 else 0.0
        val winRate = if (rawRate == 0.0) 72.5 else rawRate // Safe default for demo layout

        return PortfolioMetrics(
            totalValueEth = totalEth,
            totalValueUsd = totalUsd,
            realizedPnlUsd = realizedPnlUsd,
            unrealizedPnlUsd = unrealizedPnlUsd,
            totalTrades = tradesCount,
            winRate = winRate,
            tradingVolumeEth = totalVol
        )
    }

    // DOUBLE EXTENSION EXTRACTOR
    private fun Double.formatDecimals(digits: Int): String {
        return java.lang.String.format(java.util.Locale.US, "%.${digits}f", this)
    }

    companion object {
        private val simSymbols = listOf("MOON", "PEPE", "PUMP", "DOG", "KITTY", "BASE", "GIGA", "CHAD", "WIF", "ROCKET", "TURBO", "SAFE", "BULL", "ALPHA", "BEAR")
        private val simPrefixes = listOf("Based", "Super", "Giga", "Baby", "Golden", "Mega", "Pepe", "Elon", "Space", "Degen")
    }
}

// HOLDER DATA CLASS FOR AGGREGATES
data class PortfolioMetrics(
    val totalValueEth: Double,
    val totalValueUsd: Double,
    val realizedPnlUsd: Double,
    val unrealizedPnlUsd: Double,
    val totalTrades: Int,
    val winRate: Double,
    val tradingVolumeEth: Double
)
