package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.AddAlert
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AlertList
import com.example.ui.theme.*
import com.example.ui.viewmodel.TradingViewModel
import com.example.utils.Formatters
import kotlin.math.absoluteValue

@Composable
fun ProfileScreen(
    viewModel: TradingViewModel,
    onTokenNavigate: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val clipboardManager = LocalClipboardManager.current

    val username by viewModel.username.collectAsState()
    val walletAddress by viewModel.walletAddress.collectAsState()
    val rawHistory by viewModel.tradeHistory.collectAsState()
    val alerts by viewModel.activeAlerts.collectAsState()

    var isEditingName by remember { mutableStateOf(false) }
    var nameInput by remember { mutableStateOf(username) }

    val totals = remember(rawHistory) { viewModel.getPortfolioTotals() }

    var selectedTab by remember { mutableStateOf(0) } // 0 = History, 1 = Alerts

    val scrollState = rememberScrollState()

    // Deterministic Jazzicon colored avatar gradient helper
    val avatarGradient = remember(username) {
        val h = username.hashCode()
        val color1 = Color(0xFF000000L or (h.absoluteValue % 0xFFFFFF).toLong())
        val color2 = Color(0xFF000000L or ((h.absoluteValue * 31) % 0xFFFFFF).toLong())
        Brush.radialGradient(
            colors = listOf(color1, color2, Color.Black),
            radius = 120f
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("profile_screen")
    ) {
        Text(
            text = "PROFIL TRADER",
            color = BaseBlue,
            fontWeight = FontWeight.Black,
            fontSize = 18.sp,
            letterSpacing = 0.5.sp
        )
        Text(
            text = "Kelola identitas dan riwayat perdagangan Anda",
            color = TextMuted,
            fontSize = 11.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        // AVATAR & EDITABLE NAME CARDS
        Card(
            colors = CardDefaults.cardColors(containerColor = CardBg),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, BorderColor),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Jazzicon Circle Avatar
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(avatarGradient)
                        .border(1.5.dp, BorderColor, CircleShape)
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Editable name box
                if (isEditingName) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = { nameInput = it },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = JetBlack,
                                unfocusedContainerColor = JetBlack,
                                focusedBorderColor = BaseBlue,
                                unfocusedBorderColor = BorderColor,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .padding(end = 6.dp)
                        )
                        IconButton(
                            onClick = {
                                viewModel.updateUsername(nameInput)
                                isEditingName = false
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(BaseBlue.copy(alpha = 0.2f))
                        ) {
                            Icon(imageVector = Icons.Default.Save, contentDescription = "Simpan", tint = BaseBlue)
                        }
                    }
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.clickable {
                            nameInput = username
                            isEditingName = true
                        }
                    ) {
                        Text(
                            text = username,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit", tint = TextMuted, modifier = Modifier.size(14.dp))
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Short copyable wallet pill
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(32.dp))
                        .background(JetBlack)
                        .border(0.5.dp, BorderColor, RoundedCornerShape(32.dp))
                        .clickable {
                            clipboardManager.setText(AnnotatedString(walletAddress))
                        }
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Icon(imageVector = Icons.Default.Wallet, contentDescription = null, tint = BaseBlue, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = Formatters.shortenAddress(walletAddress),
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, tint = TextMuted, modifier = Modifier.size(10.dp))
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // STATS BOX
        Card(
            colors = CardDefaults.cardColors(containerColor = CardBg),
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, BorderColor),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "STATISTIK AKUN PRO",
                    color = TextWhite,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    ProfileStatsCell("VOLUME PERDAGANGAN", String.format("%.2f ETH", totals.tradingVolumeEth))
                    ProfileStatsCell("TOTAL TRADES", String.format("%d", totals.totalTrades))
                }

                Spacer(modifier = Modifier.height(12.dp))
                Divider(color = BorderColor, thickness = 0.5.dp)
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    ProfileStatsCell("WIN RATE ESTIMATE", String.format("%.1f%%", totals.winRate))
                    val unrealizedPnlFormatted = if (totals.unrealizedPnlUsd >= 0.0) {
                        "+$" + java.lang.String.format(java.util.Locale.US, "%,.2f", totals.unrealizedPnlUsd)
                    } else {
                        "-$" + java.lang.String.format(java.util.Locale.US, "%,.2f", -totals.unrealizedPnlUsd)
                    }
                    ProfileStatsCell("BEST GAIN PNL EST", unrealizedPnlFormatted)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // NAV BAR FOR LOGS / ALERTS
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(BorderStroke(0.5.dp, BorderColor))
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clickable { selectedTab = 0 }
                    .background(if (selectedTab == 0) BaseBlue.copy(alpha = 0.1f) else Color.Transparent)
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.History, contentDescription = null, tint = if (selectedTab == 0) BaseBlue else TextMuted, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        "HISTORY",
                        color = if (selectedTab == 0) BaseBlue else TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clickable { selectedTab = 1 }
                    .background(if (selectedTab == 1) BaseBlue.copy(alpha = 0.1f) else Color.Transparent)
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.AddAlert, contentDescription = null, tint = if (selectedTab == 1) BaseBlue else TextMuted, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        "ALERTS (${alerts.size})",
                        color = if (selectedTab == 1) BaseBlue else TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Tab views
        if (selectedTab == 0) {
            if (rawHistory.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Belum ada trade yang dicatat.", color = TextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    rawHistory.forEach { tx ->
                        HistoryItemWidget(tx = tx)
                    }
                }
            }
        } else {
            AlertList(
                alerts = alerts,
                onDelete = { viewModel.removePriceAlert(it) }
            )
        }
    }
}

@Composable
fun ProfileStatsCell(label: String, value: String) {
    Column {
        Text(text = label, color = TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}
