package com.example.data

enum class SafetyRating {
    SAFE, WARNING, DANGER
}

data class Token(
    val id: String,
    val name: String,
    val symbol: String,
    val address: String,
    val logoUrl: String = "",
    val priceEth: Double,
    val priceUsd: Double,
    val priceChangePercent24h: Double,
    val volume24hUsd: Double,
    val marketCapUsd: Double,
    val liquidityEth: Double,
    val liquidityUsd: Double,
    val pairAgeHours: Double,
    val safetyRating: SafetyRating,
    val isHoneypot: Boolean = false,
    val isVerified: Boolean = true,
    val holdersCount: Int = 1450,
    val totalSupply: Double = 1_000_000_000.0,
    val description: String = "",
    val socialsTelegram: String = "",
    val socialsX: String = "",
    val socialsWebsite: String = "",
    val deployerAddress: String = "",
    val creationTimeMills: Long = System.currentTimeMillis() - 86400000L * 15 // 15 days ago
)

data class OhlcvPoint(
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
)

data class TradeHistoryItem(
    val id: String,
    val type: String, // "BUY" or "SELL"
    val isBuy: Boolean,
    val tokenAddress: String,
    val tokenName: String,
    val tokenSymbol: String,
    val ethAmount: Double,
    val tokenAmount: Double,
    val pricePaidEth: Double,
    val pricePaidUsd: Double,
    val timestamp: Long,
    val txHash: String,
    val status: String // "SUCCESS", "PENDING", "FAILED"
)

data class PriceAlert(
    val id: String,
    val tokenAddress: String,
    val tokenSymbol: String,
    val targetPriceUsd: Double,
    val isAbove: Boolean, // True path checks if price >= targetPriceUsd; False checks if price <= targetPriceUsd
    var isActive: Boolean = true,
    val createTime: Long = System.currentTimeMillis(),
    var isTriggered: Boolean = false,
    var triggeredPrice: Double = 0.0,
    var triggerTime: Long = 0L
)

data class PortfolioSnapshot(
    val timestamp: Long,
    val valueEth: Double,
    val valueUsd: Double
)

data class LeaderboardTrader(
    val rank: Int,
    val username: String,
    val address: String,
    val volumeEth: Double,
    val pnlUsd: Double,
    val winRate: Double,
    val totalTrades: Int,
    val avatarGradientStart: Long = 0xFF0052FF,
    val avatarGradientEnd: Long = 0xFF00FF88
)

data class LiveTrade(
    val id: String,
    val isBuy: Boolean, // BUY or SELL
    val walletShort: String,
    val ethAmount: Double,
    val tokenAmount: Double,
    val timeAgoString: String,
    val txHash: String
)

data class ChartSettings(
    val defaultTimeframe: String = "1m",
    val refreshRate: String = "Normal",
    val maxCandles: Int = 100,
    val autoSelectTimeframe: Boolean = true,
    val visibleTimeframes: Set<String> = setOf(
        "1s","5s","15s","30s",
        "1m","5m","15m",
        "1h","4h","1d"
    )
)

data class UserSettings(
    val theme: String = "Dark", // "Dark", "Light", "Auto"
    val accentColor: String = "#0052FF", // "#0052FF", "#00FF88", "#7C3AED", "#F5A623"
    val defaultChartStyle: String = "Candlestick", // "Candlestick", "Line"
    val isCompactMode: Boolean = false,

    val defaultSlippage: Double = 1.0,
    val defaultBuyAmounts: List<Double> = listOf(0.01, 0.05, 0.1, 0.5),
    val isConfirmBeforeTrade: Boolean = true,
    val gasPreference: String = "Standard", // "Standard", "Fast", "Instant"

    val isPriceAlertEnabled: Boolean = true,
    val isSoundAlertEnabled: Boolean = true,
    val isNewListingAlertEnabled: Boolean = true,

    val isHideDangerousTokens: Boolean = false,
    val isAutoSafetyCheck: Boolean = true,
    val blacklist: List<String> = emptyList(),

    val currencyDisplay: String = "Both", // "ETH", "USD", "Both"
    val addressFormat: String = "Short", // "Short", "Full"
    val timeFormat: String = "Relative", // "Relative", "Absolute"
    val isHideSmallBalances: Boolean = false,

    val isShowLiveFeedTicker: Boolean = true,
    val justLaunchedRefreshRateSeconds: Int = 10, // 5, 10, 30
    val minLiquidityUsd: Double = 1000.0,
    val hideTokensYoungerThanMinutes: Int = 0, // 0 (No filter), 1, 5, 10
    val isAutoOpenNewToken: Boolean = false,
    val dismissedLiveFeedTicker: Boolean = false,

    val bio: String = "",
    val chartSettings: ChartSettings = ChartSettings()
)

