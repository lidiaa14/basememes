package com.example.data

import kotlin.math.sin
import kotlin.random.Random

object MockData {

    val tokens = listOf(
        // === 12 SAFE TOKENS ===
        Token(
            id = "brett",
            name = "Brett on Base",
            symbol = "BRETT",
            address = "0x532f27101965dd16442e59d40670faf5ebb142e4",
            priceEth = 0.0000305,
            priceUsd = 0.0915,
            priceChangePercent24h = 8.42,
            volume24hUsd = 12450000.0,
            marketCapUsd = 915000000.0,
            liquidityEth = 8500.0,
            liquidityUsd = 25500000.0,
            pairAgeHours = 1420.0,
            safetyRating = SafetyRating.SAFE,
            isHoneypot = false,
            isVerified = true,
            holdersCount = 125000,
            totalSupply = 10_000_000_000.0,
            description = "BRETT is the legendary blue character from Matt Furie's Boys' Club comic. He is Pepe's best friend on the Base chain, representing speed, culture, and absolute meme dominance.",
            socialsTelegram = "t.me/brett_on_base",
            socialsX = "x.com/brett_on_base",
            socialsWebsite = "basedbrett.com",
            deployerAddress = "0x889988220011bbcc009988aa7744332211aa9988"
        ),
        Token(
            id = "degen",
            name = "Degen Token",
            symbol = "DEGEN",
            address = "0x4ed4e862860bed51a9570b96d89af5e1b0efefed",
            priceEth = 0.0000028,
            priceUsd = 0.0084,
            priceChangePercent24h = -3.12,
            volume24hUsd = 4850000.0,
            marketCapUsd = 124000000.0,
            liquidityEth = 3200.0,
            liquidityUsd = 9600000.0,
            pairAgeHours = 2400.0,
            safetyRating = SafetyRating.SAFE,
            isHoneypot = false,
            isVerified = true,
            holdersCount = 85000,
            totalSupply = 37_000_000_000.0,
            description = "DEGEN started as a reward token for participants in the Farcaster /degen channel. It has grown into Base's native reward utility token with a massive underlying community.",
            socialsTelegram = "t.me/degentokenbase",
            socialsX = "x.com/degentokenbase",
            socialsWebsite = "degen.tips",
            deployerAddress = "0x1111111122222233333344444455555566666677"
        ),
        Token(
            id = "toshi",
            name = "Toshi Cat",
            symbol = "TOSHI",
            address = "0xAC1cD25E15893C003022fbcaBE98c7c975a5Ebe9",
            priceEth = 0.000085,
            priceUsd = 0.255,
            priceChangePercent24h = 12.15,
            volume24hUsd = 1850000.0,
            marketCapUsd = 107000000.0,
            liquidityEth = 1200.0,
            liquidityUsd = 3600000.0,
            pairAgeHours = 3100.0,
            safetyRating = SafetyRating.SAFE,
            isHoneypot = false,
            isVerified = true,
            holdersCount = 42000,
            totalSupply = 420_690_000.0,
            description = "TOSHI is named after Brian Armstrong’s cat, Toshi, which is in turn named after Satoshi Nakamoto. Toshi is the cute, cuddly face of Base ecosystem tooling.",
            socialsTelegram = "t.me/toshi_base",
            socialsX = "x.com/toshicatbase",
            socialsWebsite = "toshi.base.org",
            deployerAddress = "0xbbccaa77ef88d99ccee7755aa1a2b2b1bc27bc37"
        ),
        Token(
            id = "keycat",
            name = "Keyboard Cat",
            symbol = "KEYCAT",
            address = "0x9a86214d4831e5d7f794931a7c5c00b0e9f60bc5",
            priceEth = 0.0000019,
            priceUsd = 0.0057,
            priceChangePercent24h = 24.52,
            volume24hUsd = 950000.0,
            marketCapUsd = 57000000.0,
            liquidityEth = 650.0,
            liquidityUsd = 1950000.0,
            pairAgeHours = 820.0,
            safetyRating = SafetyRating.SAFE,
            isHoneypot = false,
            isVerified = true,
            holdersCount = 18000,
            totalSupply = 10_000_000_000.0,
            description = "Keyboard Cat is the classic internet video of Fatso the cat playin' the key chords! Revived fully on Base Chain with custom pixel art styles.",
            socialsTelegram = "t.me/keycatbase",
            socialsX = "x.com/keycatbase",
            socialsWebsite = "keyboardcat.base",
            deployerAddress = "0xaabb0011ffddee22110099abcdc129aa18287bc1"
        ),
        Token(
            id = "mog",
            name = "Mog Coin",
            symbol = "MOG",
            address = "0x2e0619a86214d4a3ef794931a7c5c00b0e9f61b0",
            priceEth = 0.00000045,
            priceUsd = 0.00135,
            priceChangePercent24h = 1.15,
            volume24hUsd = 2400000.0,
            marketCapUsd = 430000000.0,
            liquidityEth = 4100.0,
            liquidityUsd = 12300000.0,
            pairAgeHours = 3500.0,
            safetyRating = SafetyRating.SAFE,
            isHoneypot = false,
            isVerified = true,
            holdersCount = 76000,
            totalSupply = 390_000_000_000.0,
            description = "MOG is the internet's first culture coin. Based meme energy for winners, keeping your style high, sunglasses on, and winning guaranteed.",
            socialsTelegram = "t.me/mogcoinbase",
            socialsX = "x.com/mogcoinbase",
            socialsWebsite = "mogcoin.xyz",
            deployerAddress = "0xccdd11223344efaa11122abccdd9988716aa6105"
        ),
        Token(
            id = "chompy",
            name = "Chompy",
            symbol = "CHOMPY",
            address = "0xab6214d119c5c00e9f60bc571bca422cfbca012a",
            priceEth = 0.000045,
            priceUsd = 0.135,
            priceChangePercent24h = 45.18,
            volume24hUsd = 1200000.0,
            marketCapUsd = 13500000.0,
            liquidityEth = 350.0,
            liquidityUsd = 1050000.0,
            pairAgeHours = 320.0,
            safetyRating = SafetyRating.SAFE,
            isHoneypot = false,
            isVerified = true,
            holdersCount = 9500,
            totalSupply = 100_000_000.0,
            description = "Chompy is the official Base core builder pet, ready to chew through blocks and eat fees, bringing green dildos all day.",
            socialsWebsite = "chompybase.io",
            deployerAddress = "0x23efab09871bbff0101918aadd71bbabcb67bbd2"
        ),
        Token(
            id = "mochi",
            name = "Mochi Cat",
            symbol = "MOCHI",
            address = "0x2a86bc1d4831e5d7f794931a7c5c00b0e9f601b0",
            priceEth = 0.00000085,
            priceUsd = 0.00255,
            priceChangePercent24h = -15.42,
            volume24hUsd = 620000.0,
            marketCapUsd = 25000000.0,
            liquidityEth = 480.0,
            liquidityUsd = 1440000.0,
            pairAgeHours = 1200.0,
            safetyRating = SafetyRating.SAFE,
            isHoneypot = false,
            isVerified = true,
            holdersCount = 21000,
            totalSupply = 10_000_000_000.0,
            description = "Mochi is named after Brian Armstrong's second adorable cat. Pure fluffy cuteness that drives community-led charity support and NFTs.",
            deployerAddress = "0x8a992cbffea12300aa4477bbaacdfbc112aa56ab"
        ),
        Token(
            id = "boomer",
            name = "Boomer Base",
            symbol = "BOOMER",
            address = "0xbf32a8a86214d4e9c794931a61c5cb0e9f60bc51",
            priceEth = 0.00012,
            priceUsd = 0.36,
            priceChangePercent24h = 5.21,
            volume24hUsd = 450000.0,
            marketCapUsd = 36000000.0,
            liquidityEth = 560.0,
            liquidityUsd = 1680000.0,
            pairAgeHours = 960.0,
            safetyRating = SafetyRating.SAFE,
            deployerAddress = "0x23acbb009aa8cc110a0a88bcccdd99bbcb182cba"
        ),
        Token(
            id = "roost",
            name = "Roost Coin",
            symbol = "ROOST",
            address = "0xe5bf32a8a86214d4e9c7949ee1c5cb0e9f60bc58",
            priceEth = 0.0000042,
            priceUsd = 0.0126,
            priceChangePercent24h = -0.52,
            volume24hUsd = 350000.0,
            marketCapUsd = 12600000.0,
            liquidityEth = 280.0,
            liquidityUsd = 840000.0,
            pairAgeHours = 710.0,
            safetyRating = SafetyRating.SAFE,
            deployerAddress = "0x8cbffd012cbaa990aa210214efbf91aa891bb2c5"
        ),
        Token(
            id = "basepepe",
            name = "Pepe on Base",
            symbol = "BPEPE",
            address = "0xce5bf32a8d11c0de9c7949ee1c5cb0e9ff6c72d1",
            priceEth = 0.000000012,
            priceUsd = 0.000036,
            priceChangePercent24h = 18.25,
            volume24hUsd = 980000.0,
            marketCapUsd = 15000000.0,
            liquidityEth = 420.0,
            liquidityUsd = 1260000.0,
            pairAgeHours = 180.0,
            safetyRating = SafetyRating.SAFE,
            deployerAddress = "0x2211ddeecc334488ff911cc99ab001acbdcbef81"
        ),
        Token(
            id = "higuys",
            name = "Hi Guys",
            symbol = "HIGUYS",
            address = "0x33e5bf32a8a86214d4e9c794931a7c5c00b0e9f6",
            priceEth = 0.00115,
            priceUsd = 3.45,
            priceChangePercent24h = -12.45,
            volume24hUsd = 320000.0,
            marketCapUsd = 3450000.0,
            liquidityEth = 180.0,
            liquidityUsd = 540000.0,
            pairAgeHours = 96.0,
            safetyRating = SafetyRating.SAFE
        ),
        Token(
            id = "based_pepe_junior",
            name = "Based Pepe Junior",
            symbol = "PEPEJR",
            address = "0xd86214d119c5c00e9f60bc571bca422cfbca012c",
            priceEth = 0.000000004,
            priceUsd = 0.000012,
            priceChangePercent24h = 58.12,
            volume24hUsd = 640000.0,
            marketCapUsd = 2400000.0,
            liquidityEth = 110.0,
            liquidityUsd = 330000.0,
            pairAgeHours = 18.2, // New listing (less than 24 hours!)
            safetyRating = SafetyRating.SAFE,
            deployerAddress = "0x77aa8c991b11ccde88bbcc82cc66336aaabcb123"
        ),

        // === 5 WARNING TOKENS ===
        Token(
            id = "ruggy",
            name = "Ruggy Bear",
            symbol = "RUGGY",
            address = "0x99e5bf32a8a86214d4e9c794931a7c5c00b0e980",
            priceEth = 0.0000012,
            priceUsd = 0.0036,
            priceChangePercent24h = -40.5,
            volume24hUsd = 15000.0,
            marketCapUsd = 120000.0,
            liquidityEth = 3.5, // low liquidity warning (< 10 ETH)
            liquidityUsd = 10500.0,
            pairAgeHours = 45.0,
            safetyRating = SafetyRating.WARNING,
            isHoneypot = false,
            isVerified = true,
            holdersCount = 210,
            totalSupply = 100_000_000.0,
            description = "Ruggy Bear has developer wallets holding more than 40% of the circulating supply. Extremely low liquidity. Proceed with extreme caution.",
            deployerAddress = "0x123abcdeeedcc773cbd7718aa00cdcbbfdbdc82a"
        ),
        Token(
            id = "safemoonbase",
            name = "SafeMoon Base",
            symbol = "SAFEMB",
            address = "0x55bf32a8a86214d4e9c794931a7c5c00b0e9f60bc",
            priceEth = 0.000000025,
            priceUsd = 0.000075,
            priceChangePercent24h = 15.6,
            volume24hUsd = 12000.0,
            marketCapUsd = 750000.0,
            liquidityEth = 12.0,
            liquidityUsd = 36000.0,
            pairAgeHours = 350.0,
            safetyRating = SafetyRating.WARNING,
            isHoneypot = false,
            isVerified = false, // unverified contract
            holdersCount = 850,
            totalSupply = 10_000_000_000.0,
            description = "This token uses custom tax mechanisms (Buy tax: 10%, Sell tax: 10%). The source code is unverified on Basescan. Owner can change parameters.",
            deployerAddress = "0xdd99bb776abcc00a1122ab99fbfc67117cbdca89"
        ),
        Token(
            id = "speedy",
            name = "Speedy Gonzales",
            symbol = "SPEEDY",
            address = "0x66f3e5bf32a8a86214d4e9c794931a7c5c00b0e",
            priceEth = 0.0000015,
            priceUsd = 0.0045,
            priceChangePercent24h = 0.0,
            volume24hUsd = 120.0, // no volume warning
            marketCapUsd = 450000.0,
            liquidityEth = 15.0,
            liquidityUsd = 45000.0,
            pairAgeHours = 26.0,
            safetyRating = SafetyRating.WARNING,
            deployerAddress = "0x5b3ab336100cddeba88abccdcd31bc27acdbeba8"
        ),
        Token(
            id = "dogebase",
            name = "Doge Base Classic",
            symbol = "DOGEBC",
            address = "0x77ce5bf32a8d11c0de9c7949ee1c5cb0e9ff6c72",
            priceEth = 0.000000015,
            priceUsd = 0.000045,
            priceChangePercent24h = -22.4,
            volume24hUsd = 8200.0,
            marketCapUsd = 90000.0,
            liquidityEth = 2.8, // low liquidity
            liquidityUsd = 8400.0,
            pairAgeHours = 12.0, // New listing but warning
            safetyRating = SafetyRating.WARNING,
            deployerAddress = "0x11abccdd88aabcdc55adcfbc2b3788cbca99bcae"
        ),
        Token(
            id = "meow",
            name = "Meow Base",
            symbol = "MEOW",
            address = "0x88fe5bf32a8a86214d4e9c794931a7c5c00b0e9f",
            priceEth = 0.00005,
            priceUsd = 0.15,
            priceChangePercent24h = -5.4,
            volume24hUsd = 3400.0,
            marketCapUsd = 1500000.0,
            liquidityEth = 16.0,
            liquidityUsd = 48000.0,
            pairAgeHours = 140.0,
            safetyRating = SafetyRating.WARNING,
            isVerified = false,
            deployerAddress = "0x9212bcde77aadccd1c77bb8aa8bc891122aabcee"
        ),

        // === 3 DANGER TOKENS ===
        Token(
            id = "honeybase",
            name = "Honeypot Finance",
            symbol = "HONEY",
            address = "0x11116214d119c5c00e9f60bc571bca422cfbca012",
            priceEth = 0.0018,
            priceUsd = 5.40,
            priceChangePercent24h = 420.52, // looks like a parabolic gain but you can't sell!
            volume24hUsd = 89000.0,
            marketCapUsd = 5400000.0,
            liquidityEth = 0.45, // < 1 ETH liquidity
            liquidityUsd = 1350.0,
            pairAgeHours = 6.0,
            safetyRating = SafetyRating.DANGER,
            isHoneypot = true, // honeypot/blacklist triggered!
            isVerified = false,
            holdersCount = 220,
            totalSupply = 1_000_000.0,
            description = "⚠️ KONTRAK BERBAHAYA - KEMUNGKINAN HONEYPOT. Fungsi sell dinonaktifkan dalam smart contract (hanya pembuat contract yang bisa menjual token). JANGAN BELI!",
            deployerAddress = "0xbaaaaaaaadddddd111122223333444455556666"
        ),
        Token(
            id = "mintbrrr",
            name = "Unlimited Brrr",
            symbol = "BRRR",
            address = "0x2222cd119c5c00e9f60bc571bca422cfbca012ca",
            priceEth = 0.000000001,
            priceUsd = 0.000003,
            priceChangePercent24h = -99.4,
            volume24hUsd = 50.0,
            marketCapUsd = 3000.0,
            liquidityEth = 0.08, // almost empty liquidity
            liquidityUsd = 240.0,
            pairAgeHours = 2.0,
            safetyRating = SafetyRating.DANGER,
            isHoneypot = false,
            isVerified = false,
            holdersCount = 18,
            totalSupply = 1_000_000_000_000.0,
            description = "⚠️ KONTRAK BERBAHAYA. Owner memiliki flag 'mintUnlimited' aktif dan terus mencetak token baru untuk didumping ke pool likuiditas.",
            deployerAddress = "0xbeefbeefefbeef88bbcc82377488ab89a912ba00"
        ),
        Token(
            id = "scamcoin",
            name = "Simulated Scam Coin",
            symbol = "SCAM",
            address = "0x3333cd119c5c00e9f60bc571bca422cfbca012cab",
            priceEth = 0.0000025,
            priceUsd = 0.0075,
            priceChangePercent24h = -85.12,
            volume24hUsd = 8.0,
            marketCapUsd = 7500.0,
            liquidityEth = 0.15,
            liquidityUsd = 450.0,
            pairAgeHours = 1.5,
            safetyRating = SafetyRating.DANGER,
            isHoneypot = true,
            isVerified = false,
            holdersCount = 4,
            totalSupply = 1_000_000.0,
            description = "⚠️ KONTRAK MANDATORY DANGER. Liquidity sangat rendah (<1 ETH), contract unverified, flagged as suspicious honeypot.",
            deployerAddress = "0xdeaddeadbcdeeeff88220011bbccaaccffaa5544"
        )
    )

    // Deteministically generate daily OHLCV candles (7 days) for a given token
    fun generateOhlcv(token: Token, intervalHours: Int = 1): List<OhlcvPoint> {
        val random = Random(token.address.hashCode())
        val list = mutableListOf<OhlcvPoint>()
        var currentPrice = token.priceUsd
        val pointsCount = 7 * 24 / intervalHours // hourly points for 7 days
        val startTime = System.currentTimeMillis() - 7L * 24 * 3600 * 1000

        for (i in 0 until pointsCount) {
            val pointTime = startTime + i * intervalHours * 3600 * 1000L
            val changePercent = (random.nextDouble() - 0.48) * 0.05 // slightly upward trend
            val open = currentPrice
            val close = currentPrice * (1.0 + changePercent)
            val high = maxOf(open, close) * (1.0 + random.nextDouble() * 0.02)
            val low = minOf(open, close) * (1.0 - random.nextDouble() * 0.02)
            val volume = token.volume24hUsd / 24.0 * (0.5 + random.nextDouble() * 1.5)

            list.add(OhlcvPoint(pointTime, open, high, low, close, volume))
            currentPrice = close
        }
        return list
    }

    // Standard 30 historic transactions
    val initialTradeHistory = listOf(
        TradeHistoryItem("tx1", "BUY", true, "0x532f27101965dd16442e59d40670faf5ebb142e4", "Brett on Base", "BRETT", 0.1, 3278.6, 0.0000305, 0.0915, System.currentTimeMillis() - 7200000, "0x1111...aaaa", "SUCCESS"),
        TradeHistoryItem("tx2", "BUY", true, "0x4ed4e862860bed51a9570b96d89af5e1b0efefed", "Degen Token", "DEGEN", 0.05, 17857.0, 0.0000028, 0.0084, System.currentTimeMillis() - 14400000, "0x2222...bbbb", "SUCCESS"),
        TradeHistoryItem("tx3", "BUY", true, "0xAC1cD25E15893C003022fbcaBE98c7c975a5Ebe9", "Toshi Cat", "TOSHI", 0.15, 1764.7, 0.000085, 0.255, System.currentTimeMillis() - 28800000, "0x3333...cccc", "SUCCESS"),
        TradeHistoryItem("tx4", "SELL", false, "0x532f27101965dd16442e59d40670faf5ebb142e4", "Brett on Base", "BRETT", 0.05, 1500.0, 0.000033, 0.099, System.currentTimeMillis() - 3600000, "0x4444...dddd", "SUCCESS"),
        TradeHistoryItem("tx5", "BUY", true, "0x9a86214d4831e5d7f794931a7c5c00b0e9f60bc5", "Keyboard Cat", "KEYCAT", 0.2, 105263.0, 0.0000019, 0.0057, System.currentTimeMillis() - 50000000, "0x5555...eeee", "SUCCESS")
    )

    // Standard 10 leaderboard traders
    val leaderboard = listOf(
        LeaderboardTrader(1, "BaseWhale", "0x3344...eeff", 420.5, 45200.0, 92.5, 134, 0xFF00FF88, 0xFF0052FF),
        LeaderboardTrader(2, "BananaKing", "0x8899...bbcc", 385.2, 38100.0, 88.1, 240, 0xFFFFFF00, 0xFFFF3B3B),
        LeaderboardTrader(3, "MemeSnipro", "0x55aa...1122", 215.1, 24500.0, 84.6, 95, 0xFFFF00FF, 0xFF00FFFF),
        LeaderboardTrader(4, "BrettMaxi", "0xcca7...27ff", 195.4, 18900.0, 78.4, 182, 0xFF0052FF, 0xFF8A8A8A),
        LeaderboardTrader(5, "BaseGigaChad", "0xdead...beef", 152.0, 15400.0, 71.2, 84, 0xFFFF3B3B, 0xFF00FF88),
        LeaderboardTrader(6, "DegenNo1", "0x1111...bbcc", 112.4, 9800.0, 68.5, 310, 0xFF00FFFF, 0xFF0052FF),
        LeaderboardTrader(7, "SatoshiCat", "0x9922...ffaa", 84.5, 6200.0, 65.1, 54, 0xFFAB47BC, 0xFF26A69A),
        LeaderboardTrader(8, "UniswapDeg", "0x77ab...cb12", 72.0, 4800.0, 61.2, 120, 0xFFEC407A, 0xFFFFA726),
        LeaderboardTrader(9, "MogPumper", "0x3344...32ac", 58.2, 3200.0, 59.8, 67, 0xFF9CCC65, 0xFFD4E157),
        LeaderboardTrader(10, "BaseBot_039", "0x23ac...182c", 45.0, 2100.0, 56.4, 45, 0xFF80CBC4, 0xFF0052FF)
    )

    // Simulated local pool real-time trades list (GeckoTerminal trades)
    fun generateLiveTrades(token: Token): List<LiveTrade> {
        val rand = Random(System.currentTimeMillis() / 10000L) // updates occasionally
        val list = mutableListOf<LiveTrade>()
        val words = listOf("0xab", "0x53", "0x4e", "0x9a", "0x2e", "0xcc", "0xde", "0x8cb", "0xba", "0x11")
        for (i in 0 until 10) {
            val directionBuy = rand.nextBoolean()
            val shortWallet = "${words[rand.nextInt(words.size)]}...${rand.nextInt(1000, 9999)}"
            val ethIn = rand.nextDouble(0.01, 0.45)
            val tokenOut = ethIn / token.priceEth * (0.98 + rand.nextDouble() * 0.04)
            val secondsAgo = i * 4 + rand.nextInt(0, 3)
            val timeString = if (secondsAgo == 0) "just now" else "${secondsAgo}s ago"
            list.add(
                LiveTrade(
                    id = "live_$i",
                    isBuy = directionBuy,
                    walletShort = shortWallet,
                    ethAmount = ethIn,
                    tokenAmount = tokenOut,
                    timeAgoString = timeString,
                    txHash = "0x" + token.address.take(4) + "..." + (100000 + i)
                )
            )
        }
        return list
    }
}
