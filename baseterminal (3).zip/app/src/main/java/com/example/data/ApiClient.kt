package com.example.data

import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

// DexScreener API models
data class DexToken(val address: String, val name: String, val symbol: String)
data class DexVolume(val h24: Double?)
data class DexLiquidity(val usd: Double?, val base: Double?, val quote: Double?)
data class DexPair(
    val chainId: String,
    val pairAddress: String,
    val baseToken: DexToken,
    val quoteToken: DexToken,
    val priceUsd: String?,
    val priceNative: String?,
    val volume: DexVolume?,
    val liquidity: DexLiquidity?,
    val marketCap: Double?
)
data class DexScreenerResponse(val pairs: List<DexPair>?)

// GeckoTerminal API models
data class GeckoAttributes(
    val name: String,
    val address: String,
    val price_in_usd: String?,
    val price_in_target_token: String?,
    val from_volume_in_usd: String?,
    val volume_usd: Map<String, String>?,
    val fee_percent: String?,
    val reserve_in_usd: String?,
    val pool_created_at: String? = null
)
data class GeckoPool(val id: String, val type: String, val attributes: GeckoAttributes)
data class GeckoTerminalResponse(val data: List<GeckoPool>?)

data class GeckoTradeAttributes(
    val price_from_in_usd: String?,
    val from_token_amount: String?,
    val block_timestamp: String?,
    val kind: String?
)
data class GeckoTrade(
    val id: String,
    val type: String,
    val attributes: GeckoTradeAttributes
)
data class GeckoTradesResponse(
    val data: List<GeckoTrade>?
)

data class GeckoOhlcvAttributes(
    val ohlcv_list: List<List<Double>>?
)
data class GeckoOhlcvData(
    val id: String,
    val type: String,
    val attributes: GeckoOhlcvAttributes?
)
data class GeckoOhlcvResponse(
    val data: GeckoOhlcvData?
)

// API Interface for DexScreener
interface DexScreenerService {
    @GET("dex/search")
    suspend fun searchTokens(@Query("q") query: String): DexScreenerResponse

    @GET("dex/tokens/{address}")
    suspend fun getTokenInfo(@Path("address") address: String): DexScreenerResponse
}

// API Interface for GeckoTerminal
interface GeckoTerminalService {
    @GET("networks/base/trending_pools")
    suspend fun getTrendingPools(): GeckoTerminalResponse

    @GET("networks/base/pools")
    suspend fun getNewlyLaunchedPools(
        @Query("page") page: Int,
        @Query("sort") sort: String
    ): GeckoTerminalResponse

    @GET("networks/base/tokens/{token_address}/pools")
    suspend fun getTokenPools(
        @Path("token_address") tokenAddress: String
    ): GeckoTerminalResponse

    @GET("networks/base/pools/{pool}/trades")
    suspend fun getPoolTrades(
        @Path("pool") pool: String
    ): GeckoTradesResponse

    @GET("networks/base/pools/{pool}/ohlcv/minute")
    suspend fun getOhlcvMinute(
        @Path("pool") pool: String,
        @Query("aggregate") aggregate: Int
    ): GeckoOhlcvResponse

    @GET("networks/base/pools/{pool}/ohlcv/hour")
    suspend fun getOhlcvHour(
        @Path("pool") pool: String,
        @Query("aggregate") aggregate: Int
    ): GeckoOhlcvResponse

    @GET("networks/base/pools/{pool}/ohlcv/day")
    suspend fun getOhlcvDay(
        @Path("pool") pool: String,
        @Query("aggregate") aggregate: Int
    ): GeckoOhlcvResponse
}

object ApiClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .build()

    private val moshiInstance = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val dexRetrofit = Retrofit.Builder()
        .baseUrl("https://api.dexscreener.com/latest/")
        .client(client)
        .addConverterFactory(MoshiConverterFactory.create(moshiInstance))
        .build()

    private val geckoRetrofit = Retrofit.Builder()
        .baseUrl("https://api.geckoterminal.com/api/v2/")
        .client(client)
        .addConverterFactory(MoshiConverterFactory.create(moshiInstance))
        .build()

    val dexService: DexScreenerService = dexRetrofit.create(DexScreenerService::class.java)
    val geckoService: GeckoTerminalService = geckoRetrofit.create(GeckoTerminalService::class.java)

    // Resilient fallback fetch wrapper for searches
    suspend fun searchTokensResilient(query: String): List<Token> {
        if (query.isBlank()) return emptyList()
        return try {
            val response = dexService.searchTokens(query)
            val pairs = response.pairs?.filter { it.chainId == "base" } ?: emptyList()
            if (pairs.isEmpty()) {
                fallbackSearch(query)
            } else {
                pairs.map { pair ->
                    Token(
                        id = pair.baseToken.address.take(10),
                        name = pair.baseToken.name,
                        symbol = pair.baseToken.symbol,
                        address = pair.baseToken.address,
                        priceUsd = pair.priceUsd?.toDoubleOrNull() ?: 0.0,
                        priceEth = pair.priceNative?.toDoubleOrNull() ?: 0.0,
                        priceChangePercent24h = 0.0, // Default for search
                        volume24hUsd = pair.volume?.h24 ?: 0.0,
                        marketCapUsd = pair.marketCap ?: 0.0,
                        liquidityEth = (pair.liquidity?.usd ?: 0.0) / 3000.0,
                        liquidityUsd = pair.liquidity?.usd ?: 0.0,
                        pairAgeHours = 120.0,
                        safetyRating = if ((pair.liquidity?.usd ?: 0.0) > 30000) SafetyRating.SAFE else SafetyRating.WARNING
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            fallbackSearch(query)
        }
    }

    private fun fallbackSearch(query: String): List<Token> {
        val lowerQuery = query.lowercase()
        return MockData.tokens.filter {
            it.name.lowercase().contains(lowerQuery) ||
            it.symbol.lowercase().contains(lowerQuery) ||
            it.address.lowercase() == lowerQuery
        }
    }
}
