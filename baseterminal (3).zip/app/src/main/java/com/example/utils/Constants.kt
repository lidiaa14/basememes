package com.example.utils

object Constants {
    const val FEE_ROUTER_ADDRESS = "0xb3e642bf1140026a2603336E57B271c5C0b26F42" // Example deployed FeeRouter on Base
    const val FEE_PERCENT = 1.0 // 1% Fee integrated automatically
    const val BASE_CHAIN_ID = 8453
    const val UNISWAP_ROUTER = "0x2626664c2603336E57B271c5C0b26F421741e481"
    const val WETH_BASE = "0x4200000000000000000000000000000000000006"
    const val RPC_URL = "https://mainnet.base.org"

    // Complete FeeRouter ABI in JSON for contract view and logs
    val FEE_ROUTER_ABI_JSON = """
    [
      {
        "inputs": [
          {"internalType": "address", "name": "tokenOut", "type": "address"},
          {"internalType": "uint256", "name": "minAmountOut", "type": "uint256"},
          {"internalType": "uint24", "name": "poolFee", "type": "uint24"}
        ],
        "name": "buyToken",
        "outputs": [],
        "stateMutability": "payable",
        "type": "function"
      },
      {
        "inputs": [
          {"internalType": "uint256", "name": "newFee", "type": "uint256"}
        ],
        "name": "updateFee",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
      },
      {
        "inputs": [
          {"internalType": "address", "name": "newOwner", "type": "address"}
        ],
        "name": "updateOwner",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
      },
      {
        "inputs": [],
        "name": "owner",
        "outputs": [
          {"internalType": "address", "name": "", "type": "address"}
        ],
        "stateMutability": "view",
        "type": "function"
      },
      {
        "inputs": [],
        "name": "feePercent",
        "outputs": [
          {"internalType": "uint256", "name": "", "type": "uint256"}
        ],
        "stateMutability": "view",
        "type": "function"
      },
      {
        "anonymous": false,
        "inputs": [
          {"indexed": true, "internalType": "address", "name": "buyer", "type": "address"},
          {"indexed": true, "internalType": "address", "name": "token", "type": "address"},
          {"indexed": false, "internalType": "uint256", "name": "ethIn", "type": "uint256"},
          {"indexed": false, "internalType": "uint256", "name": "fee", "type": "uint256"}
        ],
        "name": "TokenBought",
        "type": "event"
      }
    ]
    """.trimIndent()
}
