package com.example.utils

object TimeframeHelper {
    
    val ALL_TIMEFRAMES = listOf("1s", "5s", "15s", "30s", "1m", "5m", "15m", "1h", "4h", "1d")

    fun findNearestAvailableTimeframe(disabledTf: String, visibleSet: Set<String>): String {
        val index = ALL_TIMEFRAMES.indexOf(disabledTf)
        if (index == -1) return visibleSet.firstOrNull() ?: "1m"
        
        var offset = 1
        while (offset < ALL_TIMEFRAMES.size) {
            // Check lower side index
            val lowerIdx = index - offset
            if (lowerIdx >= 0) {
                val candidate = ALL_TIMEFRAMES[lowerIdx]
                if (visibleSet.contains(candidate)) return candidate
            }
            // Check higher side index
            val higherIdx = index + offset
            if (higherIdx < ALL_TIMEFRAMES.size) {
                val candidate = ALL_TIMEFRAMES[higherIdx]
                if (visibleSet.contains(candidate)) return candidate
            }
            offset++
        }
        return visibleSet.firstOrNull() ?: "1m"
    }
}
