package com.example.utils

data class Trade(
    val price: Double,
    val amount: Double,
    val timestamp: Long,
    val type: String
)

data class Candle(
    val time: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
)

fun buildCandlesFromTrades(
    trades: List<Trade>,
    intervalSeconds: Int,
    maxCandles: Int = 100
): List<Candle> {
    if (trades.isEmpty()) return emptyList()
    
    val sorted = trades.sortedBy { it.timestamp }
    val intervalMs = intervalSeconds * 1000L
    
    val buckets = sorted.groupBy { trade ->
        (trade.timestamp / intervalMs) * intervalMs
    }
    
    return buckets.map { (time, trades) ->
        Candle(
            time = time,
            open = trades.first().price,
            high = trades.maxOf { it.price },
            low = trades.minOf { it.price },
            close = trades.last().price,
            volume = trades.sumOf { it.amount }
        )
    }.takeLast(maxCandles)
}
