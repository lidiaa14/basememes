package com.example.utils

import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Formatters {

    fun formatUsd(value: Double): String {
        return if (value < 0.01 && value > 0) {
            val df = DecimalFormat("$#.######")
            df.format(value)
        } else if (value >= 1_000_000) {
            formatNumberCompact(value, "$")
        } else {
            val df = DecimalFormat("$#,##0.00")
            df.format(value)
        }
    }

    fun formatEth(value: Double): String {
        return if (value < 0.0001 && value > 0) {
            val df = DecimalFormat("#.######## ETH")
            df.format(value)
        } else {
            val df = DecimalFormat("#,##0.0000 ETH")
            df.format(value)
        }
    }

    fun formatPercentage(value: Double): String {
        val df = DecimalFormat("+#,##0.00%;-#,##0.00%")
        return df.format(value / 100.0)
    }

    fun formatNumberCompact(value: Double, prefix: String = ""): String {
        return when {
            value >= 1_000_000_000 -> {
                val df = DecimalFormat("#,##0.00")
                prefix + df.format(value / 1_000_000_000) + "B"
            }
            value >= 1_000_000 -> {
                val df = DecimalFormat("#,##0.00")
                prefix + df.format(value / 1_000_000) + "M"
            }
            value >= 1_000 -> {
                val df = DecimalFormat("#,##0.0")
                prefix + df.format(value / 1_000) + "K"
            }
            else -> {
                val df = DecimalFormat("#,##0.00")
                prefix + df.format(value)
            }
        }
    }

    fun formatTimestamp(timeMills: Long): String {
        val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        return sdf.format(Date(timeMills))
    }

    fun formatDateTime(timeMills: Long): String {
        val sdf = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault())
        return sdf.format(Date(timeMills))
    }

    fun shortenAddress(address: String): String {
        if (address.length < 10) return address
        return address.take(6) + "..." + address.takeLast(4)
    }
}
