package com.example.utils

import android.content.Context
import android.content.SharedPreferences
import com.example.data.PortfolioSnapshot
import com.example.data.PriceAlert
import com.example.data.TradeHistoryItem
import com.example.data.UserSettings
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.ToJson
import com.squareup.moshi.FromJson
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

class SetAdapter {
    @ToJson
    fun toJson(set: Set<String>): List<String> {
        return set.toList()
    }

    @FromJson
    fun fromJson(list: List<String>): Set<String> {
        return list.toSet()
    }
}

class StorageHelper(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("base_trader_prefs", Context.MODE_PRIVATE)

    private val moshi = Moshi.Builder()
        .add(SetAdapter())
        .addLast(KotlinJsonAdapterFactory())
        .build()

    // Moshi list adapters
    private val stringListAdapter = moshi.adapter<List<String>>(
        Types.newParameterizedType(List::class.java, String::class.java)
    )

    private val tradeHistoryAdapter = moshi.adapter<List<TradeHistoryItem>>(
        Types.newParameterizedType(List::class.java, TradeHistoryItem::class.java)
    )

    private val priceAlertAdapter = moshi.adapter<List<PriceAlert>>(
        Types.newParameterizedType(List::class.java, PriceAlert::class.java)
    )

    private val portfolioSnapshotAdapter = moshi.adapter<List<PortfolioSnapshot>>(
        Types.newParameterizedType(List::class.java, PortfolioSnapshot::class.java)
    )

    private val holdingsAdapter = moshi.adapter<Map<String, Double>>(
        Types.newParameterizedType(Map::class.java, String::class.java, Double::class.javaObjectType)
    )

    private val userSettingsAdapter = moshi.adapter(UserSettings::class.java)

    // USERNAME
    fun getUsername(): String {
        return prefs.getString("username", "") ?: ""
    }

    fun setUsername(name: String) {
        prefs.edit().putString("username", name).apply()
    }

    // CONNECTED WALLET ADDRESS
    fun getWalletAddress(): String {
        return prefs.getString("wallet_address", "0xDemoWalletBaseTrade5Eth") ?: "0xDemoWalletBaseTrade5Eth"
    }

    fun setWalletAddress(address: String) {
        prefs.edit().putString("wallet_address", address).apply()
    }

    // IS WALLET CONNECTED
    fun isWalletConnected(): Boolean {
        return prefs.getBoolean("wallet_connected", true) // Default true for demo wallet ease of use
    }

    fun setWalletConnected(connected: Boolean) {
        prefs.edit().putBoolean("wallet_connected", connected).apply()
    }

    // DEMO ETH BALANCE (Defaults to 5.0 ETH)
    fun getDemoEthBalance(): Double {
        return prefs.getFloat("demo_eth_balance", 5.0f).toDouble()
    }

    fun setDemoEthBalance(balance: Double) {
        prefs.edit().putFloat("demo_eth_balance", balance.toFloat()).apply()
    }

    // DEMO TOKEN HOLDINGS (Contract Address -> Amount)
    fun getDemoHoldings(): Map<String, Double> {
        val json = prefs.getString("demo_holdings", null) ?: return mapOf(
            "0x532f27101965dd16442e59d40670faf5ebb142e4" to 540.0, // BRETT
            "0x4ed4e862860bed51a9570b96d89af5e1b0efefed" to 12500.0 // DEGEN
        )
        return try {
            holdingsAdapter.fromJson(json) ?: emptyMap()
        } catch (e: Exception) {
            emptyMap()
        }
    }

    fun setDemoHoldings(holdings: Map<String, Double>) {
        try {
            val json = holdingsAdapter.toJson(holdings)
            prefs.edit().putString("demo_holdings", json).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // RECENT SEARCHES
    fun getRecentSearches(): List<String> {
        val json = prefs.getString("recent_searches", null) ?: return emptyList()
        return try {
            stringListAdapter.fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveRecentSearch(query: String) {
        val current = getRecentSearches().toMutableList()
        current.remove(query)
        current.add(0, query)
        val limited = if (current.size > 10) current.subList(0, 10) else current
        try {
            val json = stringListAdapter.toJson(limited)
            prefs.edit().putString("recent_searches", json).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun clearRecentSearches() {
        prefs.edit().remove("recent_searches").apply()
    }

    // RECENTLY VIEWED
    fun getRecentlyViewed(): List<String> {
        val json = prefs.getString("recently_viewed", null) ?: return emptyList()
        return try {
            stringListAdapter.fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveRecentlyViewed(address: String) {
        val current = getRecentlyViewed().toMutableList()
        current.remove(address)
        current.add(0, address)
        val limited = if (current.size > 5) current.subList(0, 5) else current
        try {
            val json = stringListAdapter.toJson(limited)
            prefs.edit().putString("recently_viewed", json).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // HISTORICAL TRADE HISTORY
    fun getTradeHistory(): List<TradeHistoryItem> {
        val json = prefs.getString("trade_history", null)
        if (json == null) {
            // Seed initial data if empty
            val initial = com.example.data.MockData.initialTradeHistory
            setTradeHistory(initial)
            return initial
        }
        return try {
            tradeHistoryAdapter.fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveTradeHistoryItem(item: TradeHistoryItem) {
        val current = getTradeHistory().toMutableList()
        current.add(0, item)
        setTradeHistory(current)
    }

    fun setTradeHistory(list: List<TradeHistoryItem>) {
        try {
            val json = tradeHistoryAdapter.toJson(list)
            prefs.edit().putString("trade_history", json).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // PRICE ALERTS
    fun getPriceAlerts(): List<PriceAlert> {
        val json = prefs.getString("price_alerts", null) ?: return emptyList()
        return try {
            priceAlertAdapter.fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun savePriceAlert(alert: PriceAlert) {
        val current = getPriceAlerts().toMutableList()
        current.removeIf { it.id == alert.id }
        current.add(0, alert)
        setPriceAlerts(current)
    }

    fun setPriceAlerts(list: List<PriceAlert>) {
        try {
            val json = priceAlertAdapter.toJson(list)
            prefs.edit().putString("price_alerts", json).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // PORTFOLIO SNAPSHOTS
    fun getPortfolioSnapshots(): List<PortfolioSnapshot> {
        val json = prefs.getString("portfolio_snapshots", null)
        if (json == null) {
            // Seed 7 days portfolio snapshots
            val list = mutableListOf<PortfolioSnapshot>()
            val now = System.currentTimeMillis()
            for (i in 0..6) {
                val t = now - (6 - i) * 86400000L
                val valEth = 5.0 + i * 0.15 + (kotlin.math.sin(i.toDouble()) * 0.2)
                val valUsd = valEth * 3000.0
                list.add(PortfolioSnapshot(t, valEth, valUsd))
            }
            setPortfolioSnapshots(list)
            return list
        }
        return try {
            portfolioSnapshotAdapter.fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun setPortfolioSnapshots(list: List<PortfolioSnapshot>) {
        try {
            val json = portfolioSnapshotAdapter.toJson(list)
            prefs.edit().putString("portfolio_snapshots", json).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun addPortfolioSnapshot(snapshot: PortfolioSnapshot) {
        val current = getPortfolioSnapshots().toMutableList()
        current.add(snapshot)
        // Keep last 30 snapshots
        val trimmed = if (current.size > 30) current.takeLast(30) else current
        setPortfolioSnapshots(trimmed)
    }

    fun getUserSettings(): UserSettings {
        val json = prefs.getString("userSettings", null) ?: return UserSettings()
        return try {
            userSettingsAdapter.fromJson(json) ?: UserSettings()
        } catch (e: Exception) {
            UserSettings()
        }
    }

    fun setUserSettings(settings: UserSettings) {
        try {
            val json = userSettingsAdapter.toJson(settings)
            prefs.edit().putString("userSettings", json).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun clearAllLocalData() {
        prefs.edit().clear().apply()
    }
}
