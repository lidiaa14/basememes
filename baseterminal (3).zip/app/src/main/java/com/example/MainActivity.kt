package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AddAlert
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Hardware
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.example.ui.components.TransactionToast
import com.example.ui.screens.*
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import androidx.compose.material.icons.filled.Settings
import com.example.ui.theme.BaseBlue
import com.example.ui.theme.DarkBg
import com.example.ui.theme.JetBlack
import com.example.ui.theme.SafeGreen
import com.example.ui.theme.BorderColor
import com.example.ui.theme.TextMuted
import com.example.ui.viewmodel.TradingViewModel
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: TradingViewModel = viewModel()
            val userSettings by viewModel.userSettings.collectAsState()
            MyApplicationTheme(userSettings = userSettings) {
                MainAppContainer(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppContainer(viewModel: TradingViewModel) {
    val context = LocalContext.current
    val navController = rememberNavController()

    val txState by viewModel.txState.collectAsState()
    val tokens by viewModel.tokens.collectAsState()

    val currentBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = currentBackStackEntry?.destination?.route ?: "home"

    // Listen to real-time price alerts being triggered
    LaunchedEffect(Unit) {
        viewModel.alertTriggeredFlow.collectLatest { alert ->
            Toast.makeText(
                context,
                "🔔 ALERT TRIGGERED! ${alert.tokenSymbol} mencapai $${alert.targetPriceUsd}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = DarkBg,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .background(JetBlack)
                    .border(BottomBorder(1.dp, BorderColor))
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "BASE SWIFT",
                        color = BaseBlue,
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "⚡",
                        color = Color(0xFFF5A623),
                        fontSize = 14.sp
                    )
                }

                // Neon connected status tag (Base RPC indicator)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(32.dp))
                        .background(Color(0x1500FF88))
                        .border(0.5.dp, SafeGreen.copy(alpha = 0.4f), RoundedCornerShape(32.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(SafeGreen, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "BASE MAINNET",
                        color = SafeGreen,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = JetBlack,
                tonalElevation = 0.dp,
                modifier = Modifier
                    .navigationBarsPadding()
                    .border(TopBorder(1.dp, BorderColor))
                    .height(64.dp)
            ) {
                // Segment Nav Tabs
                val isSelectedHome = currentRoute == "home" || currentRoute.startsWith("trade")
                val scaleHome by animateFloatAsState(
                    targetValue = if (isSelectedHome) 1.15f else 1.0f,
                    animationSpec = spring(dampingRatio = 0.6f, stiffness = 400f),
                    label = "scaleHome"
                )
                NavigationBarItem(
                    selected = isSelectedHome,
                    onClick = {
                        if (currentRoute.startsWith("trade")) {
                            val popped = navController.popBackStack("home", inclusive = false)
                            if (!popped) {
                                navController.navigate("home") {
                                    popUpTo("home") { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        } else {
                            navController.navigate("home") {
                                    popUpTo("home") { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                        }
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Dashboard,
                            contentDescription = "Trade",
                            modifier = Modifier.graphicsLayer {
                                scaleX = scaleHome
                                scaleY = scaleHome
                            }
                        )
                    },
                    label = { Text("Trade", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted,
                        indicatorColor = Color.Transparent
                    )
                )

                val isSelectedPortfolio = currentRoute == "portfolio"
                val scalePortfolio by animateFloatAsState(
                    targetValue = if (isSelectedPortfolio) 1.15f else 1.0f,
                    animationSpec = spring(dampingRatio = 0.6f, stiffness = 400f),
                    label = "scalePortfolio"
                )
                NavigationBarItem(
                    selected = isSelectedPortfolio,
                    onClick = {
                        navController.navigate("portfolio") {
                            popUpTo("home") { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.PieChart,
                            contentDescription = "Portfolio",
                            modifier = Modifier.graphicsLayer {
                                scaleX = scalePortfolio
                                scaleY = scalePortfolio
                            }
                        )
                    },
                    label = { Text("Portfolio", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted,
                        indicatorColor = Color.Transparent
                    )
                )

                val isSelectedLeaderboard = currentRoute == "leaderboard"
                val scaleLeaderboard by animateFloatAsState(
                    targetValue = if (isSelectedLeaderboard) 1.15f else 1.0f,
                    animationSpec = spring(dampingRatio = 0.6f, stiffness = 400f),
                    label = "scaleLeaderboard"
                )
                NavigationBarItem(
                    selected = isSelectedLeaderboard,
                    onClick = {
                        navController.navigate("leaderboard") {
                            popUpTo("home") { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = "Leaderboard",
                            modifier = Modifier.graphicsLayer {
                                scaleX = scaleLeaderboard
                                scaleY = scaleLeaderboard
                            }
                        )
                    },
                    label = { Text("Ranks", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted,
                        indicatorColor = Color.Transparent
                    )
                )

                val isSelectedProfile = currentRoute == "profile"
                val scaleProfile by animateFloatAsState(
                    targetValue = if (isSelectedProfile) 1.15f else 1.0f,
                    animationSpec = spring(dampingRatio = 0.6f, stiffness = 400f),
                    label = "scaleProfile"
                )
                NavigationBarItem(
                    selected = isSelectedProfile,
                    onClick = {
                        navController.navigate("profile") {
                            popUpTo("home") { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = "Profile",
                            modifier = Modifier.graphicsLayer {
                                scaleX = scaleProfile
                                scaleY = scaleProfile
                            }
                        )
                    },
                    label = { Text("Profile", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted,
                        indicatorColor = Color.Transparent
                    )
                )

                val isSelectedSettings = currentRoute == "settings"
                val scaleSettings by animateFloatAsState(
                    targetValue = if (isSelectedSettings) 1.15f else 1.0f,
                    animationSpec = spring(dampingRatio = 0.6f, stiffness = 400f),
                    label = "scaleSettings"
                )
                NavigationBarItem(
                    selected = isSelectedSettings,
                    onClick = {
                        navController.navigate("settings") {
                            popUpTo("home") { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            modifier = Modifier.graphicsLayer {
                                scaleX = scaleSettings
                                scaleY = scaleSettings
                            }
                        )
                    },
                    label = { Text("Settings", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted,
                        indicatorColor = Color.Transparent
                    )
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main type-safe Navigation Stack graph routing
            NavHost(
                navController = navController,
                startDestination = "home",
                modifier = Modifier.fillMaxSize(),
                enterTransition = {
                    fadeIn(animationSpec = tween(durationMillis = 300)) +
                            slideInVertically(
                                initialOffsetY = { 40 },
                                animationSpec = tween(durationMillis = 300)
                            )
                },
                exitTransition = {
                    fadeOut(animationSpec = tween(durationMillis = 300))
                },
                popEnterTransition = {
                    fadeIn(animationSpec = tween(durationMillis = 300))
                },
                popExitTransition = {
                    fadeOut(animationSpec = tween(durationMillis = 300)) +
                            slideOutVertically(
                                targetOffsetY = { 40 },
                                animationSpec = tween(durationMillis = 300)
                            )
                }
            ) {
                composable("home") {
                    HomeScreen(
                        viewModel = viewModel,
                        onTokenNavigate = { address ->
                            navController.navigate("trade/$address")
                        }
                    )
                }

                composable(
                    route = "trade/{address}",
                    arguments = listOf(navArgument("address") { type = NavType.StringType })
                ) { backStackEntry ->
                    val address = backStackEntry.arguments?.getString("address") ?: ""
                    TradeScreen(
                        viewModel = viewModel,
                        tokenAddress = address,
                        onBack = {
                            val popped = navController.popBackStack()
                            if (!popped) {
                                navController.navigate("home") {
                                    popUpTo("home") { inclusive = true }
                                }
                            }
                        }
                    )
                }

                composable("portfolio") {
                    PortfolioScreen(
                        viewModel = viewModel,
                        onTokenNavigate = { address ->
                            navController.navigate("trade/$address")
                        }
                    )
                }

                composable("leaderboard") {
                    LeaderboardScreen()
                }

                composable("profile") {
                    ProfileScreen(
                        viewModel = viewModel,
                        onTokenNavigate = { address ->
                            navController.navigate("trade/$address")
                        }
                    )
                }

                composable("settings") {
                    SettingsScreen(viewModel = viewModel)
                }
            }

            // Shared transaction status Toast overlay
            TransactionToast(
                txState = txState,
                onDismiss = { viewModel.resetTxState() }
            )
        }
    }
}

// Helpers for precise element borders
private fun BottomBorder(strokeWidth: androidx.compose.ui.unit.Dp, color: Color) = BorderStroke(strokeWidth, color)
private fun TopBorder(strokeWidth: androidx.compose.ui.unit.Dp, color: Color) = BorderStroke(strokeWidth, color)
